import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ShoppingBag,
  Package,
  BarChart3,
  Users,
  RotateCcw,
  Settings as SettingsIcon,
  Search,
  Plus,
  Minus,
  Check,
  AlertTriangle,
  Printer,
  QrCode,
  FileSpreadsheet,
  FileDown,
  Upload,
  Moon,
  Sun,
  Lock,
  X,
  CreditCard,
  Banknote,
  Percent,
  Tag,
  DollarSign,
  ChevronRight,
  RefreshCw,
  Trash2,
  Edit,
  ArrowLeft,
  Volume2,
  VolumeX,
  Clock,
  UserCheck,
  Receipt,
  HelpCircle,
  ExternalLink,
  ShieldCheck,
  Wifi,
  WifiOff,
  Menu,
  Eye
} from 'lucide-react';
import {
  Product,
  CartItem,
  Customer,
  Sale,
  Refund,
  StoreSettings,
  HardwareState,
  PaymentMethod,
  ThermalSalesReport
} from './types';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_SALES
} from './data/initialData';
import { hardwareManager, playSound } from './utils/hardware';
import { exportFullBackupXLSX, exportInventoryXLSX, parseInventoryXLSX } from './utils/excelBackup';
import { generateSalesReportPDF } from './utils/reportsPdf';

type NavPage = 'register' | 'inventory' | 'reports' | 'customers' | 'refunds' | 'settings';

export default function App() {
  // ----------------------------------------------------
  // Persistent State (Offline-first via LocalStorage)
  // ----------------------------------------------------
  const [settings, setSettings] = useState<StoreSettings>(() => {
    const saved = localStorage.getItem('shopify_pos_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('shopify_pos_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('shopify_pos_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('shopify_pos_sales');
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });

  const [refunds, setRefunds] = useState<Refund[]>(() => {
    const saved = localStorage.getItem('shopify_pos_refunds');
    return saved ? JSON.parse(saved) : [];
  });

  // Navigation
  const [currentPage, setCurrentPage] = useState<NavPage>('register');
  const [isNavDrawerOpen, setIsNavDrawerOpen] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Security / PIN for Inventory (Strictly 1111)
  const [isInventoryUnlocked, setIsInventoryUnlocked] = useState<boolean>(false);
  const [showPinModal, setShowPinModal] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  // Cart State (Register)
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('Most Selling');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [orderNote, setOrderNote] = useState<string>('');
  const [cartDiscount, setCartDiscount] = useState<{ type: 'percent' | 'fixed'; value: number } | null>(null);

  // Modals & Dialogs
  const [showCheckoutModal, setShowCheckoutModal] = useState<boolean>(false);
  const [checkoutPaymentMethod, setCheckoutPaymentMethod] = useState<PaymentMethod>('card');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [splitCashAmount, setSplitCashAmount] = useState<string>('');
  const [splitCardAmount, setSplitCardAmount] = useState<string>('');
  const [showReceiptModal, setShowReceiptModal] = useState<boolean>(false);
  const [lastSale, setLastSale] = useState<Sale | null>(null);

  // Out of Stock & Barcode Alerts
  const [outOfStockProduct, setOutOfStockProduct] = useState<Product | null>(null);
  const [lowStockAlerts, setLowStockAlerts] = useState<{ product: Product; stock: number }[]>([]);
  const [showAddProductModal, setShowAddProductModal] = useState<boolean>(false);
  const [prefilledBarcode, setPrefilledBarcode] = useState<string>('');

  // Discount Modal
  const [showDiscountModal, setShowDiscountModal] = useState<boolean>(false);
  const [discountInputVal, setDiscountInputVal] = useState<string>('');
  const [discountType, setDiscountType] = useState<'percent' | 'fixed'>('percent');

  // Customer Selector Modal, Directory & Purchase History
  const [showCustomerModal, setShowCustomerModal] = useState<boolean>(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');
  const [showNewCustomerModal, setShowNewCustomerModal] = useState<boolean>(false);
  const [customerDirectorySearch, setCustomerDirectorySearch] = useState<string>('');
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [showEditCustomerModal, setShowEditCustomerModal] = useState<boolean>(false);
  const [editCustomerTab, setEditCustomerTab] = useState<'profile' | 'history'>('profile');
  const [editFormName, setEditFormName] = useState<string>('');
  const [editFormEmail, setEditFormEmail] = useState<string>('');
  const [editFormPhone, setEditFormPhone] = useState<string>('');
  const [editFormNotes, setEditFormNotes] = useState<string>('');
  const [editFormError, setEditFormError] = useState<string>('');
  const [editConfirmDelete, setEditConfirmDelete] = useState<boolean>(false);
  const [viewingCustomerHistory, setViewingCustomerHistory] = useState<Customer | null>(null);
  const [customerHistoryTab, setCustomerHistoryTab] = useState<'items' | 'orders'>('items');

  // Note Modal
  const [showNoteModal, setShowNoteModal] = useState<boolean>(false);
  const [noteInput, setNoteInput] = useState<string>('');

  // Product CRUD in Inventory
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [viewingProductDetails, setViewingProductDetails] = useState<Product | null>(null);
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);
  const [inventorySearch, setInventorySearch] = useState<string>('');
  const [inventoryCategoryFilter, setInventoryCategoryFilter] = useState<string>('All');

  // Reports Date Filter & POS Thermal Sales Report
  const [reportDateRange, setReportDateRange] = useState<'today' | 'week' | 'month' | 'all'>('week');
  const [thermalReportData, setThermalReportData] = useState<ThermalSalesReport | null>(null);

  // Refunds State
  const [refundSearch, setRefundSearch] = useState<string>('');
  const [selectedSaleForRefund, setSelectedSaleForRefund] = useState<Sale | null>(null);
  const [refundItemQuantities, setRefundItemQuantities] = useState<{ [productId: string]: number }>({});
  const [refundReason, setRefundReason] = useState<string>('Customer returned goods');
  const [showRefundReceiptModal, setShowRefundReceiptModal] = useState<boolean>(false);
  const [lastRefund, setLastRefund] = useState<Refund | null>(null);
  const [showQuickRefundModal, setShowQuickRefundModal] = useState<boolean>(false);
  const [quickRefundSearch, setQuickRefundSearch] = useState<string>('');

  // Real Hardware State
  const [hardware, setHardware] = useState<HardwareState>({
    scannerConnected: false,
    scannerName: 'Disconnected',
    printerConnected: false,
    printerName: 'Disconnected',
    lastScannedBarcode: ''
  });
  const [hardwarePairingMsg, setHardwarePairingMsg] = useState<{ type: 'scanner' | 'printer'; message: string; isError?: boolean } | null>(null);

  // Time display
  const [currentTime, setCurrentTime] = useState<string>(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

  // References
  const searchInputRef = useRef<HTMLInputElement>(null);
  const barcodeBufferRef = useRef<string>('');
  const lastKeyTimeRef = useRef<number>(0);

  // Sync Theme to HTML and Body tags (prevents text color blending)
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
  }, [settings.theme]);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('shopify_pos_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('shopify_pos_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('shopify_pos_customers', JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem('shopify_pos_sales', JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem('shopify_pos_refunds', JSON.stringify(refunds));
  }, [refunds]);

  // Handle Online/Offline Status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const clockTimer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 10000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(clockTimer);
    };
  }, []);

  // Poll / Check Real Hardware Detection on Mount
  useEffect(() => {
    const checkHW = async () => {
      const status = await hardwareManager.checkRealDevices();
      setHardware(prev => ({
        ...prev,
        scannerConnected: status.scannerConnected,
        scannerName: status.scannerName,
        printerConnected: status.printerConnected,
        printerName: status.printerName
      }));
    };
    checkHW();
  }, []);

  // Clear thermal report print data after browser print dialog finishes
  useEffect(() => {
    const handleAfterPrint = () => {
      setThermalReportData(null);
    };
    window.addEventListener('afterprint', handleAfterPrint);
    return () => {
      window.removeEventListener('afterprint', handleAfterPrint);
    };
  }, []);

  // Helper to detect if any modal, alert, or navigation drawer is open
  const isAnyModalOpen = Boolean(
    showPinModal ||
    outOfStockProduct ||
    showAddProductModal ||
    showDiscountModal ||
    showCustomerModal ||
    showNewCustomerModal ||
    showEditCustomerModal ||
    viewingCustomerHistory ||
    showNoteModal ||
    showCheckoutModal ||
    showReceiptModal ||
    showRefundReceiptModal ||
    showQuickRefundModal ||
    lowStockAlerts.length > 0 ||
    deletingProductId ||
    viewingProductDetails ||
    isNavDrawerOpen
  );

  // Automatically focus the Register searchbar when on Register screen with no modals
  useEffect(() => {
    if (currentPage === 'register' && !isAnyModalOpen) {
      searchInputRef.current?.focus();
    }
  }, [currentPage, isAnyModalOpen]);

  // Global Automatic Typing & Barcode Scanner Listener
  // Automatically writes into the searchbar whenever typing or scanning on the Register page
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only active on Register screen and when no modal or drawer is open
      if (currentPage !== 'register' || isAnyModalOpen) return;

      const target = e.target as HTMLElement;
      const isInput = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);

      // Handle Enter (e.g. from Barcode scanner termination or manual Enter)
      if (e.key === 'Enter') {
        if (target === searchInputRef.current) return; // handled by input onKeyDown
        const code = searchQuery.trim() || barcodeBufferRef.current.trim();
        if (code) {
          handleProcessBarcode(code);
          setSearchQuery('');
          barcodeBufferRef.current = '';
          searchInputRef.current?.focus();
          e.preventDefault();
        }
        return;
      }

      // Handle Escape: clear search query
      if (e.key === 'Escape') {
        if (searchQuery) {
          setSearchQuery('');
          barcodeBufferRef.current = '';
          e.preventDefault();
        }
        return;
      }

      // If user is already focused directly in searchInput, let normal input onChange handle it,
      // but also buffer for fast scanner termination tracking
      if (target === searchInputRef.current) {
        if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
          barcodeBufferRef.current += e.key;
        }
        return;
      }

      // If user is focused inside another input/textarea, don't intercept
      if (isInput) return;

      // Ignore modifier combinations (Ctrl+C, Cmd+R, Alt+Tab, etc.)
      if (e.ctrlKey || e.metaKey || e.altKey) return;

      // Handle Backspace when not directly in input
      if (e.key === 'Backspace') {
        searchInputRef.current?.focus();
        setSearchQuery(prev => prev.slice(0, -1));
        barcodeBufferRef.current = barcodeBufferRef.current.slice(0, -1);
        e.preventDefault();
        return;
      }

      // Handle printable character: single character key (letters, digits, symbols)
      // Automatically focus searchbar and write character into it
      if (e.key.length === 1) {
        searchInputRef.current?.focus();
        setSearchQuery(prev => prev + e.key);
        barcodeBufferRef.current += e.key;
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, isAnyModalOpen, searchQuery, products]);

  // Audio helper
  const triggerSound = (type: 'beep' | 'success' | 'alert' | 'error') => {
    if (settings.soundEnabled) {
      playSound(type);
    }
  };

  // ----------------------------------------------------
  // Barcode Processing Logic
  // ----------------------------------------------------
  const handleProcessBarcode = (scannedCode: string) => {
    setHardware(prev => ({ ...prev, lastScannedBarcode: scannedCode }));
    const foundProduct = products.find(p => p.barcode === scannedCode || p.sku.toLowerCase() === scannedCode.toLowerCase());

    if (foundProduct) {
      // Check stock
      if (foundProduct.stock <= 0) {
        triggerSound('error');
        setOutOfStockProduct(foundProduct);
      } else {
        triggerSound('beep');
        addToCart(foundProduct);
      }
    } else {
      // Unrecognized Barcode Action: prompt to add new product pre-filled with this barcode!
      triggerSound('alert');
      setPrefilledBarcode(scannedCode);
      setShowAddProductModal(true);
    }
  };

  // ----------------------------------------------------
  // Cart Calculations
  // ----------------------------------------------------
  const cartSubtotal = useMemo(() => {
    return cart.reduce((sum, item) => {
      const price = item.customPrice ?? item.product.price;
      return sum + (price * item.quantity);
    }, 0);
  }, [cart]);

  const discountAmount = useMemo(() => {
    if (!cartDiscount) return 0;
    if (cartDiscount.type === 'percent') {
      return (cartSubtotal * cartDiscount.value) / 100;
    }
    return Math.min(cartDiscount.value, cartSubtotal);
  }, [cartSubtotal, cartDiscount]);

  const cartTax = useMemo(() => {
    const taxableSubtotal = Math.max(0, cartSubtotal - discountAmount);
    return taxableSubtotal * settings.taxRate;
  }, [cartSubtotal, discountAmount, settings.taxRate]);

  const cartTotal = useMemo(() => {
    return Math.max(0, cartSubtotal - discountAmount + cartTax);
  }, [cartSubtotal, discountAmount, cartTax]);

  const cartTotalItems = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // ----------------------------------------------------
  // Cart Actions
  // ----------------------------------------------------
  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      triggerSound('error');
      setOutOfStockProduct(product);
      return;
    }

    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        // Guard if already at max available stock
        if (existing.quantity >= product.stock) {
          triggerSound('alert');
          alert(`Cannot add more. Only ${product.stock} units of ${product.name} available in stock.`);
          return prev;
        }
        triggerSound('beep');
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        triggerSound('beep');
        return [...prev, { product, quantity: 1 }];
      }
    });
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) {
              return null; // Removes item cleanly when decreased to 0
            }
            if (newQty > item.product.stock) {
              triggerSound('alert');
              alert(`Only ${item.product.stock} units available in stock.`);
              return item;
            }
            return { ...item, quantity: newQty };
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const clearCart = () => {
    setCart([]);
    setSelectedCustomer(null);
    setCartDiscount(null);
    setOrderNote('');
  };

  // ----------------------------------------------------
  // Checkout & Sale Completion
  // ----------------------------------------------------
  const handleOpenCheckout = () => {
    if (cart.length === 0) return;
    setCashTendered(cartTotal.toFixed(2));
    setSplitCashAmount((cartTotal / 2).toFixed(2));
    setSplitCardAmount((cartTotal / 2).toFixed(2));
    setShowCheckoutModal(true);
  };

  const completeCheckout = () => {
    const cashVal = parseFloat(cashTendered) || 0;
    const change = Math.max(0, cashVal - cartTotal);

    const now = new Date();
    const dateCode = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const receiptNum = `REC-${dateCode}-${randSuffix}`;

    const newSale: Sale = {
      id: `sale-${Date.now()}`,
      receiptNumber: receiptNum,
      items: [...cart],
      subtotal: cartSubtotal,
      discountTotal: discountAmount,
      taxTotal: cartTax,
      total: cartTotal,
      paymentMethod: checkoutPaymentMethod,
      cashReceived: checkoutPaymentMethod === 'cash' ? cashVal : undefined,
      changeGiven: checkoutPaymentMethod === 'cash' ? change : undefined,
      cashAmount: checkoutPaymentMethod === 'split' ? parseFloat(splitCashAmount) || 0 : undefined,
      cardAmount: checkoutPaymentMethod === 'split' ? parseFloat(splitCardAmount) || 0 : undefined,
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer?.name,
      cashier: settings.cashierName,
      date: now.toISOString(),
      status: 'completed',
      note: orderNote
    };

    // Deduct stock from inventory and check low stock threshold
    const lowStockTriggered: { product: Product; stock: number }[] = [];
    const updatedProducts = products.map(prod => {
      const cartMatch = cart.find(ci => ci.product.id === prod.id);
      if (cartMatch) {
        const remainingStock = Math.max(0, prod.stock - cartMatch.quantity);
        if (remainingStock <= prod.lowStockThreshold) {
          lowStockTriggered.push({ product: prod, stock: remainingStock });
        }
        return { ...prod, stock: remainingStock };
      }
      return prod;
    });

    setProducts(updatedProducts);
    setSales(prev => [newSale, ...prev]);

    // Update customer stats if assigned
    if (selectedCustomer) {
      setCustomers(prev =>
        prev.map(c =>
          c.id === selectedCustomer.id
            ? { ...c, totalOrders: c.totalOrders + 1, totalSpent: c.totalSpent + cartTotal }
            : c
        )
      );
    }

    triggerSound('success');
    setLastSale(newSale);
    setShowCheckoutModal(false);
    clearCart();
    setShowReceiptModal(true);

    // If low stock triggered, queue the alert
    if (lowStockTriggered.length > 0) {
      setLowStockAlerts(lowStockTriggered);
    }
  };

  // ----------------------------------------------------
  // Navigation Handler with Inventory Security PIN
  // ----------------------------------------------------
  const handleNavClick = (page: NavPage) => {
    if (page === 'inventory') {
      if (!isInventoryUnlocked) {
        setPinInput('');
        setPinError('');
        setShowPinModal(true);
        return;
      }
    }
    setCurrentPage(page);
    setIsNavDrawerOpen(false);
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput === settings.inventoryPin) {
      triggerSound('success');
      setIsInventoryUnlocked(true);
      setShowPinModal(false);
      setCurrentPage('inventory');
      setIsNavDrawerOpen(false);
    } else {
      triggerSound('error');
      setPinError('Incorrect PIN. Default is 1111.');
      setPinInput('');
    }
  };

  // ----------------------------------------------------
  // Product CRUD (Inventory)
  // ----------------------------------------------------
  const handleSaveProduct = (prod: Product) => {
    if (editingProduct) {
      setProducts(prev => prev.map(p => p.id === prod.id ? prod : p));
    } else {
      setProducts(prev => [prod, ...prev]);
    }
    setShowAddProductModal(false);
    setEditingProduct(null);
    setPrefilledBarcode('');
    triggerSound('success');
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    setDeletingProductId(null);
    triggerSound('beep');
  };

  // ----------------------------------------------------
  // Refunds Logic
  // ----------------------------------------------------
  const handleStartRefundForSale = (sale: Sale) => {
    setSelectedSaleForRefund(sale);
    // Initialize quantities to 0
    const initialQtys: { [pId: string]: number } = {};
    sale.items.forEach(it => {
      initialQtys[it.product.id] = 0;
    });
    setRefundItemQuantities(initialQtys);
  };

  const handleSelectAllRefundItems = () => {
    if (!selectedSaleForRefund) return;
    const allQtys: { [pId: string]: number } = {};
    selectedSaleForRefund.items.forEach(it => {
      allQtys[it.product.id] = it.quantity;
    });
    setRefundItemQuantities(allQtys);
  };

  const handleOpenQuickRefund = () => {
    setSelectedSaleForRefund(null);
    if (selectedCustomer) {
      setQuickRefundSearch(selectedCustomer.name);
    } else {
      setQuickRefundSearch('');
    }
    setShowQuickRefundModal(true);
  };

  const handleProcessRefund = () => {
    if (!selectedSaleForRefund) return;

    const refundItemsList: { productId: string; productName: string; price: number; quantity: number; refundAmount: number }[] = [];
    let calculatedRefundTotal = 0;

    selectedSaleForRefund.items.forEach(it => {
      const qtyToRefund = refundItemQuantities[it.product.id] || 0;
      if (qtyToRefund > 0) {
        const unitPrice = it.customPrice ?? it.product.price;
        const lineRefund = unitPrice * qtyToRefund;
        calculatedRefundTotal += lineRefund;
        refundItemsList.push({
          productId: it.product.id,
          productName: it.product.name,
          price: unitPrice,
          quantity: qtyToRefund,
          refundAmount: lineRefund
        });
      }
    });

    if (refundItemsList.length === 0) {
      alert('Please select at least one item quantity to refund.');
      return;
    }

    // Add back into product inventory
    setProducts(prev =>
      prev.map(p => {
        const refundedMatch = refundItemsList.find(ri => ri.productId === p.id);
        if (refundedMatch) {
          return { ...p, stock: p.stock + refundedMatch.quantity };
        }
        return p;
      })
    );

    const refundRecord: Refund = {
      id: `refund-${Date.now()}`,
      refundNumber: `REF-${Date.now().toString().slice(-6)}`,
      originalSaleId: selectedSaleForRefund.id,
      receiptNumber: selectedSaleForRefund.receiptNumber,
      items: refundItemsList,
      totalRefunded: calculatedRefundTotal,
      reason: refundReason,
      date: new Date().toISOString(),
      cashier: settings.cashierName
    };

    setRefunds(prev => [refundRecord, ...prev]);

    // Update sale status
    setSales(prev =>
      prev.map(s => {
        if (s.id === selectedSaleForRefund.id) {
          return { ...s, status: 'refunded' };
        }
        return s;
      })
    );

    triggerSound('success');
    setLastRefund(refundRecord);
    setSelectedSaleForRefund(null);
    setShowQuickRefundModal(false);
    setShowRefundReceiptModal(true);
  };

  // ----------------------------------------------------
  // Filtered Products for Register
  // ----------------------------------------------------
  const productSalesVolume = useMemo(() => {
    const map: Record<string, number> = {};
    for (const sale of sales) {
      if (!sale.items) continue;
      for (const item of sale.items) {
        if (item.product?.id) {
          map[item.product.id] = (map[item.product.id] || 0) + (item.quantity || 1);
        }
      }
    }
    return map;
  }, [sales]);

  const categories = useMemo(() => {
    const set = new Set(products.map(p => p.category));
    return ['Most Selling', ...Array.from(set)];
  }, [products]);

  const filteredRegisterProducts = useMemo(() => {
    const list = products.filter(p => {
      const matchesCategory = selectedCategory === 'Most Selling' || p.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ||
        p.name.toLowerCase().includes(q) ||
        p.barcode.includes(q) ||
        p.sku.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });

    if (selectedCategory === 'Most Selling') {
      return [...list].sort((a, b) => {
        const salesA = productSalesVolume[a.id] || 0;
        const salesB = productSalesVolume[b.id] || 0;
        if (salesB !== salesA) {
          return salesB - salesA;
        }
        return a.name.localeCompare(b.name);
      });
    }

    return list;
  }, [products, selectedCategory, searchQuery, productSalesVolume]);

  // ----------------------------------------------------
  // Thermal Printing Actions (Sale Receipts & POS Reports)
  // ----------------------------------------------------
  const handlePrintReceipt = () => {
    setThermalReportData(null);
    setTimeout(() => {
      window.print();
    }, 30);
  };

  const handlePrintPOSReport = (type: 'weekly' | 'monthly') => {
    const now = Date.now();
    const days = type === 'weekly' ? 7 : 30;
    const cutoff = now - days * 24 * 60 * 60 * 1000;

    const relevantSales = sales.filter(s => new Date(s.date).getTime() >= cutoff);
    const relevantRefunds = refunds.filter(r => new Date(r.date).getTime() >= cutoff);

    const grossSales = relevantSales.reduce((acc, s) => acc + s.subtotal, 0);
    const totalTax = relevantSales.reduce((acc, s) => acc + s.taxTotal, 0);
    const totalDiscounts = relevantSales.reduce((acc, s) => acc + s.discountTotal, 0);
    const totalRefunded = relevantRefunds.reduce((acc, r) => acc + r.totalRefunded, 0);
    const netSales = grossSales - totalDiscounts - totalRefunded;
    const aov = relevantSales.length > 0 ? (grossSales / relevantSales.length) : 0;

    const cashSales = relevantSales.filter(s => s.paymentMethod === 'cash');
    const cardSales = relevantSales.filter(s => s.paymentMethod === 'card');
    const splitSales = relevantSales.filter(s => s.paymentMethod === 'split');

    const cashTotal = cashSales.reduce((sum, s) => sum + s.total, 0);
    const cardTotal = cardSales.reduce((sum, s) => sum + s.total, 0);
    const splitTotal = splitSales.reduce((sum, s) => sum + s.total, 0);

    const report: ThermalSalesReport = {
      type,
      title: type === 'weekly' ? 'WEEKLY SALES REPORT' : 'MONTHLY SALES REPORT',
      periodLabel: type === 'weekly' ? 'Past 7 Days' : 'Past 30 Days',
      startDate: new Date(cutoff).toLocaleDateString(),
      endDate: new Date(now).toLocaleDateString(),
      printedAt: new Date(now).toLocaleString(),
      totalOrders: relevantSales.length,
      grossSales,
      totalDiscounts,
      totalRefunded,
      totalTax,
      netSales,
      aov,
      cashCount: cashSales.length,
      cashTotal,
      cardCount: cardSales.length,
      cardTotal,
      splitCount: splitSales.length,
      splitTotal,
    };

    setThermalReportData(report);
    triggerSound('beep');

    // Give React a frame to update the printable DOM before launching window.print
    setTimeout(() => {
      window.print();
    }, 60);
  };

  // ----------------------------------------------------
  // Hardware Connection Handlers
  // ----------------------------------------------------
  const handleConnectScanner = async () => {
    const res = await hardwareManager.requestScannerConnection();
    if (res.success) {
      setHardware(prev => ({
        ...prev,
        scannerConnected: true,
        scannerName: res.name || 'Connected Scanner'
      }));
      setHardwarePairingMsg({ type: 'scanner', message: `Successfully connected ${res.name || 'Scanner'}!` });
      triggerSound('success');
    } else {
      setHardware(prev => ({
        ...prev,
        scannerConnected: false,
        scannerName: 'Disconnected'
      }));
      setHardwarePairingMsg({ type: 'scanner', message: res.error || 'Connection failed.', isError: true });
      triggerSound('error');
    }
  };

  const handleConnectPrinter = async () => {
    const res = await hardwareManager.requestPrinterConnection();
    if (res.success) {
      setHardware(prev => ({
        ...prev,
        printerConnected: true,
        printerName: res.name || 'Connected POS Printer'
      }));
      setHardwarePairingMsg({ type: 'printer', message: `Successfully paired ${res.name || 'Printer'}!` });
      triggerSound('success');
    } else {
      setHardware(prev => ({
        ...prev,
        printerConnected: false,
        printerName: 'Disconnected'
      }));
      setHardwarePairingMsg({ type: 'printer', message: res.error || 'Connection failed.', isError: true });
      triggerSound('error');
    }
  };

  // ----------------------------------------------------
  // Customer Edit & Delete Handlers
  // ----------------------------------------------------
  const handleOpenEditCustomer = (cust: Customer) => {
    setEditingCustomer(cust);
    setEditFormName(cust.name || '');
    setEditFormEmail(cust.email || '');
    setEditFormPhone(cust.phone || '');
    setEditFormNotes(cust.notes || '');
    setEditFormError('');
    setEditConfirmDelete(false);
    setShowEditCustomerModal(true);
    triggerSound('beep');
  };

  const handleSaveEditCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;
    const trimmedName = editFormName.trim();
    if (!trimmedName) {
      setEditFormError('Customer full name is required');
      triggerSound('error');
      return;
    }

    const updatedCustomer: Customer = {
      ...editingCustomer,
      name: trimmedName,
      email: editFormEmail.trim(),
      phone: editFormPhone.trim(),
      notes: editFormNotes.trim()
    };

    setCustomers(prev => prev.map(c => (c.id === updatedCustomer.id ? updatedCustomer : c)));

    // Keep active selected customer in sync if currently selected on register
    if (selectedCustomer?.id === updatedCustomer.id) {
      setSelectedCustomer(updatedCustomer);
    }

    setShowEditCustomerModal(false);
    setEditingCustomer(null);
    triggerSound('success');
  };

  const handleDeleteCustomer = () => {
    if (!editingCustomer) return;
    const targetId = editingCustomer.id;

    setCustomers(prev => prev.filter(c => c.id !== targetId));

    if (selectedCustomer?.id === targetId) {
      setSelectedCustomer(null);
    }

    setShowEditCustomerModal(false);
    setEditingCustomer(null);
    setEditConfirmDelete(false);
    triggerSound('alert');
  };

  // ----------------------------------------------------
  // Customer Purchase History Handlers & Helpers
  // ----------------------------------------------------
  const getCustomerSales = (cust: Customer | null): Sale[] => {
    if (!cust) return [];
    return sales.filter(s =>
      (s.customerId && s.customerId === cust.id) ||
      (s.customerName && s.customerName.toLowerCase().trim() === cust.name.toLowerCase().trim())
    );
  };

  const getCustomerPurchasedItems = (cust: Customer | null) => {
    if (!cust) return [];
    const custSales = getCustomerSales(cust);
    const itemMap = new Map<string, {
      product: Product;
      totalQuantity: number;
      totalSpent: number;
      lastDate: string;
      orderCount: number;
    }>();

    custSales.forEach(s => {
      s.items.forEach(it => {
        const pId = it.product.id;
        const lineTotal = (it.customPrice ?? it.product.price) * it.quantity;
        const existing = itemMap.get(pId);
        if (existing) {
          existing.totalQuantity += it.quantity;
          existing.totalSpent += lineTotal;
          existing.orderCount += 1;
          if (new Date(s.date).getTime() > new Date(existing.lastDate).getTime()) {
            existing.lastDate = s.date;
          }
        } else {
          itemMap.set(pId, {
            product: it.product,
            totalQuantity: it.quantity,
            totalSpent: lineTotal,
            lastDate: s.date,
            orderCount: 1
          });
        }
      });
    });

    return Array.from(itemMap.values()).sort((a, b) => b.totalQuantity - a.totalQuantity);
  };

  const handleOpenCustomerHistory = (cust: Customer) => {
    setViewingCustomerHistory(cust);
    setCustomerHistoryTab('items');
    triggerSound('beep');
  };

  const handleReorderProduct = (prod: Product, qty: number = 1) => {
    const currentStock = products.find(p => p.id === prod.id)?.stock ?? prod.stock;
    if (currentStock <= 0) {
      setOutOfStockProduct(prod);
      triggerSound('error');
      return;
    }
    setCart(prev => {
      const existing = prev.find(item => item.product.id === prod.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === prod.id
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      }
      return [...prev, { product: prod, quantity: qty }];
    });
    triggerSound('success');
  };

  const handleReorderSale = (sale: Sale) => {
    sale.items.forEach(it => {
      handleReorderProduct(it.product, it.quantity);
    });
    setCurrentPage('register');
    setViewingCustomerHistory(null);
    setShowEditCustomerModal(false);
    triggerSound('success');
  };

  const handlePrintPastSaleSlip = (sale: Sale) => {
    setThermalReportData(null);
    setLastSale(sale);
    setShowReceiptModal(true);
    triggerSound('beep');
  };

  // ----------------------------------------------------
  // Render Main Layout
  // ----------------------------------------------------
  return (
    <div className={`h-screen w-screen flex overflow-hidden select-none ${settings.theme === 'dark' ? 'dark bg-[#111213] text-[#e1e3e5]' : 'bg-[#f4f6f8] text-[#202223]'}`}>
      
      {/* ==================================================== */}
      {/* 1. SLIDE-OUT NAVIGATION DRAWER (TOGGLED VIA 3-LINE BUTTON) */}
      {/* ==================================================== */}
      {isNavDrawerOpen && (
        <div className="no-print fixed inset-0 z-50 flex justify-end">
          {/* Dimmed Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsNavDrawerOpen(false)}
          />

          {/* Drawer Container (Shopify Dark Charcoal / Slate) */}
          <aside className="relative w-80 max-w-[88vw] bg-[#1a1a1a] text-[#c9cccf] flex flex-col justify-between h-full shadow-2xl z-10 border-l border-[#2d2e30]">
            <div>
              {/* Brand & Store Header with Close Button */}
              <div className="h-16 px-5 flex items-center justify-between border-b border-[#2d2e30]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#008060] flex items-center justify-center text-white font-bold text-base shadow-sm">
                    S
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-sm font-semibold text-white tracking-tight truncate">
                      {settings.storeName}
                    </div>
                    <div className="text-xs text-[#8c9196] flex items-center gap-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-[#008060]' : 'bg-amber-500'}`} />
                      {isOnline ? 'Offline-Ready' : 'Working Offline'}
                    </div>
                  </div>
                </div>

                {/* Close Drawer Button */}
                <button
                  onClick={() => setIsNavDrawerOpen(false)}
                  className="p-1.5 text-[#8c9196] hover:text-white hover:bg-[#252628] rounded-lg transition-colors cursor-pointer"
                  title="Close Navigation"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Links */}
              <nav className="p-3 space-y-1">
                <button
                  onClick={() => handleNavClick('register')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'register'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <ShoppingBag className={`w-5 h-5 ${currentPage === 'register' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                  Register
                </button>

                <button
                  onClick={() => handleNavClick('inventory')}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'inventory'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Package className={`w-5 h-5 ${currentPage === 'inventory' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                    Inventory
                  </div>
                  {!isInventoryUnlocked && (
                    <Lock className="w-4 h-4 text-[#8c9196]" />
                  )}
                </button>

                <button
                  onClick={() => handleNavClick('reports')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'reports'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <BarChart3 className={`w-5 h-5 ${currentPage === 'reports' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                  Reports
                </button>

                <button
                  onClick={() => handleNavClick('customers')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'customers'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <Users className={`w-5 h-5 ${currentPage === 'customers' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                  Customers
                </button>

                <button
                  onClick={() => handleNavClick('refunds')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'refunds'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <RotateCcw className={`w-5 h-5 ${currentPage === 'refunds' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                  Refunds & Returns
                </button>

                <button
                  onClick={() => handleNavClick('settings')}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    currentPage === 'settings'
                      ? 'bg-[#2b2d30] text-white shadow-sm'
                      : 'text-[#c9cccf] hover:bg-[#232426] hover:text-white'
                  }`}
                >
                  <SettingsIcon className={`w-5 h-5 ${currentPage === 'settings' ? 'text-[#008060]' : 'text-[#8c9196]'}`} />
                  Settings
                </button>
              </nav>
            </div>

            {/* Real Hardware Status Indicator Bar at Bottom of Drawer */}
            <div className="p-3 border-t border-[#2d2e30] bg-[#141414] space-y-2 text-xs">
              <div className="px-1 text-[11px] font-semibold text-[#8c9196] uppercase tracking-wider">
                Connected Hardware
              </div>

              <div className="flex items-center justify-between px-2 py-1.5 rounded bg-[#1e1f21] border border-[#2c2d30]">
                <div className="flex items-center gap-2">
                  <QrCode className="w-3.5 h-3.5 text-[#8c9196]" />
                  <span className="text-[#c9cccf]">Scanner</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      hardware.scannerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'
                    }`}
                  />
                  <span className={`text-[11px] font-medium ${hardware.scannerConnected ? 'text-[#008060]' : 'text-[#8c9196]'}`}>
                    {hardware.scannerConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between px-2 py-1.5 rounded bg-[#1e1f21] border border-[#2c2d30]">
                <div className="flex items-center gap-2">
                  <Printer className="w-3.5 h-3.5 text-[#8c9196]" />
                  <span className="text-[#c9cccf]">Receipt Printer</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      hardware.printerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'
                    }`}
                  />
                  <span className={`text-[11px] font-medium ${hardware.printerConnected ? 'text-[#008060]' : 'text-[#8c9196]'}`}>
                    {hardware.printerConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>

              <div className="pt-1 px-1 flex items-center justify-between text-[#8c9196] text-[11px]">
                <span>Cashier: {settings.cashierName}</span>
                <span className="font-mono">{currentTime}</span>
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* ==================================================== */}
      {/* 2. MAIN APPLICATION CONTENT AREA (FULL SCREEN WIDTH) */}
      {/* ==================================================== */}
      <main className="no-print flex-1 flex flex-col h-full w-full overflow-hidden">
        
        {/* Top Header */}
        <header className="h-16 px-6 bg-white dark:bg-[#1a1a1a] border-b border-[#e1e3e5] dark:border-[#303030] flex items-center justify-between shrink-0 shadow-[0_1px_2px_0_rgba(0,0,0,0.03)]">
          <div className="flex items-center gap-3">
            {currentPage !== 'register' && (
              <button
                onClick={() => setCurrentPage('register')}
                className="p-1.5 -ml-1 text-[#6d7175] hover:text-[#202223] dark:hover:text-white rounded-lg hover:bg-[#f1f2f4] dark:hover:bg-[#252627] flex items-center gap-1 text-xs font-semibold transition-colors cursor-pointer"
                title="Back to Register"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Register</span>
              </button>
            )}

            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-[#008060] flex items-center justify-center text-white font-bold text-sm shadow-xs">
                S
              </div>
              <div>
                <h1 className="text-base font-bold text-[#202223] dark:text-white capitalize tracking-tight leading-none">
                  {currentPage === 'register' ? settings.storeName : currentPage === 'refunds' ? 'Returns & Exchanges' : currentPage}
                </h1>
                <span className="text-[10px] text-[#8c9196] font-medium">
                  {currentPage === 'register' ? 'Point of Sale' : settings.storeName}
                </span>
              </div>
            </div>

            {currentPage === 'inventory' && isInventoryUnlocked && (
              <span className="text-xs text-[#008060] bg-[#e3f1df] dark:bg-[#008060]/20 px-2.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> PIN Verified
              </span>
            )}
          </div>

          {/* Right Header Zone with Real Scanner Readout, Status Badges & 3-Line Menu Button */}
          <div className="flex items-center gap-3">
            {/* Real scanner last input readout badge */}
            {hardware.lastScannedBarcode && (
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-[#f1f2f4] dark:bg-[#242526] rounded text-xs text-[#6d7175] font-mono border border-[#e1e3e5] dark:border-[#303030]">
                <QrCode className="w-3.5 h-3.5 text-[#008060]" />
                <span>Last Scan: {hardware.lastScannedBarcode}</span>
              </div>
            )}

            {/* Hardware mini indicators */}
            <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 bg-[#f6f6f7] dark:bg-[#202123] rounded-lg border border-[#e1e3e5] dark:border-[#303030] text-[11px] text-[#6d7175] dark:text-[#a6acb2]">
              <div className="flex items-center gap-1">
                <span className={`w-1.5 h-1.5 rounded-full ${hardware.scannerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'}`} />
                <span>Scanner</span>
              </div>
              <span className="text-[#c9cccf]">·</span>
              <div className="flex items-center gap-1">
                <span className={`w-1.5 h-1.5 rounded-full ${hardware.printerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'}`} />
                <span>Printer</span>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-[#6d7175] dark:text-[#a6acb2] bg-[#f6f6f7] dark:bg-[#202123] px-3 py-1.5 rounded-lg border border-[#e1e3e5] dark:border-[#303030]">
              <Clock className="w-3.5 h-3.5 text-[#8c9196]" />
              <span>{currentTime}</span>
            </div>

            {/* ==================================================== */}
            {/* 3-LINE TOP RIGHT CORNER MENU BUTTON */}
            {/* ==================================================== */}
            <button
              onClick={() => setIsNavDrawerOpen(prev => !prev)}
              className={`p-2 rounded-lg border transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center ${
                isNavDrawerOpen
                  ? 'bg-[#202223] text-white border-[#202223] dark:bg-white dark:text-[#202223]'
                  : 'bg-[#f6f6f7] dark:bg-[#202123] hover:bg-[#e4e5e7] dark:hover:bg-[#2b2c2e] text-[#202223] dark:text-white border-[#e1e3e5] dark:border-[#303030]'
              }`}
              title="Navigation Menu"
              aria-label="Toggle Navigation Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Page Content Switcher */}
        <div className="flex-1 overflow-hidden">
          {currentPage === 'register' && renderRegisterScreen()}
          {currentPage === 'inventory' && renderInventoryScreen()}
          {currentPage === 'reports' && renderReportsScreen()}
          {currentPage === 'customers' && renderCustomersScreen()}
          {currentPage === 'refunds' && renderRefundsScreen()}
          {currentPage === 'settings' && renderSettingsScreen()}
        </div>
      </main>

      {/* ==================================================== */}
      {/* 3. THERMAL RECEIPT & REPORT CONTAINER (Printable via @media print) */}
      {/* ==================================================== */}
      <div
        id="thermal-receipt-area"
        className={`print-only ${settings.paperWidth === '58mm' ? 'width-58mm' : 'width-80mm'}`}
      >
        {thermalReportData
          ? renderPrintableThermalSalesReport(thermalReportData)
          : renderPrintableThermalReceipt(lastSale || sales[0])}
      </div>

      {/* ==================================================== */}
      {/* 4. MODALS & POP-UPS */}
      {/* ==================================================== */}
      {showPinModal && renderPinModal()}
      {outOfStockProduct && renderOutOfStockModal()}
      {showAddProductModal && renderAddProductModal()}
      {showDiscountModal && renderDiscountModal()}
      {showCustomerModal && renderCustomerModal()}
      {showNewCustomerModal && renderNewCustomerModal()}
      {showEditCustomerModal && editingCustomer && renderEditCustomerModal()}
      {viewingCustomerHistory && renderCustomerHistoryModal()}
      {showNoteModal && renderNoteModal()}
      {showCheckoutModal && renderCheckoutModal()}
      {showReceiptModal && renderPostSaleReceiptModal()}
      {showRefundReceiptModal && renderRefundReceiptModal()}
      {showQuickRefundModal && renderQuickRefundModal()}
      {lowStockAlerts.length > 0 && renderLowStockAlertModal()}
      {deletingProductId && renderDeleteConfirmationModal()}
      {viewingProductDetails && renderProductDetailsModal()}
    </div>
  );

  // ====================================================
  // SCREEN: REGISTER (SHOPIFY POS LAYOUT)
  // ====================================================
  function renderRegisterScreen() {
    return (
      <div className="h-full flex overflow-hidden">
        {/* Left Side: Product Catalog & Search */}
        <div className="flex-1 flex flex-col h-full overflow-hidden border-r border-[#e1e3e5] dark:border-[#303030]">
          
          {/* Search & Barcode Scan Bar */}
          <div className="p-4 bg-white dark:bg-[#1a1a1a] border-b border-[#e1e3e5] dark:border-[#303030]">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-[#8c9196] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder="Search products or scan barcode (UPC / SKU)..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    if (searchQuery.trim()) {
                      handleProcessBarcode(searchQuery.trim());
                      setSearchQuery('');
                    }
                  }
                }}
                className="w-full pl-10 pr-10 py-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#008060] focus:border-[#008060] transition-all shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8c9196] hover:text-[#202223]"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Category Filter Pills (Shopify Segmented Style) */}
          <div className="px-4 py-2.5 bg-[#fafbfb] dark:bg-[#161718] border-b border-[#e1e3e5] dark:border-[#303030] flex items-center gap-2 overflow-x-auto no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#202223] text-white dark:bg-white dark:text-[#202223] shadow-sm'
                    : 'bg-white dark:bg-[#202123] text-[#5c5f62] dark:text-[#a6acb2] border border-[#e1e3e5] dark:border-[#303030] hover:border-[#8c9196]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="flex-1 p-4 overflow-y-auto">
            {filteredRegisterProducts.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-[#6d7175]">
                <Package className="w-12 h-12 text-[#c9cccf] mb-2" />
                <p className="font-semibold text-sm">No products matched "{searchQuery}"</p>
                <p className="text-xs text-[#8c9196] mt-1">Try another category, SKU, or add a new product</p>
                <button
                  onClick={() => {
                    setPrefilledBarcode(searchQuery);
                    setShowAddProductModal(true);
                  }}
                  className="mt-4 px-4 py-2 bg-[#008060] text-white text-xs font-semibold rounded-lg hover:bg-[#006e52] transition-colors"
                >
                  Create Product "{searchQuery}"
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3.5">
                {filteredRegisterProducts.map(prod => {
                  const isOutOfStock = prod.stock <= 0;
                  const isLowStock = prod.stock > 0 && prod.stock <= prod.lowStockThreshold;

                  return (
                    <div
                      key={prod.id}
                      onClick={() => addToCart(prod)}
                      className={`group relative bg-white dark:bg-[#1e1f20] border rounded-[8px] p-3 flex flex-col justify-between cursor-pointer transition-all duration-150 active:scale-[0.98] ${
                        isOutOfStock
                          ? 'border-dashed border-[#d2d5d8] dark:border-[#3b3c3e] opacity-75 hover:border-[#8c9196]'
                          : 'border-[#e1e3e5] dark:border-[#303030] hover:border-[#008060] hover:shadow-[0_2px_8px_rgba(0,0,0,0.06)]'
                      }`}
                    >
                      {/* Product Visual Container */}
                      <div className="relative w-full aspect-square rounded-md overflow-hidden bg-[#f4f6f8] dark:bg-[#252627] mb-2.5 flex items-center justify-center">
                        {prod.image ? (
                          <img
                            src={prod.image}
                            alt={prod.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            onError={(e) => {
                              // Fallback container if broken
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          <Package className="w-8 h-8 text-[#8c9196]" />
                        )}

                        {/* Stock Tag on Card */}
                        <div className="absolute top-2 right-2">
                          {isOutOfStock ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#fee8e7] text-[#c01507] border border-[#f5b8b5]">
                              Out of Stock
                            </span>
                          ) : isLowStock ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#fff5ea] text-[#914d00] border border-[#ffe0b2]">
                              {prod.stock} left
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-white/90 dark:bg-black/70 text-[#202223] dark:text-white backdrop-blur-xs">
                              {prod.stock} in stock
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Product Info */}
                      <div>
                        <div className="text-[11px] font-medium text-[#6d7175] dark:text-[#999ea4] truncate">
                          {prod.category}
                        </div>
                        <h3 className="text-xs font-semibold text-[#202223] dark:text-white line-clamp-2 mt-0.5 min-h-[32px] leading-tight">
                          {prod.name}
                        </h3>
                      </div>

                      {/* Price & SKU */}
                      <div className="mt-2.5 pt-2 border-t border-[#f1f2f4] dark:border-[#2a2b2d] flex items-center justify-between">
                        <span className="text-[11px] font-mono text-[#8c9196]">{prod.sku}</span>
                        <span className="text-sm font-bold font-mono text-[#202223] dark:text-white">
                          {settings.currencySymbol}{prod.price.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* ==================================================== */}
        {/* Right Side: SHOPIFY POS CART & TRANSACTION DRAWER */}
        {/* ==================================================== */}
        <div className="w-96 bg-white dark:bg-[#1a1a1a] flex flex-col h-full border-l border-[#e1e3e5] dark:border-[#303030] shrink-0 shadow-[-2px_0_6px_rgba(0,0,0,0.02)]">
          
          {/* Cart Header & Customer Assignment */}
          <div className="p-4 border-b border-[#e1e3e5] dark:border-[#303030] flex items-center justify-between bg-[#fafbfb] dark:bg-[#161718]">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#008060]" />
              <span className="text-sm font-bold text-[#202223] dark:text-white">Current Sale</span>
              <span className="text-xs font-semibold px-2 py-0.5 bg-[#f1f2f4] dark:bg-[#2b2c2e] rounded-full text-[#5c5f62] dark:text-[#a6acb2]">
                {cartTotalItems}
              </span>
            </div>

            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs font-medium text-[#c01507] hover:underline"
              >
                Clear Cart
              </button>
            )}
          </div>

          {/* Customer & Refund Bar (Customer ~3/4, Refund ~1/4) */}
          <div className="px-3.5 py-2 border-b border-[#e1e3e5] dark:border-[#303030] flex items-center gap-2 bg-white dark:bg-[#1a1a1a]">
            {/* Customer Section (3/4 width) */}
            <div className="flex-[3] min-w-0">
              {selectedCustomer ? (
                <div className="flex items-center justify-between w-full px-2.5 py-1.5 bg-[#f6f6f7] dark:bg-[#242526] rounded-lg border border-[#e1e3e5] dark:border-[#303030] group">
                  <div
                    onClick={() => handleOpenEditCustomer(selectedCustomer)}
                    className="flex items-center gap-2 overflow-hidden min-w-0 cursor-pointer hover:opacity-85 transition-opacity"
                    title="Click to view or edit customer profile"
                  >
                    <div className="w-6 h-6 rounded-full bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5] font-bold text-[11px] flex items-center justify-center shrink-0">
                      {selectedCustomer.name[0]}
                    </div>
                    <div className="overflow-hidden min-w-0">
                      <p className="text-xs font-semibold text-[#202223] dark:text-white truncate flex items-center gap-1.5">
                        <span className="truncate">{selectedCustomer.name}</span>
                        <Edit className="w-2.5 h-2.5 text-[#8c9196] group-hover:text-[#008060] shrink-0" />
                      </p>
                      <p className="text-[10px] text-[#8c9196] truncate">{selectedCustomer.email || selectedCustomer.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-0.5 shrink-0 ml-1">
                    <button
                      onClick={() => handleOpenCustomerHistory(selectedCustomer)}
                      title={`View ${selectedCustomer.name}'s purchase history`}
                      className="p-1 text-[#8c9196] hover:text-[#008060] hover:bg-[#e3f1df]/60 dark:hover:bg-[#004e38]/50 rounded-md transition-colors"
                    >
                      <Clock className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleOpenEditCustomer(selectedCustomer)}
                      title="Edit Customer Details"
                      className="p-1 text-[#8c9196] hover:text-[#008060] hover:bg-[#e3f1df]/60 dark:hover:bg-[#004e38]/50 rounded-md transition-colors"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setSelectedCustomer(null)}
                      title="Remove Customer from Sale"
                      className="text-xs text-[#8c9196] hover:text-[#c01507] p-1 rounded-md transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowCustomerModal(true)}
                  className="w-full py-2 px-2.5 border border-dashed border-[#c9cccf] dark:border-[#3b3c3e] rounded-lg text-xs font-medium text-[#5c5f62] dark:text-[#a6acb2] hover:border-[#008060] hover:text-[#008060] flex items-center justify-center gap-1.5 transition-colors truncate shadow-2xs"
                >
                  <Users className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">+ Add Customer</span>
                </button>
              )}
            </div>

            {/* Refund Action Button (1/4 width) */}
            <button
              onClick={handleOpenQuickRefund}
              title="Quick Return & Refund (in register)"
              className="flex-1 min-w-[70px] py-2 px-2 border border-[#d2d5d8] dark:border-[#3b3c3e] hover:border-[#c01507] dark:hover:border-[#c01507] rounded-lg text-xs font-medium text-[#5c5f62] dark:text-[#a6acb2] hover:text-[#c01507] hover:bg-[#fee8e7]/30 dark:hover:bg-[#3d1a19]/30 flex items-center justify-center gap-1.5 transition-colors cursor-pointer group shadow-2xs"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0 text-[#8c9196] group-hover:text-[#c01507] transition-colors" />
              <span className="font-semibold text-xs truncate">Refund</span>
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#8c9196]">
                <ShoppingBag className="w-12 h-12 text-[#dfe3e8] dark:text-[#333] mb-2" />
                <p className="text-sm font-semibold text-[#5c5f62] dark:text-[#a6acb2]">Cart is empty</p>
                <p className="text-xs mt-1">Tap products or scan barcodes to begin sale</p>
              </div>
            ) : (
              cart.map(item => {
                const unitPrice = item.customPrice ?? item.product.price;
                const lineTotal = unitPrice * item.quantity;

                return (
                  <div
                    key={item.product.id}
                    className="p-3 bg-[#fafbfb] dark:bg-[#202123] border border-[#e1e3e5] dark:border-[#2e3032] rounded-[8px] flex flex-col gap-2 transition-all"
                  >
                    {/* Item row header: Title and Line Total */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold text-[#202223] dark:text-white truncate">
                          {item.product.name}
                        </h4>
                        <span className="text-[11px] text-[#6d7175] dark:text-[#999ea4] font-mono">
                          {settings.currencySymbol}{unitPrice.toFixed(2)} each
                        </span>
                      </div>
                      <div className="text-xs font-bold font-mono text-[#202223] dark:text-white shrink-0">
                        {settings.currencySymbol}{lineTotal.toFixed(2)}
                      </div>
                    </div>

                    {/* Quantity Stepper (MANDATORY: NO individual trash delete button!) */}
                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center border border-[#d2d5d8] dark:border-[#383a3c] rounded-md bg-white dark:bg-[#1a1a1a] overflow-hidden">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, -1)}
                          className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c] text-[#5c5f62] dark:text-[#a6acb2] active:bg-[#e4e5e7]"
                          title="Decrease quantity (reduces to 0 removes)"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-8 text-center text-xs font-bold font-mono text-[#202223] dark:text-white">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, 1)}
                          className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c] text-[#5c5f62] dark:text-[#a6acb2] active:bg-[#e4e5e7]"
                          title="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="text-[11px] text-[#8c9196]">
                        {item.product.stock - item.quantity} in inventory
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Cart Summary & Actions */}
          {cart.length > 0 && (
            <div className="p-4 bg-[#fafbfb] dark:bg-[#161718] border-t border-[#e1e3e5] dark:border-[#303030] space-y-3 shrink-0">
              
              {/* Distinct Shopify-Blue "Add Discount" Button */}
              <div className="flex items-center justify-between text-xs">
                <button
                  onClick={() => setShowDiscountModal(true)}
                  className="font-semibold text-[#005bd3] hover:text-[#004bb0] dark:text-[#3f88e8] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Tag className="w-3.5 h-3.5" />
                  <span>{cartDiscount ? `Discount (${cartDiscount.type === 'percent' ? `${cartDiscount.value}%` : `$${cartDiscount.value}`})` : 'Add Discount'}</span>
                </button>

                <button
                  onClick={() => setShowNoteModal(true)}
                  className="text-[#6d7175] hover:text-[#202223] dark:hover:text-white text-xs font-medium"
                >
                  {orderNote ? 'Edit Note' : '+ Order Note'}
                </button>
              </div>

              {/* Subtotal, Discount & Tax breakdown */}
              <div className="space-y-1 text-xs border-t border-b border-[#e1e3e5] dark:border-[#2e3032] py-2">
                <div className="flex justify-between text-[#6d7175] dark:text-[#a6acb2]">
                  <span>Subtotal</span>
                  <span className="font-mono">{settings.currencySymbol}{cartSubtotal.toFixed(2)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-[#005bd3] dark:text-[#3f88e8] font-medium">
                    <span>Discount</span>
                    <span className="font-mono">-{settings.currencySymbol}{discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#6d7175] dark:text-[#a6acb2]">
                  <span>Estimated Tax ({(settings.taxRate * 100).toFixed(2)}%)</span>
                  <span className="font-mono">{settings.currencySymbol}{cartTax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-[#202223] dark:text-white pt-1">
                  <span>Total</span>
                  <span className="font-mono text-base">{settings.currencySymbol}{cartTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Primary Charge CTA Button */}
              <button
                onClick={handleOpenCheckout}
                className="w-full py-3.5 bg-[#008060] hover:bg-[#006e52] active:bg-[#005c44] text-white font-bold text-sm rounded-[8px] shadow-[0_1px_3px_rgba(0,0,0,0.1)] flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Charge</span>
                <span className="font-mono">{settings.currencySymbol}{cartTotal.toFixed(2)}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ====================================================
  // SCREEN: INVENTORY (PIN PROTECTED & FULL CRUD)
  // ====================================================
  function renderInventoryScreen() {
    const filteredInventory = products.filter(p => {
      const matchesCat = inventoryCategoryFilter === 'All' || p.category === inventoryCategoryFilter;
      const q = inventorySearch.toLowerCase().trim();
      const matchesSearch = !q ||
        p.name.toLowerCase().includes(q) ||
        p.barcode.includes(q) ||
        p.sku.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });

    const totalStockCount = products.reduce((sum, p) => sum + p.stock, 0);
    const lowStockCount = products.filter(p => p.stock > 0 && p.stock <= p.lowStockThreshold).length;
    const outOfStockCount = products.filter(p => p.stock <= 0).length;
    const totalInventoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);

    return (
      <div className="h-full flex flex-col overflow-hidden p-6 bg-[#f4f6f8] dark:bg-[#111213]">
        {/* KPI Strip */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-white dark:bg-[#1a1a1a] p-4 rounded-[8px] border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
            <p className="text-xs font-bold text-[#303030] dark:text-[#c9cccf]">Total Products</p>
            <p className="text-xl font-bold font-mono text-[#111213] dark:text-white mt-1">{products.length} SKUs</p>
          </div>
          <div className="bg-white dark:bg-[#1a1a1a] p-4 rounded-[8px] border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
            <p className="text-xs font-bold text-[#303030] dark:text-[#c9cccf]">Units In Stock</p>
            <p className="text-xl font-bold font-mono text-[#111213] dark:text-white mt-1">{totalStockCount} units</p>
          </div>
          <div className="bg-white dark:bg-[#1a1a1a] p-4 rounded-[8px] border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
            <p className="text-xs font-bold text-[#703b00] dark:text-[#f49342]">Low / Out of Stock</p>
            <p className="text-xl font-bold font-mono text-[#111213] dark:text-white mt-1">{lowStockCount + outOfStockCount} items</p>
          </div>
          <div className="bg-white dark:bg-[#1a1a1a] p-4 rounded-[8px] border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
            <p className="text-xs font-bold text-[#006045] dark:text-[#38d39f]">Retail Inventory Value</p>
            <p className="text-xl font-bold font-mono text-[#008060] dark:text-[#2ecc71] mt-1">{settings.currencySymbol}{totalInventoryValue.toFixed(2)}</p>
          </div>
        </div>

        {/* Toolbar: Search, Filters & Add Product */}
        <div className="bg-white dark:bg-[#1a1a1a] p-4 rounded-t-[8px] border border-b-0 border-[#c9cccf] dark:border-[#383a3c] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-[280px]">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#5c5f62] dark:text-[#b4b8bc] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search inventory by title, SKU, barcode..."
                value={inventorySearch}
                onChange={e => setInventorySearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-xs bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-[#008060] shadow-xs"
              />
            </div>

            <select
              value={inventoryCategoryFilter}
              onChange={e => setInventoryCategoryFilter(e.target.value)}
              className="py-2.5 px-3 text-xs bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] rounded-lg font-semibold text-[#111213] dark:text-white cursor-pointer shadow-xs"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => exportInventoryXLSX(products, settings.storeName)}
              className="px-3.5 py-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#202223] dark:text-[#e1e3e5] hover:text-[#008060] text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-[#008060]" />
              <span>Export .xlsx</span>
            </button>

            <button
              onClick={() => {
                setEditingProduct(null);
                setPrefilledBarcode('');
                setShowAddProductModal(true);
              }}
              className="px-4 py-2.5 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Product</span>
            </button>
          </div>
        </div>

        {/* Inventory Data Table */}
        <div className="flex-1 bg-white dark:bg-[#1a1a1a] rounded-b-[8px] border border-[#c9cccf] dark:border-[#383a3c] overflow-y-auto shadow-xs">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f1f2f4] dark:bg-[#202123] border-b border-[#c9cccf] dark:border-[#404245] sticky top-0 z-10 text-[#111213] dark:text-[#f1f2f4]">
              <tr>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-[#202223] dark:text-[#f1f2f4]">Product Details</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-[#202223] dark:text-[#f1f2f4]">SKU / Barcode</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-[#202223] dark:text-[#f1f2f4]">Category</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-right text-[#202223] dark:text-[#f1f2f4]">Price</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-right text-[#202223] dark:text-[#f1f2f4]">Cost</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-center text-[#202223] dark:text-[#f1f2f4]">Stock Level</th>
                <th className="py-3 px-4 font-bold text-xs uppercase tracking-wider text-right text-[#202223] dark:text-[#f1f2f4]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e1e3e5] dark:divide-[#2e3032]">
              {filteredInventory.map(item => {
                const isOut = item.stock <= 0;
                const isLow = item.stock > 0 && item.stock <= item.lowStockThreshold;

                return (
                  <tr
                    key={item.id}
                    onClick={() => setViewingProductDetails(item)}
                    className="hover:bg-[#f6f6f7] dark:hover:bg-[#202123] transition-colors group cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded bg-[#f4f6f8] dark:bg-[#252627] flex items-center justify-center overflow-hidden shrink-0 border border-[#c9cccf] dark:border-[#383a3c]">
                          {item.image ? (
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                          ) : (
                            <Package className="w-5 h-5 text-[#5c5f62] dark:text-[#b4b8bc]" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-sm text-[#111213] dark:text-white group-hover:text-[#008060] transition-colors truncate max-w-xs">{item.name}</p>
                          <p className="text-xs text-[#5c5f62] dark:text-[#c9cccf] truncate font-medium mt-0.5">{item.description || 'Tap to view product details'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <div className="text-xs font-bold text-[#111213] dark:text-white">{item.sku}</div>
                      <div className="text-xs text-[#5c5f62] dark:text-[#b4b8bc] mt-0.5">{item.barcode}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-block px-2 py-0.5 rounded text-xs font-semibold bg-[#f1f2f4] dark:bg-[#2a2b2d] text-[#202223] dark:text-[#f1f2f4] border border-[#d2d5d8] dark:border-[#383a3c]">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-sm text-[#111213] dark:text-white">
                      {settings.currencySymbol}{item.price.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-xs text-[#5c5f62] dark:text-[#c9cccf]">
                      {settings.currencySymbol}{item.cost.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold font-mono ${
                        isOut
                          ? 'bg-[#fee8e7] text-[#900b00] border border-[#f5b8b5]'
                          : isLow
                          ? 'bg-[#fff5ea] text-[#703b00] border border-[#fed699]'
                          : 'bg-[#e3f1df] text-[#006045] border border-[#b7e2b1]'
                      }`}>
                        {item.stock} in stock
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right" onClick={e => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setViewingProductDetails(item)}
                          className="p-1.5 text-[#202223] dark:text-[#e1e3e5] hover:text-[#008060] hover:bg-[#e4e5e7] dark:hover:bg-[#2b2c2e] rounded transition-colors"
                          title="View product details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setEditingProduct(item);
                            setShowAddProductModal(true);
                          }}
                          className="p-1.5 text-[#202223] dark:text-[#e1e3e5] hover:text-[#008060] hover:bg-[#e4e5e7] dark:hover:bg-[#2b2c2e] rounded transition-colors"
                          title="Edit product"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletingProductId(item.id)}
                          className="p-1.5 text-[#202223] dark:text-[#e1e3e5] hover:text-[#c01507] hover:bg-[#fee8e7] dark:hover:bg-[#3d1a19] rounded transition-colors"
                          title="Delete product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ====================================================
  // SCREEN: REPORTS (EXECUTIVE METRICS & PDF DOWNLOADS)
  // ====================================================
  function renderReportsScreen() {
    // Filter sales based on selected range
    const now = Date.now();
    const cutoff = reportDateRange === 'today'
      ? now - 24 * 60 * 60 * 1000
      : reportDateRange === 'week'
      ? now - 7 * 24 * 60 * 60 * 1000
      : reportDateRange === 'month'
      ? now - 30 * 24 * 60 * 60 * 1000
      : 0;

    const relevantSales = sales.filter(s => new Date(s.date).getTime() >= cutoff);
    const relevantRefunds = refunds.filter(r => new Date(r.date).getTime() >= cutoff);

    const grossSales = relevantSales.reduce((acc, s) => acc + s.subtotal, 0);
    const totalTax = relevantSales.reduce((acc, s) => acc + s.taxTotal, 0);
    const totalDiscounts = relevantSales.reduce((acc, s) => acc + s.discountTotal, 0);
    const totalRefunded = relevantRefunds.reduce((acc, r) => acc + r.totalRefunded, 0);
    const netSales = grossSales - totalDiscounts - totalRefunded;
    const aov = relevantSales.length > 0 ? (grossSales / relevantSales.length) : 0;

    // Payment breakdown
    const cashTotal = relevantSales.filter(s => s.paymentMethod === 'cash').reduce((sum, s) => sum + s.total, 0);
    const cardTotal = relevantSales.filter(s => s.paymentMethod === 'card').reduce((sum, s) => sum + s.total, 0);
    const splitTotal = relevantSales.filter(s => s.paymentMethod === 'split').reduce((sum, s) => sum + s.total, 0);

    // Top selling products aggregation
    const productStats: { [name: string]: { name: string; qty: number; revenue: number } } = {};
    relevantSales.forEach(s => {
      s.items.forEach(it => {
        if (!productStats[it.product.name]) {
          productStats[it.product.name] = { name: it.product.name, qty: 0, revenue: 0 };
        }
        productStats[it.product.name].qty += it.quantity;
        productStats[it.product.name].revenue += (it.customPrice ?? it.product.price) * it.quantity;
      });
    });

    const topSelling = Object.values(productStats).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

    return (
      <div className="h-full overflow-y-auto p-6 bg-[#f4f6f8] dark:bg-[#111213] space-y-6">
        {/* Top Controls: Filter Range & PDF Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-[#1a1a1a] p-4 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
          <div className="flex items-center gap-1.5 p-1 bg-[#f1f2f4] dark:bg-[#242526] rounded-lg">
            {(['today', 'week', 'month', 'all'] as const).map(range => (
              <button
                key={range}
                onClick={() => setReportDateRange(range)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md capitalize transition-all ${
                  reportDateRange === range
                    ? 'bg-white dark:bg-[#1a1a1a] text-[#202223] dark:text-white shadow-xs'
                    : 'text-[#6d7175] hover:text-[#202223]'
                }`}
              >
                {range === 'all' ? 'All Time' : range === 'today' ? 'Today' : `Past ${range}`}
              </button>
            ))}
          </div>

          {/* ACTION CONTROLS: POS THERMAL PRINTING & PDF EXPORTS */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Paper Roll Width Toggle (80mm vs 58mm) */}
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#f1f2f4] dark:bg-[#242526] rounded-lg border border-[#e1e3e5] dark:border-[#333]">
              <span className="text-[11px] font-medium text-[#6d7175]">POS Paper:</span>
              {(['80mm', '58mm'] as const).map(w => (
                <button
                  key={w}
                  onClick={() => {
                    setSettings(prev => ({ ...prev, paperWidth: w }));
                    triggerSound('beep');
                  }}
                  className={`px-2 py-0.5 text-[11px] font-semibold rounded cursor-pointer transition-all ${
                    settings.paperWidth === w
                      ? 'bg-[#008060] text-white shadow-xs'
                      : 'text-[#6d7175] hover:text-[#202223] dark:hover:text-white'
                  }`}
                  title={`Switch thermal printer roll width to ${w}`}
                >
                  {w}
                </button>
              ))}
            </div>

            {/* Print Weekly to POS Printer */}
            <button
              onClick={() => handlePrintPOSReport('weekly')}
              className="px-3.5 py-2 bg-[#202223] dark:bg-[#28292b] hover:bg-[#333] text-white text-xs font-semibold rounded-lg flex items-center gap-2 shadow-xs transition-colors cursor-pointer border border-[#3b3c3e]"
              title="Instantly print weekly sales report to POS receipt printer"
            >
              <Printer className="w-4 h-4 text-[#008060]" />
              <span>Print Weekly (POS)</span>
            </button>

            {/* Print Monthly to POS Printer */}
            <button
              onClick={() => handlePrintPOSReport('monthly')}
              className="px-3.5 py-2 bg-[#202223] dark:bg-[#28292b] hover:bg-[#333] text-white text-xs font-semibold rounded-lg flex items-center gap-2 shadow-xs transition-colors cursor-pointer border border-[#3b3c3e]"
              title="Instantly print monthly sales report to POS receipt printer"
            >
              <Printer className="w-4 h-4 text-[#008060]" />
              <span>Print Monthly (POS)</span>
            </button>

            {/* PDF Report Downloads */}
            <button
              onClick={() => generateSalesReportPDF('weekly', sales, refunds, settings)}
              className="px-3 py-2 bg-[#f1f2f4] dark:bg-[#202123] hover:bg-[#e4e5e7] dark:hover:bg-[#2b2c2e] text-[#202223] dark:text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 border border-[#c9cccf] dark:border-[#3b3c3e] transition-colors cursor-pointer"
              title="Download 7-day sales PDF report"
            >
              <FileDown className="w-3.5 h-3.5 text-[#6d7175]" />
              <span>Weekly (PDF)</span>
            </button>

            <button
              onClick={() => generateSalesReportPDF('monthly', sales, refunds, settings)}
              className="px-3 py-2 bg-[#f1f2f4] dark:bg-[#202123] hover:bg-[#e4e5e7] dark:hover:bg-[#2b2c2e] text-[#202223] dark:text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 border border-[#c9cccf] dark:border-[#3b3c3e] transition-colors cursor-pointer"
              title="Download 30-day sales PDF report"
            >
              <FileDown className="w-3.5 h-3.5 text-[#6d7175]" />
              <span>Monthly (PDF)</span>
            </button>
          </div>
        </div>

        {/* Clean Sales Summary Cards (NO RAW TRANSACTION LOG CLUTTER!) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <span className="text-xs font-semibold text-[#6d7175]">Gross Merchandise Sales</span>
            <div className="text-2xl font-bold font-mono text-[#202223] dark:text-white mt-1">
              {settings.currencySymbol}{grossSales.toFixed(2)}
            </div>
            <div className="text-[11px] text-[#8c9196] mt-1">Total value of items ordered</div>
          </div>

          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <span className="text-xs font-semibold text-[#008060]">Net Revenue</span>
            <div className="text-2xl font-bold font-mono text-[#008060] mt-1">
              {settings.currencySymbol}{netSales.toFixed(2)}
            </div>
            <div className="text-[11px] text-[#8c9196] mt-1">After discounts & processed returns</div>
          </div>

          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <span className="text-xs font-semibold text-[#6d7175]">Total Transactions</span>
            <div className="text-2xl font-bold font-mono text-[#202223] dark:text-white mt-1">
              {relevantSales.length} orders
            </div>
            <div className="text-[11px] text-[#8c9196] mt-1">Completed at store register</div>
          </div>

          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <span className="text-xs font-semibold text-[#6d7175]">Average Order Value (AOV)</span>
            <div className="text-2xl font-bold font-mono text-[#202223] dark:text-white mt-1">
              {settings.currencySymbol}{aov.toFixed(2)}
            </div>
            <div className="text-[11px] text-[#8c9196] mt-1">Per transaction basket average</div>
          </div>
        </div>

        {/* Revenue Statement & Payment Distribution Grids */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Statement Card */}
          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <h3 className="text-sm font-bold text-[#202223] dark:text-white mb-4">Financial Statement Reconciliation</h3>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#6d7175]">Gross Product Sales</span>
                <span className="font-mono font-semibold text-[#202223] dark:text-white">{settings.currencySymbol}{grossSales.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#005bd3]">Cart & Line Discounts</span>
                <span className="font-mono font-semibold text-[#005bd3]">-{settings.currencySymbol}{totalDiscounts.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#c01507]">Returns & Refunds</span>
                <span className="font-mono font-semibold text-[#c01507]">-{settings.currencySymbol}{totalRefunded.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#6d7175]">Sales Tax Collected</span>
                <span className="font-mono text-[#5c5f62] dark:text-[#a6acb2]">{settings.currencySymbol}{totalTax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-2 pt-3 text-sm font-bold text-[#202223] dark:text-white">
                <span>Net Store Revenue</span>
                <span className="font-mono text-[#008060]">{settings.currencySymbol}{netSales.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Payment Method Distribution */}
          <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
            <h3 className="text-sm font-bold text-[#202223] dark:text-white mb-4">Payment Tender Share</h3>
            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="font-medium text-[#202223] dark:text-white flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-[#008060]" /> Credit / Debit Card (EMV)
                  </span>
                  <span className="font-mono font-semibold">{settings.currencySymbol}{cardTotal.toFixed(2)}</span>
                </div>
                <div className="w-full bg-[#f1f2f4] dark:bg-[#2b2c2e] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#008060] h-full rounded-full transition-all"
                    style={{ width: `${grossSales > 0 ? (cardTotal / grossSales) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="font-medium text-[#202223] dark:text-white flex items-center gap-1.5">
                    <Banknote className="w-3.5 h-3.5 text-[#005bd3]" /> Cash Tender
                  </span>
                  <span className="font-mono font-semibold">{settings.currencySymbol}{cashTotal.toFixed(2)}</span>
                </div>
                <div className="w-full bg-[#f1f2f4] dark:bg-[#2b2c2e] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#005bd3] h-full rounded-full transition-all"
                    style={{ width: `${grossSales > 0 ? (cashTotal / grossSales) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="font-medium text-[#202223] dark:text-white flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 text-purple-600" /> Split / Mixed Tender
                  </span>
                  <span className="font-mono font-semibold">{settings.currencySymbol}{splitTotal.toFixed(2)}</span>
                </div>
                <div className="w-full bg-[#f1f2f4] dark:bg-[#2b2c2e] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-purple-600 h-full rounded-full transition-all"
                    style={{ width: `${grossSales > 0 ? (splitTotal / grossSales) * 100 : 0}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Top Performing SKUs Table */}
        <div className="bg-white dark:bg-[#1a1a1a] rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] p-5 shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
          <h3 className="text-sm font-bold text-[#202223] dark:text-white mb-4">Top 5 Selling Items</h3>
          {topSelling.length === 0 ? (
            <p className="text-xs text-[#8c9196] italic">No sales recorded during this reporting window.</p>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="border-b border-[#e1e3e5] dark:border-[#303030] text-[#6d7175]">
                <tr>
                  <th className="py-2.5 font-semibold">Product Name</th>
                  <th className="py-2.5 font-semibold text-center">Units Sold</th>
                  <th className="py-2.5 font-semibold text-right">Gross Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f2f4] dark:divide-[#26282a]">
                {topSelling.map((it, idx) => (
                  <tr key={idx} className="hover:bg-[#f6f6f7] dark:hover:bg-[#202123]">
                    <td className="py-2.5 font-semibold text-[#202223] dark:text-white">{it.name}</td>
                    <td className="py-2.5 text-center font-mono">{it.qty}</td>
                    <td className="py-2.5 text-right font-mono font-bold text-[#008060]">
                      {settings.currencySymbol}{it.revenue.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  }

  // ====================================================
  // SCREEN: REFUNDS & RETURNS (SHOPIFY ORDER LOOKUP)
  // ====================================================
  function renderRefundsScreen() {
    const matchingSales = sales.filter(s => {
      const q = refundSearch.toLowerCase().trim();
      if (!q) return true;
      return (
        s.receiptNumber.toLowerCase().includes(q) ||
        (s.customerName && s.customerName.toLowerCase().includes(q)) ||
        s.date.includes(q)
      );
    });

    return (
      <div className="h-full flex overflow-hidden p-6 gap-6 bg-[#f4f6f8] dark:bg-[#111213]">
        {/* Left: Orders Lookup */}
        <div className="w-1/2 flex flex-col bg-white dark:bg-[#1a1a1a] rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.03)] overflow-hidden">
          <div className="p-4 border-b border-[#e1e3e5] dark:border-[#303030] bg-[#fafbfb] dark:bg-[#161718]">
            <h2 className="text-sm font-bold text-[#202223] dark:text-white">Lookup Completed Order</h2>
            <div className="relative mt-2">
              <Search className="w-4 h-4 text-[#8c9196] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search receipt # (e.g. REC-...) or customer name..."
                value={refundSearch}
                onChange={e => setRefundSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-xs bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008060] shadow-xs"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[#f1f2f4] dark:divide-[#2e3032]">
            {matchingSales.length === 0 ? (
              <div className="p-8 text-center text-[#8c9196] text-xs">
                No orders match your search criteria.
              </div>
            ) : (
              matchingSales.map(sale => {
                const isSelected = selectedSaleForRefund?.id === sale.id;
                return (
                  <div
                    key={sale.id}
                    onClick={() => handleStartRefundForSale(sale)}
                    className={`p-4 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#e3f1df] dark:bg-[#008060]/20 border-l-4 border-[#008060]'
                        : 'hover:bg-[#f6f6f7] dark:hover:bg-[#202123]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono text-[#202223] dark:text-white">
                        {sale.receiptNumber}
                      </span>
                      <span className="text-xs font-mono font-bold text-[#202223] dark:text-white">
                        {settings.currencySymbol}{sale.total.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-1 text-[11px] text-[#6d7175]">
                      <span>{sale.customerName || 'Walk-in Customer'} · {sale.items.reduce((s, it) => s + it.quantity, 0)} items</span>
                      <span>{new Date(sale.date).toLocaleDateString()}</span>
                    </div>

                    <div className="mt-2 flex items-center justify-between">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded capitalize ${
                        sale.status === 'refunded'
                          ? 'bg-[#fee8e7] text-[#c01507]'
                          : 'bg-[#e3f1df] text-[#008060]'
                      }`}>
                        {sale.status.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] font-medium text-[#008060] flex items-center gap-1">
                        Select for Return <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Refund Item Selection & Inventory Restocking */}
        <div className="w-1/2 flex flex-col bg-white dark:bg-[#1a1a1a] rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.03)] overflow-hidden">
          <div className="p-4 border-b border-[#e1e3e5] dark:border-[#303030] bg-[#fafbfb] dark:bg-[#161718]">
            <h2 className="text-sm font-bold text-[#202223] dark:text-white">Process Item Return & Restock</h2>
            <p className="text-xs text-[#8c9196] mt-0.5">
              Select items to return. Restocks inventory automatically upon completion.
            </p>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {!selectedSaleForRefund ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-[#8c9196] p-6">
                <RotateCcw className="w-10 h-10 text-[#d2d5d8] mb-2" />
                <p className="text-sm font-semibold">No order selected</p>
                <p className="text-xs mt-1">Select an order on the left to initiate return workflow</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-[#f6f6f7] dark:bg-[#222] rounded-lg text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-[#6d7175]">Receipt:</span>
                    <span className="font-mono font-bold text-[#202223] dark:text-white">{selectedSaleForRefund.receiptNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#6d7175]">Date of Sale:</span>
                    <span>{new Date(selectedSaleForRefund.date).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#6d7175]">Original Payment:</span>
                    <span className="capitalize">{selectedSaleForRefund.paymentMethod}</span>
                  </div>
                </div>

                <h4 className="text-xs font-bold text-[#202223] dark:text-white uppercase tracking-wider">
                  Select Return Quantities
                </h4>

                <div className="space-y-2">
                  {selectedSaleForRefund.items.map(it => {
                    const selectedQty = refundItemQuantities[it.product.id] || 0;
                    const unitPrice = it.customPrice ?? it.product.price;

                    return (
                      <div
                        key={it.product.id}
                        className="p-3 border border-[#e1e3e5] dark:border-[#303030] rounded-lg flex items-center justify-between"
                      >
                        <div className="flex-1 min-w-0 pr-3">
                          <p className="text-xs font-semibold text-[#202223] dark:text-white truncate">{it.product.name}</p>
                          <p className="text-[11px] text-[#6d7175]">
                            {settings.currencySymbol}{unitPrice.toFixed(2)} × {it.quantity} purchased
                          </p>
                        </div>

                        {/* Quantity Stepper for return */}
                        <div className="flex items-center gap-2">
                          <div className="flex items-center border border-[#d2d5d8] dark:border-[#383a3c] rounded-md bg-white dark:bg-[#1a1a1a]">
                            <button
                              onClick={() => {
                                setRefundItemQuantities(prev => ({
                                  ...prev,
                                  [it.product.id]: Math.max(0, (prev[it.product.id] || 0) - 1)
                                }));
                              }}
                              className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c]"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-8 text-center text-xs font-mono font-bold">
                              {selectedQty}
                            </span>
                            <button
                              onClick={() => {
                                setRefundItemQuantities(prev => ({
                                  ...prev,
                                  [it.product.id]: Math.min(it.quantity, (prev[it.product.id] || 0) + 1)
                                }));
                              }}
                              className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c]"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#6d7175] mb-1">Return Reason</label>
                  <select
                    value={refundReason}
                    onChange={e => setRefundReason(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg focus:ring-2 focus:ring-[#008060] outline-none font-medium shadow-xs"
                  >
                    <option value="Customer returned goods">Customer returned goods</option>
                    <option value="Defective or damaged">Defective or damaged</option>
                    <option value="Wrong size or variant">Wrong size or variant</option>
                    <option value="Accidental duplicate charge">Accidental duplicate charge</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {selectedSaleForRefund && (
            <div className="p-4 border-t border-[#e1e3e5] dark:border-[#303030] bg-[#fafbfb] dark:bg-[#161718] flex items-center justify-between">
              <div>
                <span className="text-xs text-[#6d7175]">Total Refund Due:</span>
                <div className="text-lg font-bold font-mono text-[#c01507]">
                  {settings.currencySymbol}
                  {selectedSaleForRefund.items.reduce((sum, it) => {
                    const q = refundItemQuantities[it.product.id] || 0;
                    return sum + ((it.customPrice ?? it.product.price) * q);
                  }, 0).toFixed(2)}
                </div>
              </div>

              <button
                onClick={handleProcessRefund}
                className="px-5 py-2.5 bg-[#c01507] hover:bg-[#9f1105] text-white text-xs font-bold rounded-lg transition-colors shadow-xs"
              >
                Confirm Refund & Restock
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ====================================================
  // SCREEN: CUSTOMERS DIRECTORY
  // ====================================================
  function renderCustomersScreen() {
    const filteredDirectoryCustomers = customers.filter(cust => {
      if (!customerDirectorySearch.trim()) return true;
      const q = customerDirectorySearch.toLowerCase().trim();
      return (
        cust.name.toLowerCase().includes(q) ||
        (cust.email && cust.email.toLowerCase().includes(q)) ||
        (cust.phone && cust.phone.toLowerCase().includes(q)) ||
        (cust.notes && cust.notes.toLowerCase().includes(q))
      );
    });

    return (
      <div className="h-full flex flex-col p-6 bg-[#f4f6f8] dark:bg-[#111213] overflow-hidden">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#202223] dark:text-white">Customer Directory</h2>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5]">
                {customers.length} {customers.length === 1 ? 'Customer' : 'Customers'}
              </span>
            </div>
            <p className="text-xs text-[#8c9196] mt-0.5">Track purchase histories, contact info, and customer notes</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative min-w-[240px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#8c9196]" />
              <input
                type="text"
                placeholder="Search customers by name, phone, email..."
                value={customerDirectorySearch}
                onChange={e => setCustomerDirectorySearch(e.target.value)}
                className="w-full pl-8 pr-7 py-2 bg-white dark:bg-[#202123] border border-[#d2d5d8] dark:border-[#4d5053] rounded-lg text-xs text-[#202223] dark:text-white placeholder:text-[#8c9196] focus:border-[#008060] focus:ring-1 focus:ring-[#008060] outline-none transition-all shadow-2xs"
              />
              {customerDirectorySearch && (
                <button
                  onClick={() => setCustomerDirectorySearch('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-[#8c9196] hover:text-[#202223] dark:hover:text-white"
                  title="Clear search"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
            <button
              onClick={() => setShowNewCustomerModal(true)}
              className="px-3.5 py-2 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shrink-0 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Customer</span>
            </button>
          </div>
        </div>

        <div className="flex-1 bg-white dark:bg-[#1a1a1a] rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.03)] overflow-y-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f9fafb] dark:bg-[#1e1f20] border-b border-[#e1e3e5] dark:border-[#303030] sticky top-0 text-[#6d7175]">
              <tr>
                <th className="py-3 px-4 font-semibold">Customer</th>
                <th className="py-3 px-4 font-semibold">Email</th>
                <th className="py-3 px-4 font-semibold">Phone</th>
                <th className="py-3 px-4 font-semibold text-center">Orders</th>
                <th className="py-3 px-4 font-semibold text-right">Lifetime Spent</th>
                <th className="py-3 px-4 font-semibold">Notes</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f2f4] dark:divide-[#26282a]">
              {filteredDirectoryCustomers.map(cust => (
                <tr key={cust.id} className="hover:bg-[#f6f6f7] dark:hover:bg-[#202123] transition-colors group">
                  <td className="py-3 px-4">
                    <div
                      onClick={() => handleOpenEditCustomer(cust)}
                      className="flex items-center gap-2.5 cursor-pointer hover:opacity-85 transition-opacity"
                      title={`Click to edit details for ${cust.name}`}
                    >
                      <div className="w-8 h-8 rounded-full bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5] font-bold text-xs flex items-center justify-center shrink-0">
                        {cust.name[0]?.toUpperCase() || '?'}
                      </div>
                      <div>
                        <span className="font-semibold text-[#202223] dark:text-white block hover:text-[#008060] transition-colors">{cust.name}</span>
                        {cust.createdAt && (
                          <span className="text-[10px] text-[#8c9196]">Since {cust.createdAt}</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-[#5c5f62] dark:text-[#a6acb2]">{cust.email || '—'}</td>
                  <td className="py-3 px-4 font-mono text-[#5c5f62] dark:text-[#a6acb2]">{cust.phone || '—'}</td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleOpenCustomerHistory(cust)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold text-[#008060] dark:text-[#98f2d5] bg-[#e3f1df] dark:bg-[#004e38]/60 hover:bg-[#c9ebd1] dark:hover:bg-[#006e52] transition-colors shadow-2xs group/ord"
                      title={`Click to view ${cust.name}'s purchase history & bought items`}
                    >
                      <Clock className="w-3 h-3 text-[#008060] dark:text-[#98f2d5]" />
                      <span>{cust.totalOrders} {cust.totalOrders === 1 ? 'order' : 'orders'}</span>
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-[#008060]">
                    {settings.currencySymbol}{cust.totalSpent.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-[#8c9196] max-w-xs truncate">{cust.notes || '—'}</td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenCustomerHistory(cust)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#008060] dark:text-[#98f2d5] bg-[#e3f1df]/60 dark:bg-[#004e38]/50 hover:bg-[#e3f1df] dark:hover:bg-[#004e38] border border-[#b4e3cb] dark:border-[#006e52] rounded-md transition-all shadow-2xs"
                        title={`View purchase history & items bought by ${cust.name}`}
                      >
                        <Clock className="w-3.5 h-3.5 text-[#008060]" />
                        <span>History</span>
                      </button>
                      <button
                        onClick={() => handleOpenEditCustomer(cust)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#202223] dark:text-white bg-[#f1f2f4] dark:bg-[#2b2c2e] hover:bg-[#e4e5e7] dark:hover:bg-[#393a3d] border border-[#d2d5d8] dark:border-[#404040] rounded-md transition-all shadow-2xs hover:border-[#008060] focus:ring-1 focus:ring-[#008060]"
                        title={`Edit contact details for ${cust.name}`}
                      >
                        <Edit className="w-3.5 h-3.5 text-[#008060]" />
                        <span>Edit</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredDirectoryCustomers.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center">
                    <div className="flex flex-col items-center justify-center text-center p-6">
                      <div className="w-12 h-12 rounded-full bg-[#f1f2f4] dark:bg-[#26282a] flex items-center justify-center text-[#8c9196] mb-3">
                        <Users className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-semibold text-[#202223] dark:text-white">
                        {customerDirectorySearch ? 'No matching customers found' : 'No customers in directory'}
                      </p>
                      <p className="text-xs text-[#8c9196] mt-1 max-w-sm">
                        {customerDirectorySearch
                          ? `No customer record matches "${customerDirectorySearch}". Try searching for another name, email, or phone number.`
                          : 'Add your first customer to track their orders, purchase history, and contact details.'}
                      </p>
                      {customerDirectorySearch ? (
                        <button
                          onClick={() => setCustomerDirectorySearch('')}
                          className="mt-3 px-3 py-1.5 border border-[#d2d5d8] dark:border-[#4d5053] rounded-lg text-xs font-semibold text-[#202223] dark:text-white hover:bg-[#f6f6f7] dark:hover:bg-[#26282a]"
                        >
                          Clear Search Filter
                        </button>
                      ) : (
                        <button
                          onClick={() => setShowNewCustomerModal(true)}
                          className="mt-3 px-3.5 py-1.5 bg-[#008060] hover:bg-[#006e52] text-white rounded-lg text-xs font-semibold"
                        >
                          + Add Customer
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ====================================================
  // SCREEN: SETTINGS (THEME, HARDWARE PAIRING, EXCEL BACKUP)
  // ====================================================
  function renderSettingsScreen() {
    return (
      <div className="h-full overflow-y-auto p-6 bg-[#f4f6f8] dark:bg-[#111213] space-y-6 max-w-5xl mx-auto">
        
        {/* ================================================= */}
        {/* 1. THEME SELECTOR (EXCLUSIVELY PLACED INSIDE SETTINGS) */}
        {/* ================================================= */}
        <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#202223] dark:text-white">Application Theme</h3>
              <p className="text-xs text-[#8c9196] mt-0.5">
                Select appearance mode for store registers. Dedicated to Settings as per Shopify POS guidelines.
              </p>
            </div>

            <div className="flex items-center gap-2 p-1 bg-[#f1f2f4] dark:bg-[#2b2c2e] rounded-lg">
              <button
                onClick={() => setSettings(prev => ({ ...prev, theme: 'light' }))}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
                  settings.theme === 'light'
                    ? 'bg-white text-[#202223] shadow-xs'
                    : 'text-[#6d7175] hover:text-[#202223]'
                }`}
              >
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span>Light Mode</span>
              </button>

              <button
                onClick={() => setSettings(prev => ({ ...prev, theme: 'dark' }))}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
                  settings.theme === 'dark'
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'text-[#6d7175] hover:text-white'
                }`}
              >
                <Moon className="w-3.5 h-3.5 text-blue-400" />
                <span>Dark Mode</span>
              </button>
            </div>
          </div>
        </div>

        {/* ================================================= */}
        {/* 2. REAL HARDWARE MANAGEMENT SECTION */}
        {/* ================================================= */}
        <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)] space-y-4">
          <div>
            <h3 className="text-sm font-bold text-[#202223] dark:text-white">POS Hardware & Device Management</h3>
            <p className="text-xs text-[#8c9196] mt-0.5">
              Real device status interrogation via WebUSB, WebSerial & WebHID. Indicators strictly reflect real connection state.
            </p>
          </div>

          {hardwarePairingMsg && (
            <div className={`p-3 rounded-lg text-xs flex items-center justify-between ${
              hardwarePairingMsg.isError ? 'bg-[#fee8e7] text-[#c01507]' : 'bg-[#e3f1df] text-[#008060]'
            }`}>
              <span>{hardwarePairingMsg.message}</span>
              <button onClick={() => setHardwarePairingMsg(null)}>
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Barcode Scanner Device Card */}
            <div className="p-4 border border-[#e1e3e5] dark:border-[#303030] rounded-lg bg-[#fafbfb] dark:bg-[#202123] flex flex-col justify-between">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-[#202223] dark:text-white" />
                    <span className="text-xs font-bold text-[#202223] dark:text-white">Barcode Scanner</span>
                  </div>
                  <p className="text-[11px] text-[#8c9196] mt-1">
                    Device: {hardware.scannerName}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2.5 h-2.5 rounded-full ${hardware.scannerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'}`} />
                  <span className={`text-xs font-bold ${hardware.scannerConnected ? 'text-[#008060]' : 'text-[#8c9196]'}`}>
                    {hardware.scannerConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#e1e3e5] dark:border-[#2e3032] flex items-center justify-between">
                <span className="text-[11px] text-[#8c9196]">Keyboard Wedge Active</span>
                <button
                  onClick={handleConnectScanner}
                  className="px-3 py-1.5 bg-[#202223] dark:bg-white text-white dark:text-[#202223] text-xs font-semibold rounded-md hover:opacity-90 transition-opacity"
                >
                  Connect Scanner
                </button>
              </div>
            </div>

            {/* Receipt Printer Device Card */}
            <div className="p-4 border border-[#e1e3e5] dark:border-[#303030] rounded-lg bg-[#fafbfb] dark:bg-[#202123] flex flex-col justify-between">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4 text-[#202223] dark:text-white" />
                    <span className="text-xs font-bold text-[#202223] dark:text-white">Thermal Receipt Printer</span>
                  </div>
                  <p className="text-[11px] text-[#8c9196] mt-1">
                    Interface: {hardware.printerName}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2.5 h-2.5 rounded-full ${hardware.printerConnected ? 'bg-[#008060]' : 'bg-[#e51c00]'}`} />
                  <span className={`text-xs font-bold ${hardware.printerConnected ? 'text-[#008060]' : 'text-[#8c9196]'}`}>
                    {hardware.printerConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#e1e3e5] dark:border-[#2e3032] flex items-center justify-between gap-2">
                <button
                  onClick={handlePrintReceipt}
                  className="px-2.5 py-1.5 border border-[#c9cccf] dark:border-[#3b3c3e] text-xs font-semibold rounded-md hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e]"
                >
                  Test Print
                </button>
                <button
                  onClick={handleConnectPrinter}
                  className="px-3 py-1.5 bg-[#202223] dark:bg-white text-white dark:text-[#202223] text-xs font-semibold rounded-md hover:opacity-90 transition-opacity"
                >
                  Connect Printer
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2 text-xs">
              <span>Receipt Paper Width:</span>
              <select
                value={settings.paperWidth}
                onChange={e => setSettings(prev => ({ ...prev, paperWidth: e.target.value as any }))}
                className="p-1.5 border border-[#8c9196] dark:border-[#4d5053] rounded-md bg-white dark:bg-[#202123] text-[#111213] dark:text-white text-xs font-semibold shadow-xs cursor-pointer"
              >
                <option value="80mm">80mm (Standard POS)</option>
                <option value="58mm">58mm (Compact Thermal)</option>
              </select>
            </div>

            <button
              onClick={() => {
                setSettings(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }));
                triggerSound('beep');
              }}
              className="text-xs font-medium text-[#5c5f62] dark:text-[#a6acb2] flex items-center gap-1.5 hover:text-[#202223]"
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-[#008060]" /> : <VolumeX className="w-4 h-4" />}
              <span>{settings.soundEnabled ? 'Register Chimes Enabled' : 'Chimes Muted'}</span>
            </button>
          </div>
        </div>

        {/* ================================================= */}
        {/* 3. LOCAL EXCEL STORAGE & BACKUP (SheetJS xlsx) */}
        {/* ================================================= */}
        <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)] space-y-4">
          <div>
            <h3 className="text-sm font-bold text-[#202223] dark:text-white">Local Excel Storage & Backup (.xlsx)</h3>
            <p className="text-xs text-[#8c9196] mt-0.5">
              Powered by SheetJS. Securely export full store snapshots (sales, inventory, customers, refunds) or import product catalogs.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => exportFullBackupXLSX(products, sales, refunds, customers, settings)}
              className="p-4 border border-[#e1e3e5] dark:border-[#303030] rounded-lg bg-[#fafbfb] dark:bg-[#202123] hover:border-[#008060] flex flex-col items-start gap-2 transition-all text-left"
            >
              <FileSpreadsheet className="w-5 h-5 text-[#008060]" />
              <div>
                <p className="text-xs font-bold text-[#202223] dark:text-white">Full POS Data Backup</p>
                <p className="text-[11px] text-[#8c9196]">Exports all 5 database sheets to .xlsx</p>
              </div>
            </button>

            <button
              onClick={() => exportInventoryXLSX(products, settings.storeName)}
              className="p-4 border border-[#e1e3e5] dark:border-[#303030] rounded-lg bg-[#fafbfb] dark:bg-[#202123] hover:border-[#008060] flex flex-col items-start gap-2 transition-all text-left"
            >
              <FileDown className="w-5 h-5 text-[#005bd3]" />
              <div>
                <p className="text-xs font-bold text-[#202223] dark:text-white">Export Inventory (.xlsx)</p>
                <p className="text-[11px] text-[#8c9196]">Catalog, prices, SKUs and stock</p>
              </div>
            </button>

            <label className="p-4 border border-[#e1e3e5] dark:border-[#303030] rounded-lg bg-[#fafbfb] dark:bg-[#202123] hover:border-[#008060] flex flex-col items-start gap-2 transition-all cursor-pointer">
              <Upload className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-xs font-bold text-[#202223] dark:text-white">Import Inventory (.xlsx)</p>
                <p className="text-[11px] text-[#8c9196]">Upload and merge Excel spreadsheet</p>
              </div>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const res = await parseInventoryXLSX(file);
                    if (res.success && res.products) {
                      setProducts(prev => [...res.products!, ...prev]);
                      alert(res.message);
                      triggerSound('success');
                    } else {
                      alert(res.message);
                      triggerSound('error');
                    }
                  }
                }}
              />
            </label>
          </div>
        </div>

        {/* ================================================= */}
        {/* 4. STORE PROFILE & RECEIPT CONFIG */}
        {/* ================================================= */}
        <div className="bg-white dark:bg-[#1a1a1a] p-5 rounded-[8px] border border-[#e1e3e5] dark:border-[#303030] shadow-[0_1px_3px_0_rgba(0,0,0,0.04)] space-y-4">
          <h3 className="text-sm font-bold text-[#202223] dark:text-white">Store Profile & Receipt Branding</h3>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Store Name</label>
              <input
                type="text"
                value={settings.storeName}
                onChange={e => setSettings(prev => ({ ...prev, storeName: e.target.value }))}
                className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Cashier Staff Name</label>
              <input
                type="text"
                value={settings.cashierName}
                onChange={e => setSettings(prev => ({ ...prev, cashierName: e.target.value }))}
                className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Store Address</label>
              <input
                type="text"
                value={settings.storeAddress}
                onChange={e => setSettings(prev => ({ ...prev, storeAddress: e.target.value }))}
                className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Sales Tax Rate (e.g. 0.08875 for 8.875%)</label>
              <input
                type="number"
                step="0.001"
                value={settings.taxRate}
                onChange={e => setSettings(prev => ({ ...prev, taxRate: parseFloat(e.target.value) || 0 }))}
                className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-mono font-bold shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Currency Symbol</label>
              <input
                type="text"
                value={settings.currencySymbol}
                onChange={e => setSettings(prev => ({ ...prev, currencySymbol: e.target.value }))}
                className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-mono font-bold shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={() => {
                if (confirm("Reset application data back to factory demo state?")) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="text-xs text-[#c01507] hover:underline"
            >
              Reset to Factory Demo State
            </button>
          </div>
        </div>

      </div>
    );
  }

  // ====================================================
  // MODAL: INVENTORY PIN PROTECTION (STRICTLY 1111)
  // ====================================================
  function renderPinModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] text-center">
          <div className="w-12 h-12 rounded-full bg-[#f1f2f4] dark:bg-[#2b2c2e] text-[#202223] dark:text-white flex items-center justify-center mx-auto mb-3">
            <Lock className="w-6 h-6 text-[#008060]" />
          </div>

          <h3 className="text-base font-bold text-[#202223] dark:text-white">
            Enter Inventory Staff PIN
          </h3>
          <p className="text-xs text-[#8c9196] mt-1 mb-4">
            Security lock enabled for Inventory. Default PIN is <span className="font-mono font-bold text-[#202223] dark:text-white">1111</span>.
          </p>

          {/* PIN Dots Display */}
          <div className="flex justify-center gap-3 mb-6">
            {[0, 1, 2, 3].map(i => (
              <div
                key={i}
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  pinInput.length > i
                    ? 'bg-[#008060] border-[#008060]'
                    : 'border-[#c9cccf] dark:border-[#404245]'
                }`}
              />
            ))}
          </div>

          {pinError && (
            <p className="text-xs text-[#c01507] font-medium mb-3 animate-shake">
              {pinError}
            </p>
          )}

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto mb-4">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <button
                key={num}
                type="button"
                onClick={() => {
                  if (pinInput.length < 4) {
                    const newPin = pinInput + num;
                    setPinInput(newPin);
                    if (newPin.length === 4) {
                      setTimeout(() => {
                        if (newPin === settings.inventoryPin) {
                          triggerSound('success');
                          setIsInventoryUnlocked(true);
                          setShowPinModal(false);
                          setCurrentPage('inventory');
                        } else {
                          triggerSound('error');
                          setPinError('Incorrect PIN. Default is 1111.');
                          setPinInput('');
                        }
                      }, 100);
                    }
                  }
                }}
                className="h-12 rounded-lg bg-[#f6f6f7] dark:bg-[#28292b] hover:bg-[#e4e5e7] dark:hover:bg-[#333] text-base font-bold text-[#202223] dark:text-white transition-colors active:scale-95"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setPinInput('');
                setPinError('');
              }}
              className="h-12 rounded-lg bg-[#f6f6f7] dark:bg-[#28292b] text-xs font-semibold text-[#8c9196] hover:bg-[#e4e5e7]"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => {
                if (pinInput.length < 4) {
                  const newPin = pinInput + '0';
                  setPinInput(newPin);
                  if (newPin.length === 4) {
                    setTimeout(() => {
                      if (newPin === settings.inventoryPin) {
                        triggerSound('success');
                        setIsInventoryUnlocked(true);
                        setShowPinModal(false);
                        setCurrentPage('inventory');
                      } else {
                        triggerSound('error');
                        setPinError('Incorrect PIN. Default is 1111.');
                        setPinInput('');
                      }
                    }, 100);
                  }
                }
              }}
              className="h-12 rounded-lg bg-[#f6f6f7] dark:bg-[#28292b] text-base font-bold text-[#202223] dark:text-white"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => setShowPinModal(false)}
              className="h-12 rounded-lg bg-[#fee8e7] text-xs font-semibold text-[#c01507] hover:bg-[#fdd2cf]"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: OUT OF STOCK GUARD
  // ====================================================
  function renderOutOfStockModal() {
    if (!outOfStockProduct) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-md bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030]">
          <div className="flex items-center gap-3 text-[#c01507] mb-3">
            <div className="w-10 h-10 rounded-full bg-[#fee8e7] flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-[#c01507]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#202223] dark:text-white">Item Out of Stock</h3>
              <p className="text-xs text-[#8c9196]">Inventory Protection Guard</p>
            </div>
          </div>

          <p className="text-xs text-[#5c5f62] dark:text-[#a6acb2] my-4 leading-relaxed">
            <span className="font-semibold text-[#202223] dark:text-white">"{outOfStockProduct.name}"</span> currently has <span className="font-bold text-[#c01507]">0 units</span> in stock.
            Selling this item is prevented to preserve inventory accuracy.
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setOutOfStockProduct(null)}
              className="px-4 py-2 bg-[#202223] dark:bg-white text-white dark:text-[#202223] text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: LOW STOCK POPUP ALERT (AFTER SALE)
  // ====================================================
  function renderLowStockAlertModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-md bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#ffe0b2] dark:border-[#523e1b]">
          <div className="flex items-center gap-3 text-[#914d00] mb-3">
            <div className="w-10 h-10 rounded-full bg-[#fff5ea] flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-[#914d00]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#202223] dark:text-white">Low Stock Warning</h3>
              <p className="text-xs text-[#8c9196]">Threshold Alert Triggered</p>
            </div>
          </div>

          <div className="my-3 space-y-2">
            {lowStockAlerts.map(({ product, stock }) => (
              <div key={product.id} className="p-3 bg-[#fff5ea] dark:bg-[#2d2214] rounded-lg text-xs flex justify-between items-center">
                <span className="font-semibold text-[#202223] dark:text-white">{product.name}</span>
                <span className="font-mono font-bold text-[#914d00]">
                  {stock} left (Target: {product.lowStockThreshold})
                </span>
              </div>
            ))}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => setLowStockAlerts([])}
              className="px-4 py-2 bg-[#914d00] text-white text-xs font-semibold rounded-lg hover:opacity-90"
            >
              Acknowledge Alert
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: PRODUCT DETAILS INSPECTION (INVENTORY)
  // ====================================================
  function renderProductDetailsModal() {
    if (!viewingProductDetails) return null;
    const prod = viewingProductDetails;
    const isOut = prod.stock <= 0;
    const isLow = prod.stock > 0 && prod.stock <= prod.lowStockThreshold;
    const margin = prod.price - prod.cost;
    const marginPercent = prod.price > 0 ? ((margin / prod.price) * 100).toFixed(1) : '0.0';
    const totalVal = prod.price * prod.stock;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-lg bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#c9cccf] dark:border-[#383a3c] flex flex-col max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030] mb-4">
            <div className="flex items-center gap-2">
              <Package className="w-5 h-5 text-[#008060]" />
              <h3 className="text-base font-bold text-[#111213] dark:text-white">Product Details</h3>
            </div>
            <button
              onClick={() => setViewingProductDetails(null)}
              className="p-1 rounded-lg text-[#5c5f62] dark:text-[#a6acb2] hover:text-[#111213] dark:hover:text-white hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 pr-1">
            {/* Top Product Hero Row */}
            <div className="flex items-start gap-4 p-4 bg-[#f9fafb] dark:bg-[#242526] rounded-xl border border-[#e1e3e5] dark:border-[#303030]">
              <div className="w-20 h-20 rounded-lg bg-white dark:bg-[#1a1a1a] flex items-center justify-center overflow-hidden shrink-0 border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
                {prod.image ? (
                  <img src={prod.image} alt={prod.name} className="w-full h-full object-cover" />
                ) : (
                  <Package className="w-8 h-8 text-[#5c5f62] dark:text-[#b4b8bc]" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                  <span className="px-2 py-0.5 rounded text-xs font-semibold bg-[#e8e9eb] dark:bg-[#2e3032] text-[#202223] dark:text-[#f1f2f4] border border-[#d2d5d8] dark:border-[#404245]">
                    {prod.category}
                  </span>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold font-mono ${
                    isOut
                      ? 'bg-[#fee8e7] text-[#900b00] border border-[#f5b8b5]'
                      : isLow
                      ? 'bg-[#fff5ea] text-[#703b00] border border-[#fed699]'
                      : 'bg-[#e3f1df] text-[#006045] border border-[#b7e2b1]'
                  }`}>
                    {isOut ? 'Out of Stock' : isLow ? `${prod.stock} Left (Low)` : `${prod.stock} in stock`}
                  </span>
                </div>
                <h2 className="text-base font-bold text-[#111213] dark:text-white leading-snug">
                  {prod.name}
                </h2>
                <div className="flex items-center gap-3 mt-1.5 text-xs font-mono text-[#5c5f62] dark:text-[#b4b8bc]">
                  <span>SKU: <strong className="text-[#111213] dark:text-white">{prod.sku}</strong></span>
                  <span>•</span>
                  <span>Barcode: <strong className="text-[#111213] dark:text-white">{prod.barcode}</strong></span>
                </div>
              </div>
            </div>

            {/* Financial Summary Cards */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-white dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
                <span className="text-[11px] font-bold text-[#5c5f62] dark:text-[#a6acb2] uppercase tracking-wider block">Retail Price</span>
                <span className="text-lg font-bold font-mono text-[#111213] dark:text-white mt-1 block">
                  {settings.currencySymbol}{prod.price.toFixed(2)}
                </span>
              </div>
              <div className="p-3 bg-white dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
                <span className="text-[11px] font-bold text-[#5c5f62] dark:text-[#a6acb2] uppercase tracking-wider block">Unit Cost</span>
                <span className="text-lg font-bold font-mono text-[#5c5f62] dark:text-[#c9cccf] mt-1 block">
                  {settings.currencySymbol}{prod.cost.toFixed(2)}
                </span>
              </div>
              <div className="p-3 bg-white dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] shadow-xs">
                <span className="text-[11px] font-bold text-[#006045] dark:text-[#38d39f] uppercase tracking-wider block">Gross Margin</span>
                <span className="text-lg font-bold font-mono text-[#008060] dark:text-[#2ecc71] mt-1 block">
                  +{settings.currencySymbol}{margin.toFixed(2)} <span className="text-xs font-semibold">({marginPercent}%)</span>
                </span>
              </div>
            </div>

            {/* Inventory Status Breakdown */}
            <div className="p-4 bg-white dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] space-y-2 text-xs">
              <h4 className="font-bold text-[#111213] dark:text-white uppercase tracking-wider text-[11px]">Stock Status & Valuation</h4>
              <div className="flex justify-between py-1 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#5c5f62] dark:text-[#a6acb2]">Available on Hand:</span>
                <span className="font-mono font-bold text-[#111213] dark:text-white">{prod.stock} units</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#f1f2f4] dark:border-[#2e3032]">
                <span className="text-[#5c5f62] dark:text-[#a6acb2]">Low Stock Alert Threshold:</span>
                <span className="font-mono font-bold text-[#111213] dark:text-white">{prod.lowStockThreshold} units</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#5c5f62] dark:text-[#a6acb2]">Retail Inventory Asset Value:</span>
                <span className="font-mono font-bold text-[#008060] dark:text-[#2ecc71]">{settings.currencySymbol}{totalVal.toFixed(2)}</span>
              </div>
            </div>

            {/* Description Card */}
            <div className="p-4 bg-white dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] space-y-1.5 text-xs">
              <h4 className="font-bold text-[#111213] dark:text-white uppercase tracking-wider text-[11px]">Description & Specifications</h4>
              <p className="text-xs text-[#202223] dark:text-[#e1e3e5] leading-relaxed font-medium">
                {prod.description || 'No detailed specifications have been added for this item yet. Click Edit Product Details to add fabric composition, dimensions, or seller notes.'}
              </p>
            </div>
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-[#e1e3e5] dark:border-[#303030] flex items-center justify-between gap-3 mt-4">
            <button
              onClick={() => {
                setDeletingProductId(prod.id);
                setViewingProductDetails(null);
              }}
              className="px-3.5 py-2 text-xs font-bold text-[#c01507] hover:bg-[#fee8e7] dark:hover:bg-[#3d1a19] rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Product</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setViewingProductDetails(null)}
                className="px-4 py-2 border border-[#8c9196] dark:border-[#4d5053] text-[#202223] dark:text-[#e1e3e5] hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e] text-xs font-bold rounded-lg transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setEditingProduct(prod);
                  setViewingProductDetails(null);
                  setShowAddProductModal(true);
                }}
                className="px-5 py-2 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Edit className="w-4 h-4" />
                <span>Edit Product Details</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: ADD / EDIT PRODUCT (PRE-FILLED FOR SCANNED BARCODES)
  // ====================================================
  function renderAddProductModal() {
    const isEdit = !!editingProduct;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-lg bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030]">
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030] mb-4">
            <h3 className="text-sm font-bold text-[#202223] dark:text-white">
              {isEdit ? 'Edit Product Details' : prefilledBarcode ? `Add New Product (Barcode: ${prefilledBarcode})` : 'Add New Inventory Product'}
            </h3>
            <button onClick={() => { setShowAddProductModal(false); setEditingProduct(null); }}>
              <X className="w-4 h-4 text-[#8c9196]" />
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const formData = new FormData(form);

              const prod: Product = {
                id: editingProduct?.id || `prod-${Date.now()}`,
                name: (formData.get('name') as string).trim(),
                sku: (formData.get('sku') as string).trim(),
                barcode: (formData.get('barcode') as string).trim(),
                category: (formData.get('category') as string).trim(),
                price: parseFloat(formData.get('price') as string) || 0,
                cost: parseFloat(formData.get('cost') as string) || 0,
                stock: parseInt(formData.get('stock') as string, 10) || 0,
                lowStockThreshold: parseInt(formData.get('lowStockThreshold') as string, 10) || 5,
                description: (formData.get('description') as string).trim(),
                image: editingProduct?.image
              };

              handleSaveProduct(prod);
            }}
            className="space-y-3 text-xs"
          >
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Product Name *</label>
              <input
                required
                name="name"
                defaultValue={editingProduct?.name || ''}
                placeholder="e.g. Wool Overshirt - Navy"
                className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">SKU *</label>
                <input
                  required
                  name="sku"
                  defaultValue={editingProduct?.sku || `SKU-${Math.floor(1000 + Math.random() * 9000)}`}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Barcode (UPC/EAN) *</label>
                <input
                  required
                  name="barcode"
                  defaultValue={editingProduct?.barcode || prefilledBarcode || `${Math.floor(100000000000 + Math.random() * 900000000000)}`}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Category</label>
                <input
                  name="category"
                  defaultValue={editingProduct?.category || 'Apparel'}
                  placeholder="Apparel, Coffee, Living..."
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Stock Quantity *</label>
                <input
                  required
                  type="number"
                  name="stock"
                  defaultValue={editingProduct?.stock ?? 15}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Retail Price ($) *</label>
                <input
                  required
                  type="number"
                  step="0.01"
                  name="price"
                  defaultValue={editingProduct?.price ?? 45.00}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Unit Cost ($)</label>
                <input
                  type="number"
                  step="0.01"
                  name="cost"
                  defaultValue={editingProduct?.cost ?? 18.00}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Low Stock Target</label>
                <input
                  type="number"
                  name="lowStockThreshold"
                  defaultValue={editingProduct?.lowStockThreshold ?? 5}
                  className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Description</label>
              <textarea
                name="description"
                rows={2}
                defaultValue={editingProduct?.description || ''}
                placeholder="Product specs, materials, notes..."
                className="w-full p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[#e1e3e5] dark:border-[#303030]">
              <button
                type="button"
                onClick={() => { setShowAddProductModal(false); setEditingProduct(null); }}
                className="px-4 py-2 border border-[#c9cccf] dark:border-[#3b3c3e] rounded-lg text-[#5c5f62] dark:text-[#a6acb2]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-[#008060] hover:bg-[#006e52] text-white font-semibold rounded-lg"
              >
                Save Product
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: CHECKOUT & TENDER SELECTION
  // ====================================================
  function renderCheckoutModal() {
    const cashVal = parseFloat(cashTendered) || 0;
    const change = Math.max(0, cashVal - cartTotal);

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-lg bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col max-h-[90vh]">
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030]">
            <div>
              <h3 className="text-base font-bold text-[#202223] dark:text-white">Payment Checkout</h3>
              <p className="text-xs text-[#8c9196]">Total Due: <span className="font-mono font-bold text-[#202223] dark:text-white">{settings.currencySymbol}{cartTotal.toFixed(2)}</span></p>
            </div>
            <button onClick={() => setShowCheckoutModal(false)}>
              <X className="w-5 h-5 text-[#8c9196]" />
            </button>
          </div>

          <div className="my-4 flex-1 overflow-y-auto space-y-4">
            {/* Tender Method Selector */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setCheckoutPaymentMethod('card')}
                className={`p-3 rounded-lg border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                  checkoutPaymentMethod === 'card'
                    ? 'border-[#008060] bg-[#e3f1df] dark:bg-[#008060]/20 text-[#008060]'
                    : 'border-[#e1e3e5] dark:border-[#303030] bg-[#f6f6f7] dark:bg-[#242526] text-[#5c5f62] dark:text-[#a6acb2]'
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span>Card (EMV/Tap)</span>
              </button>

              <button
                type="button"
                onClick={() => setCheckoutPaymentMethod('cash')}
                className={`p-3 rounded-lg border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                  checkoutPaymentMethod === 'cash'
                    ? 'border-[#008060] bg-[#e3f1df] dark:bg-[#008060]/20 text-[#008060]'
                    : 'border-[#e1e3e5] dark:border-[#303030] bg-[#f6f6f7] dark:bg-[#242526] text-[#5c5f62] dark:text-[#a6acb2]'
                }`}
              >
                <Banknote className="w-5 h-5" />
                <span>Cash Tender</span>
              </button>

              <button
                type="button"
                onClick={() => setCheckoutPaymentMethod('split')}
                className={`p-3 rounded-lg border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                  checkoutPaymentMethod === 'split'
                    ? 'border-[#008060] bg-[#e3f1df] dark:bg-[#008060]/20 text-[#008060]'
                    : 'border-[#e1e3e5] dark:border-[#303030] bg-[#f6f6f7] dark:bg-[#242526] text-[#5c5f62] dark:text-[#a6acb2]'
                }`}
              >
                <RefreshCw className="w-5 h-5" />
                <span>Split Tender</span>
              </button>
            </div>

            {/* Cash Tender Details & Quick Bills */}
            {checkoutPaymentMethod === 'cash' && (
              <div className="space-y-3 p-4 bg-[#fafbfb] dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c]">
                <div>
                  <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Cash Tendered ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={cashTendered}
                    onChange={e => setCashTendered(e.target.value)}
                    className="w-full text-xl font-bold font-mono p-2.5 bg-white dark:bg-[#1a1a1a] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg focus:ring-2 focus:ring-[#008060] outline-none shadow-xs"
                  />
                </div>

                {/* Quick Bills */}
                <div className="flex gap-2">
                  {[cartTotal, 20, 50, 100].map((amt, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCashTendered(amt.toFixed(2))}
                      className="flex-1 py-1.5 bg-white dark:bg-[#1a1a1a] border border-[#c9cccf] dark:border-[#404245] text-[#111213] dark:text-white rounded text-xs font-bold hover:border-[#008060] transition-colors"
                    >
                      {idx === 0 ? 'Exact' : `$${amt}`}
                    </button>
                  ))}
                </div>

                <div className="p-3 bg-white dark:bg-[#1a1a1a] rounded border border-[#c9cccf] dark:border-[#383a3c] flex justify-between items-center text-xs">
                  <span className="font-bold text-[#303030] dark:text-[#c9cccf]">Change Due:</span>
                  <span className="text-base font-bold font-mono text-[#008060]">
                    {settings.currencySymbol}{change.toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* Split Tender Details */}
            {checkoutPaymentMethod === 'split' && (
              <div className="space-y-3 p-4 bg-[#fafbfb] dark:bg-[#242526] rounded-lg border border-[#c9cccf] dark:border-[#383a3c] text-xs">
                <div>
                  <label className="block font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Cash Portion ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={splitCashAmount}
                    onChange={e => {
                      const val = parseFloat(e.target.value) || 0;
                      setSplitCashAmount(e.target.value);
                      setSplitCardAmount(Math.max(0, cartTotal - val).toFixed(2));
                    }}
                    className="w-full p-2.5 bg-white dark:bg-[#1a1a1a] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-mono font-bold shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Card Portion ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={splitCardAmount}
                    onChange={e => {
                      const val = parseFloat(e.target.value) || 0;
                      setSplitCardAmount(e.target.value);
                      setSplitCashAmount(Math.max(0, cartTotal - val).toFixed(2));
                    }}
                    className="w-full p-2.5 bg-white dark:bg-[#1a1a1a] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg font-mono font-bold shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
                  />
                </div>
              </div>
            )}

            {checkoutPaymentMethod === 'card' && (
              <div className="p-4 bg-[#fafbfb] dark:bg-[#242526] rounded-lg border border-[#e1e3e5] dark:border-[#303030] text-center text-xs text-[#6d7175]">
                <CreditCard className="w-8 h-8 text-[#008060] mx-auto mb-2" />
                <p className="font-semibold text-[#202223] dark:text-white">Ready for EMV Chip or Tap</p>
                <p className="text-[11px] mt-0.5">Prompt customer to insert, tap, or swipe card on PIN pad terminal.</p>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-[#e1e3e5] dark:border-[#303030] flex justify-end gap-2">
            <button
              onClick={() => setShowCheckoutModal(false)}
              className="px-4 py-2.5 border border-[#c9cccf] dark:border-[#3b3c3e] rounded-lg text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={completeCheckout}
              className="px-6 py-2.5 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Complete Sale ({settings.currencySymbol}{cartTotal.toFixed(2)})</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: POST-SALE THERMAL RECEIPT & ACTION
  // ====================================================
  function renderPostSaleReceiptModal() {
    if (!lastSale) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-md bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col max-h-[90vh]">
          <div className="text-center pb-3 border-b border-[#e1e3e5] dark:border-[#303030]">
            <div className="w-12 h-12 rounded-full bg-[#e3f1df] text-[#008060] flex items-center justify-center mx-auto mb-2">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <h3 className="text-base font-bold text-[#202223] dark:text-white">Payment Approved</h3>
            <p className="text-xs font-mono text-[#008060] font-bold mt-0.5">
              {settings.currencySymbol}{lastSale.total.toFixed(2)} Paid ({lastSale.paymentMethod.toUpperCase()})
            </p>
          </div>

          {/* Thermal Receipt On-Screen Preview */}
          <div className="my-4 flex-1 overflow-y-auto bg-[#fafbfb] dark:bg-[#141414] p-4 rounded-lg border border-[#e1e3e5] dark:border-[#303030] font-mono text-xs text-[#202223] dark:text-[#ddd]">
            <div className="text-center space-y-0.5 pb-2 border-b border-dashed border-[#ccc]">
              <p className="font-bold text-sm">{settings.storeName}</p>
              <p className="text-[10px] text-[#666] dark:text-[#aaa]">{settings.storeAddress}</p>
              <p className="text-[10px] text-[#666] dark:text-[#aaa]">{settings.storePhone}</p>
            </div>

            <div className="py-2 text-[10px] border-b border-dashed border-[#ccc] space-y-0.5">
              <div className="flex justify-between">
                <span>Receipt:</span>
                <span>{lastSale.receiptNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span>{new Date(lastSale.date).toLocaleDateString()} {new Date(lastSale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="flex justify-between">
                <span>Cashier:</span>
                <span>{lastSale.cashier}</span>
              </div>
              {lastSale.customerName && (
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span>{lastSale.customerName}</span>
                </div>
              )}
            </div>

            {/* Items */}
            <div className="py-2 border-b border-dashed border-[#ccc] space-y-1">
              {lastSale.items.map((it, idx) => (
                <div key={idx} className="flex justify-between text-[11px]">
                  <span className="truncate pr-2">{it.quantity}x {it.product.name}</span>
                  <span className="shrink-0">{settings.currencySymbol}{((it.customPrice ?? it.product.price) * it.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="py-2 border-b border-dashed border-[#ccc] space-y-0.5 text-[11px]">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{settings.currencySymbol}{lastSale.subtotal.toFixed(2)}</span>
              </div>
              {lastSale.discountTotal > 0 && (
                <div className="flex justify-between text-[#005bd3]">
                  <span>Discount:</span>
                  <span>-{settings.currencySymbol}{lastSale.discountTotal.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Tax:</span>
                <span>{settings.currencySymbol}{lastSale.taxTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-xs pt-1">
                <span>Total:</span>
                <span>{settings.currencySymbol}{lastSale.total.toFixed(2)}</span>
              </div>
            </div>

            <div className="pt-2 text-center text-[10px] text-[#888] space-y-0.5">
              <p>{settings.receiptFooter}</p>
            </div>
          </div>

          <div className="pt-2 flex gap-2">
            <button
              onClick={handlePrintReceipt}
              className="flex-1 py-2.5 bg-white dark:bg-[#28292b] border border-[#c9cccf] dark:border-[#3b3c3e] text-[#202223] dark:text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 hover:bg-[#f1f2f4]"
            >
              <Printer className="w-4 h-4 text-[#008060]" />
              <span>Print Thermal Receipt</span>
            </button>
            <button
              onClick={() => {
                setShowReceiptModal(false);
                setLastSale(null);
              }}
              className="flex-1 py-2.5 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold rounded-lg transition-colors"
            >
              Start New Sale
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: REFUND RECEIPT
  // ====================================================
  function renderRefundReceiptModal() {
    if (!lastRefund) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-md bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] text-center">
          <div className="w-12 h-12 rounded-full bg-[#fee8e7] text-[#c01507] flex items-center justify-center mx-auto mb-2">
            <RotateCcw className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-[#202223] dark:text-white">Refund Completed & Restocked</h3>
          <p className="text-xs font-mono font-bold text-[#c01507] mt-1">
            {settings.currencySymbol}{lastRefund.totalRefunded.toFixed(2)} Restored
          </p>

          <p className="text-xs text-[#6d7175] my-4 leading-relaxed">
            Receipt <span className="font-mono font-bold text-[#202223] dark:text-white">{lastRefund.refundNumber}</span>.
            Returned products have been added back into active inventory quantities.
          </p>

          <div className="flex gap-2">
            <button
              onClick={handlePrintReceipt}
              className="flex-1 py-2 bg-white dark:bg-[#28292b] border border-[#c9cccf] text-xs font-semibold rounded-lg"
            >
              Print Return Slip
            </button>
            <button
              onClick={() => {
                setShowRefundReceiptModal(false);
                setLastRefund(null);
              }}
              className="flex-1 py-2 bg-[#202223] dark:bg-white text-white dark:text-[#202223] text-xs font-bold rounded-lg"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: QUICK REFUND / RETURN (IN-REGISTER)
  // ====================================================
  function renderQuickRefundModal() {
    const matchingSales = sales.filter(s => {
      const q = quickRefundSearch.toLowerCase().trim();
      if (!q) return true;
      return (
        s.receiptNumber.toLowerCase().includes(q) ||
        (s.customerName && s.customerName.toLowerCase().includes(q)) ||
        s.date.includes(q)
      );
    });

    const totalRefundCalculated = selectedSaleForRefund
      ? selectedSaleForRefund.items.reduce((sum, it) => {
          const q = refundItemQuantities[it.product.id] || 0;
          return sum + ((it.customPrice ?? it.product.price) * q);
        }, 0)
      : 0;

    const totalItemsToRefund = selectedSaleForRefund
      ? selectedSaleForRefund.items.reduce((sum, it) => {
          return sum + (refundItemQuantities[it.product.id] || 0);
        }, 0)
      : 0;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-2xl bg-white dark:bg-[#1e1f20] rounded-[14px] shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col max-h-[88vh] overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-[#e1e3e5] dark:border-[#303030] flex items-center justify-between bg-[#fafbfb] dark:bg-[#18191a]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#fee8e7] dark:bg-[#3d1a19] text-[#c01507] flex items-center justify-center shrink-0">
                <RotateCcw className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#202223] dark:text-white flex items-center gap-2">
                  Quick Return & Refund
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#f1f2f4] dark:bg-[#2b2c2e] text-[#5c5f62] dark:text-[#a6acb2]">
                    Register In-Cart
                  </span>
                </h3>
                <p className="text-xs text-[#6d7175] dark:text-[#8c9196]">
                  Process customer returns and restock inventory without clearing active sale
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setShowQuickRefundModal(false);
                setSelectedSaleForRefund(null);
              }}
              className="p-1.5 rounded-lg text-[#8c9196] hover:text-[#202223] dark:hover:text-white hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-4">
            {!selectedSaleForRefund ? (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-[#8c9196] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search past receipt # (REC-...), customer name, or date..."
                    value={quickRefundSearch}
                    onChange={e => setQuickRefundSearch(e.target.value)}
                    autoFocus
                    className="w-full pl-9 pr-8 py-2.5 text-xs bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008060] shadow-xs"
                  />
                  {quickRefundSearch && (
                    <button
                      onClick={() => setQuickRefundSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8c9196] hover:text-[#202223] dark:hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#6d7175] dark:text-[#a6acb2] font-medium px-1">
                  <span>Recent Completed Orders ({matchingSales.length})</span>
                  <span>Click an order to select items</span>
                </div>

                <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1">
                  {matchingSales.length === 0 ? (
                    <div className="p-8 text-center text-[#8c9196] text-xs bg-[#f9fafb] dark:bg-[#1a1a1a] rounded-lg border border-dashed border-[#d2d5d8] dark:border-[#303030]">
                      No orders found matching "{quickRefundSearch}".
                    </div>
                  ) : (
                    matchingSales.map(sale => (
                      <div
                        key={sale.id}
                        onClick={() => handleStartRefundForSale(sale)}
                        className="p-3.5 bg-white dark:bg-[#242526] hover:bg-[#f6f6f7] dark:hover:bg-[#2a2b2d] border border-[#e1e3e5] dark:border-[#383a3c] rounded-lg cursor-pointer transition-all flex items-center justify-between group shadow-2xs"
                      >
                        <div className="flex-1 min-w-0 pr-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold font-mono text-[#202223] dark:text-white group-hover:text-[#008060] transition-colors">
                              {sale.receiptNumber}
                            </span>
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded capitalize ${
                              sale.status === 'refunded'
                                ? 'bg-[#fee8e7] text-[#c01507]'
                                : 'bg-[#e3f1df] text-[#008060]'
                            }`}>
                              {sale.status.replace('_', ' ')}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-[11px] text-[#6d7175] dark:text-[#a6acb2]">
                            <span className="font-medium text-[#202223] dark:text-white">
                              {sale.customerName || 'Walk-in Customer'}
                            </span>
                            <span>·</span>
                            <span>{sale.items.reduce((s, it) => s + it.quantity, 0)} items</span>
                            <span>·</span>
                            <span>{new Date(sale.date).toLocaleDateString()} {new Date(sale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-sm font-mono font-bold text-[#202223] dark:text-white">
                            {settings.currencySymbol}{sale.total.toFixed(2)}
                          </span>
                          <span className="text-xs font-semibold text-[#008060] dark:text-[#2ecc71] flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                            Select <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Back button and sale overview */}
                <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030]">
                  <button
                    onClick={() => setSelectedSaleForRefund(null)}
                    className="text-xs font-semibold text-[#008060] dark:text-[#2ecc71] hover:underline flex items-center gap-1.5"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    Back to Orders List
                  </button>
                  <button
                    onClick={handleSelectAllRefundItems}
                    className="text-xs font-semibold text-[#008060] hover:underline"
                  >
                    Select All Items
                  </button>
                </div>

                {/* Selected Sale info banner */}
                <div className="p-3 bg-[#f6f6f7] dark:bg-[#252627] rounded-lg text-xs grid grid-cols-3 gap-2 border border-[#e1e3e5] dark:border-[#383a3c]">
                  <div>
                    <span className="text-[#6d7175] dark:text-[#8c9196] block text-[10px] uppercase font-bold">Receipt</span>
                    <span className="font-mono font-bold text-[#202223] dark:text-white">{selectedSaleForRefund.receiptNumber}</span>
                  </div>
                  <div>
                    <span className="text-[#6d7175] dark:text-[#8c9196] block text-[10px] uppercase font-bold">Customer</span>
                    <span className="font-medium text-[#202223] dark:text-white truncate block">
                      {selectedSaleForRefund.customerName || 'Walk-in Customer'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#6d7175] dark:text-[#8c9196] block text-[10px] uppercase font-bold">Original Total</span>
                    <span className="font-mono font-bold text-[#202223] dark:text-white">
                      {settings.currencySymbol}{selectedSaleForRefund.total.toFixed(2)} ({selectedSaleForRefund.paymentMethod})
                    </span>
                  </div>
                </div>

                {/* Items to refund */}
                <div>
                  <h4 className="text-xs font-bold text-[#202223] dark:text-white uppercase tracking-wider mb-2">
                    Specify Return Quantities
                  </h4>
                  <div className="space-y-2 max-h-[38vh] overflow-y-auto pr-1">
                    {selectedSaleForRefund.items.map(it => {
                      const selectedQty = refundItemQuantities[it.product.id] || 0;
                      const unitPrice = it.customPrice ?? it.product.price;
                      const lineRefund = unitPrice * selectedQty;

                      return (
                        <div
                          key={it.product.id}
                          className={`p-3 border rounded-lg flex items-center justify-between transition-colors ${
                            selectedQty > 0
                              ? 'bg-[#fee8e7]/20 border-[#c01507]/40 dark:border-[#c01507]/40'
                              : 'bg-white dark:bg-[#242526] border-[#e1e3e5] dark:border-[#383a3c]'
                          }`}
                        >
                          <div className="flex-1 min-w-0 pr-3">
                            <p className="text-xs font-semibold text-[#202223] dark:text-white truncate">
                              {it.product.name}
                            </p>
                            <p className="text-[11px] text-[#6d7175] dark:text-[#a6acb2]">
                              {settings.currencySymbol}{unitPrice.toFixed(2)} × {it.quantity} purchased
                            </p>
                          </div>

                          <div className="flex items-center gap-3 shrink-0">
                            {/* Stepper */}
                            <div className="flex items-center border border-[#d2d5d8] dark:border-[#383a3c] rounded-md bg-white dark:bg-[#1a1a1a]">
                              <button
                                onClick={() => {
                                  setRefundItemQuantities(prev => ({
                                    ...prev,
                                    [it.product.id]: Math.max(0, (prev[it.product.id] || 0) - 1)
                                  }));
                                }}
                                className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c] transition-colors"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="w-8 text-center text-xs font-mono font-bold">
                                {selectedQty}
                              </span>
                              <button
                                onClick={() => {
                                  setRefundItemQuantities(prev => ({
                                    ...prev,
                                    [it.product.id]: Math.min(it.quantity, (prev[it.product.id] || 0) + 1)
                                  }));
                                }}
                                className="w-7 h-7 flex items-center justify-center hover:bg-[#f1f2f4] dark:hover:bg-[#2a2b2c] transition-colors"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            <span className="w-16 text-right font-mono font-bold text-xs text-[#202223] dark:text-white">
                              {settings.currencySymbol}{lineRefund.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Reason Selection */}
                <div>
                  <label className="block text-xs font-semibold text-[#6d7175] dark:text-[#a6acb2] mb-1">
                    Return Reason
                  </label>
                  <select
                    value={refundReason}
                    onChange={e => setRefundReason(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white dark:bg-[#242526] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white rounded-lg focus:ring-2 focus:ring-[#008060] outline-none font-medium shadow-xs"
                  >
                    <option value="Customer returned goods">Customer returned goods</option>
                    <option value="Defective or damaged">Defective or damaged</option>
                    <option value="Wrong size or variant">Wrong size or variant</option>
                    <option value="Customer changed mind">Customer changed mind</option>
                    <option value="Accidental duplicate charge">Accidental duplicate charge</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="p-4 border-t border-[#e1e3e5] dark:border-[#303030] bg-[#fafbfb] dark:bg-[#18191a] flex items-center justify-between">
            {selectedSaleForRefund ? (
              <>
                <div>
                  <span className="text-[11px] text-[#6d7175] dark:text-[#a6acb2] block">
                    {totalItemsToRefund} {totalItemsToRefund === 1 ? 'item' : 'items'} to restock · Total Refund:
                  </span>
                  <div className="text-lg font-bold font-mono text-[#c01507]">
                    {settings.currencySymbol}{totalRefundCalculated.toFixed(2)}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedSaleForRefund(null);
                    }}
                    className="px-3 py-2 border border-[#c9cccf] dark:border-[#4d5053] text-xs font-semibold rounded-lg text-[#5c5f62] dark:text-[#a6acb2]"
                  >
                    Cancel Selection
                  </button>
                  <button
                    onClick={handleProcessRefund}
                    disabled={totalItemsToRefund === 0}
                    className={`px-5 py-2.5 text-white text-xs font-bold rounded-lg transition-colors shadow-xs flex items-center gap-1.5 ${
                      totalItemsToRefund > 0
                        ? 'bg-[#c01507] hover:bg-[#9f1105] cursor-pointer'
                        : 'bg-[#d2d5d8] dark:bg-[#383a3c] text-white/60 cursor-not-allowed'
                    }`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Confirm Refund & Restock</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="w-full flex justify-end">
                <button
                  onClick={() => setShowQuickRefundModal(false)}
                  className="px-4 py-2 border border-[#c9cccf] dark:border-[#4d5053] text-xs font-semibold rounded-lg text-[#5c5f62] dark:text-[#a6acb2]"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: ADD DISCOUNT (SHOPIFY BLUE ACCENT SYSTEM)
  // ====================================================
  function renderDiscountModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030]">
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030] mb-3">
            <h3 className="text-sm font-bold text-[#005bd3] dark:text-[#3f88e8] flex items-center gap-1.5">
              <Tag className="w-4 h-4" /> Add Cart Discount
            </h3>
            <button onClick={() => setShowDiscountModal(false)}>
              <X className="w-4 h-4 text-[#8c9196]" />
            </button>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex rounded-lg overflow-hidden border border-[#d2d5d8] dark:border-[#383a3c]">
              <button
                type="button"
                onClick={() => setDiscountType('percent')}
                className={`flex-1 py-2 font-bold ${
                  discountType === 'percent'
                    ? 'bg-[#005bd3] text-white'
                    : 'bg-[#f6f6f7] dark:bg-[#252627] text-[#5c5f62] dark:text-[#a6acb2]'
                }`}
              >
                Percentage (%)
              </button>
              <button
                type="button"
                onClick={() => setDiscountType('fixed')}
                className={`flex-1 py-2 font-bold ${
                  discountType === 'fixed'
                    ? 'bg-[#005bd3] text-white'
                    : 'bg-[#f6f6f7] dark:bg-[#252627] text-[#5c5f62] dark:text-[#a6acb2]'
                }`}
              >
                Fixed Amount ($)
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">
                {discountType === 'percent' ? 'Discount Percentage (%)' : 'Discount Value ($)'}
              </label>
              <input
                type="number"
                step="0.01"
                placeholder={discountType === 'percent' ? '10' : '5.00'}
                value={discountInputVal}
                onChange={e => setDiscountInputVal(e.target.value)}
                className="w-full text-base font-bold font-mono p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg shadow-xs focus:ring-2 focus:ring-[#005bd3] outline-none"
              />
            </div>

            {/* Quick Preset Discount Buttons (5%, 10%, 15%, 20%) - Displayed only in Percentage mode */}
            {discountType === 'percent' && (
              <div className="space-y-1.5 pt-1">
                <label className="block text-[11px] font-bold text-[#5c5f62] dark:text-[#a6acb2] uppercase tracking-wider">
                  Quick Discount Presets
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[5, 10, 15, 20].map(pct => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => {
                        setDiscountType('percent');
                        setDiscountInputVal(pct.toString());
                        triggerSound('beep');
                      }}
                      className={`py-2 px-2.5 rounded-lg border text-xs font-bold font-mono transition-all cursor-pointer ${
                        discountType === 'percent' && discountInputVal === pct.toString()
                          ? 'bg-[#005bd3] text-white border-[#005bd3] shadow-xs'
                          : 'bg-white dark:bg-[#242526] text-[#202223] dark:text-white border-[#8c9196] dark:border-[#4d5053] hover:border-[#005bd3] hover:text-[#005bd3] dark:hover:text-[#3f88e8]'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setCartDiscount(null);
                  setShowDiscountModal(false);
                }}
                className="px-3 py-1.5 text-xs font-medium text-[#c01507]"
              >
                Remove Discount
              </button>
              <button
                type="button"
                onClick={() => {
                  const val = parseFloat(discountInputVal);
                  if (!isNaN(val) && val > 0) {
                    setCartDiscount({ type: discountType, value: val });
                    triggerSound('beep');
                  }
                  setShowDiscountModal(false);
                }}
                className="px-4 py-1.5 bg-[#005bd3] hover:bg-[#004bb0] text-white font-bold rounded-lg"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: SELECT CUSTOMER
  // ====================================================
  function renderCustomerModal() {
    const filtered = customers.filter(c =>
      c.name.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
      c.email.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
      c.phone.includes(customerSearchQuery)
    );

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-md bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col max-h-[85vh]">
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030]">
            <h3 className="text-sm font-bold text-[#202223] dark:text-white">Attach Customer to Sale</h3>
            <button onClick={() => setShowCustomerModal(false)}>
              <X className="w-4 h-4 text-[#8c9196]" />
            </button>
          </div>

          <div className="my-3">
            <input
              type="text"
              placeholder="Search by customer name, email, phone..."
              value={customerSearchQuery}
              onChange={e => setCustomerSearchQuery(e.target.value)}
              className="w-full p-2.5 text-xs bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
            />
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[#f1f2f4] dark:divide-[#2e3032]">
            {filtered.map(cust => (
              <div
                key={cust.id}
                onClick={() => {
                  setSelectedCustomer(cust);
                  setShowCustomerModal(false);
                  triggerSound('beep');
                }}
                className="p-3 hover:bg-[#f6f6f7] dark:hover:bg-[#242526] cursor-pointer flex items-center justify-between rounded-md transition-colors group"
              >
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <div className="w-7 h-7 rounded-full bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5] font-bold text-xs flex items-center justify-center shrink-0">
                    {cust.name[0]?.toUpperCase() || '?'}
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-xs font-semibold text-[#202223] dark:text-white truncate">{cust.name}</p>
                    <p className="text-[11px] text-[#8c9196] truncate">{cust.email || cust.phone || 'No contact info'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowCustomerModal(false);
                      handleOpenCustomerHistory(cust);
                    }}
                    title={`View ${cust.name}'s purchase history`}
                    className="p-1.5 text-[#8c9196] hover:text-[#008060] hover:bg-[#e3f1df]/60 dark:hover:bg-[#004e38]/50 rounded-md transition-colors"
                  >
                    <Clock className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowCustomerModal(false);
                      handleOpenEditCustomer(cust);
                    }}
                    title={`Edit ${cust.name}`}
                    className="p-1.5 text-[#8c9196] hover:text-[#008060] hover:bg-[#e3f1df]/60 dark:hover:bg-[#004e38]/50 rounded-md transition-colors"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  <ChevronRight className="w-4 h-4 text-[#8c9196]" />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-[#e1e3e5] dark:border-[#303030] flex justify-between items-center">
            <button
              onClick={() => {
                setShowCustomerModal(false);
                setShowNewCustomerModal(true);
              }}
              className="text-xs font-semibold text-[#008060] hover:underline"
            >
              + Create New Customer
            </button>
            <button
              onClick={() => setShowCustomerModal(false)}
              className="px-3 py-1.5 border border-[#c9cccf] text-xs rounded-lg"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: CREATE NEW CUSTOMER
  // ====================================================
  function renderNewCustomerModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030]">
          <div className="flex items-center justify-between pb-3 border-b border-[#e1e3e5] dark:border-[#303030] mb-3">
            <h3 className="text-sm font-bold text-[#202223] dark:text-white">New Customer Profile</h3>
            <button onClick={() => setShowNewCustomerModal(false)}>
              <X className="w-4 h-4 text-[#8c9196]" />
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const fd = new FormData(form);
              const newC: Customer = {
                id: `cust-${Date.now()}`,
                name: (fd.get('name') as string).trim(),
                email: (fd.get('email') as string).trim(),
                phone: (fd.get('phone') as string).trim(),
                notes: (fd.get('notes') as string).trim(),
                totalOrders: 0,
                totalSpent: 0,
                createdAt: new Date().toISOString().slice(0, 10)
              };
              setCustomers(prev => [newC, ...prev]);
              setSelectedCustomer(newC);
              setShowNewCustomerModal(false);
              triggerSound('success');
            }}
            className="space-y-3 text-xs"
          >
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Full Name *</label>
              <input required name="name" placeholder="Customer full name..." className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Email Address</label>
              <input type="email" name="email" placeholder="customer@example.com" className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Phone Number</label>
              <input name="phone" placeholder="+1 (555) 000-0000" className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg font-mono text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">Customer Notes</label>
              <textarea name="notes" rows={2} placeholder="Customer preferences, VIP notes, remarks..." className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none" />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowNewCustomerModal(false)}
                className="px-3 py-1.5 border border-[#c9cccf] rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#008060] text-white font-bold rounded-lg"
              >
                Save & Attach
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: EDIT CUSTOMER DETAILS (DIRECTORY)
  // ====================================================
  function renderEditCustomerModal() {
    if (!editingCustomer) return null;

    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto"
        onClick={(e) => {
          if (e.target === e.currentTarget && !editConfirmDelete) {
            setShowEditCustomerModal(false);
            setEditingCustomer(null);
          }
        }}
      >
        <div className="w-full max-w-lg bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col my-auto">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-[#e1e3e5] dark:border-[#303030]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5] font-bold text-sm flex items-center justify-center shrink-0 shadow-2xs">
                {editingCustomer.name[0]?.toUpperCase() || '?'}
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#202223] dark:text-white flex items-center gap-2">
                  <span>Edit Customer Details</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#f1f2f4] dark:bg-[#2b2c2e] text-[#6d7175] dark:text-[#a6acb2] font-normal">
                    {editingCustomer.id}
                  </span>
                </h3>
                <p className="text-xs text-[#8c9196] mt-0.5">
                  Update customer contact information and notes
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setShowEditCustomerModal(false);
                setEditingCustomer(null);
                setEditConfirmDelete(false);
              }}
              className="p-1 rounded-md text-[#8c9196] hover:text-[#202223] dark:hover:text-white hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e] transition-colors"
              title="Close modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Account Metrics with Purchase History Quick Link */}
          <div className="grid grid-cols-3 gap-2.5 py-3 my-3 bg-[#f9fafb] dark:bg-[#171819] rounded-lg border border-[#e1e3e5] dark:border-[#2e3032] px-3">
            <button
              type="button"
              onClick={() => {
                const target = editingCustomer;
                setShowEditCustomerModal(false);
                setEditingCustomer(null);
                handleOpenCustomerHistory(target);
              }}
              className="text-left group/btn cursor-pointer p-1 rounded hover:bg-[#e3f1df]/50 dark:hover:bg-[#004e38]/30 transition-colors"
              title="Click to view purchase history & products bought"
            >
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider flex items-center gap-1 group-hover/btn:text-[#008060]">
                <span>Total Orders</span>
                <Clock className="w-2.5 h-2.5 text-[#008060]" />
              </span>
              <span className="text-sm font-mono font-bold text-[#008060] underline decoration-dotted flex items-center gap-1">
                <span>{editingCustomer.totalOrders}</span>
                <span className="text-[10px] font-sans font-normal text-[#8c9196]">(History)</span>
              </span>
            </button>
            <div className="p-1">
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Lifetime Spent</span>
              <span className="text-sm font-mono font-bold text-[#008060]">
                {settings.currencySymbol}{editingCustomer.totalSpent.toFixed(2)}
              </span>
            </div>
            <div className="p-1">
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Member Since</span>
              <span className="text-xs text-[#5c5f62] dark:text-[#a6acb2] font-mono truncate block mt-0.5">
                {editingCustomer.createdAt || 'N/A'}
              </span>
            </div>
          </div>

          {/* Delete Customer Confirmation Banner */}
          {editConfirmDelete ? (
            <div className="p-4 bg-[#fee8e7] dark:bg-[#341615] border border-[#f5b8b5] dark:border-[#60201e] rounded-lg my-2 space-y-3">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-[#c01507] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-[#c01507] dark:text-[#ff8f87]">Permanently delete this customer?</h4>
                  <p className="text-xs text-[#5c5f62] dark:text-[#e4e5e7] mt-1 leading-relaxed">
                    Are you sure you want to delete <strong className="text-[#202223] dark:text-white">{editingCustomer.name}</strong>? This will remove the profile from your customer directory. Historical sale receipts will retain their line items for accounting.
                  </p>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setEditConfirmDelete(false)}
                  className="px-3 py-1.5 bg-white dark:bg-[#202123] border border-[#d2d5d8] dark:border-[#4d5053] text-[#202223] dark:text-white text-xs font-semibold rounded-lg hover:bg-[#f6f6f7] dark:hover:bg-[#2a2b2d] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteCustomer}
                  className="px-3.5 py-1.5 bg-[#c01507] hover:bg-[#9e1005] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Yes, Delete Customer</span>
                </button>
              </div>
            </div>
          ) : (
            /* Edit Form */
            <form onSubmit={handleSaveEditCustomer} className="space-y-3.5 text-xs">
              {editFormError && (
                <div className="p-2.5 bg-[#fee8e7] dark:bg-[#341615] border border-[#f5b8b5] dark:border-[#60201e] text-[#c01507] dark:text-[#ff8f87] text-xs rounded-lg flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{editFormError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">
                  Full Name <span className="text-[#c01507]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={editFormName}
                  onChange={(e) => {
                    setEditFormName(e.target.value);
                    if (editFormError) setEditFormError('');
                  }}
                  placeholder="e.g. Eleanor Vance"
                  className={`w-full p-2.5 bg-white dark:bg-[#202123] border ${
                    editFormError ? 'border-[#c01507] focus:ring-[#c01507]' : 'border-[#8c9196] dark:border-[#4d5053] focus:ring-[#008060]'
                  } text-[#111213] dark:text-white placeholder:text-[#8c9196] rounded-lg text-xs font-medium shadow-xs focus:ring-2 outline-none transition-all`}
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={editFormEmail}
                    onChange={(e) => setEditFormEmail(e.target.value)}
                    placeholder="customer@example.com"
                    className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#8c9196] rounded-lg text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={editFormPhone}
                    onChange={(e) => setEditFormPhone(e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#8c9196] rounded-lg font-mono text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111213] dark:text-[#f1f2f4] mb-1">
                  Customer Notes & Preferences
                </label>
                <textarea
                  rows={3}
                  value={editFormNotes}
                  onChange={(e) => setEditFormNotes(e.target.value)}
                  placeholder="Preferences, preferred contact times, allergies, VIP remarks..."
                  className="w-full p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#8c9196] rounded-lg text-xs font-medium shadow-xs focus:ring-2 focus:ring-[#008060] outline-none transition-all resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#e1e3e5] dark:border-[#303030]">
                <button
                  type="button"
                  onClick={() => setEditConfirmDelete(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#c01507] hover:text-[#9e1005] hover:bg-[#fee8e7] dark:hover:bg-[#341615] rounded-lg border border-transparent hover:border-[#f5b8b5] dark:hover:border-[#60201e] transition-colors"
                  title="Delete customer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Customer</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditCustomerModal(false);
                      setEditingCustomer(null);
                      setEditFormError('');
                    }}
                    className="px-3.5 py-2 border border-[#d2d5d8] dark:border-[#4d5053] text-[#202223] dark:text-white text-xs font-semibold rounded-lg hover:bg-[#f6f6f7] dark:hover:bg-[#26282a] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: CUSTOMER PURCHASE HISTORY ("WHAT HE BUY BEFORE")
  // ====================================================
  function renderCustomerHistoryModal() {
    if (!viewingCustomerHistory) return null;

    const customerSales = getCustomerSales(viewingCustomerHistory);
    const purchasedItems = getCustomerPurchasedItems(viewingCustomerHistory);
    const totalUnitsBought = purchasedItems.reduce((sum, item) => sum + item.totalQuantity, 0);
    const avgOrderValue = customerSales.length > 0 ? (viewingCustomerHistory.totalSpent / customerSales.length) : 0;

    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            setViewingCustomerHistory(null);
          }
        }}
      >
        <div className="w-full max-w-3xl bg-white dark:bg-[#1e1f20] rounded-[14px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030] flex flex-col my-auto max-h-[90vh]">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-[#e1e3e5] dark:border-[#303030] shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5] font-bold text-base flex items-center justify-center shrink-0 shadow-2xs">
                {viewingCustomerHistory.name[0]?.toUpperCase() || '?'}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-[#202223] dark:text-white">
                    {viewingCustomerHistory.name}
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#f1f2f4] dark:bg-[#2b2c2e] text-[#6d7175] dark:text-[#a6acb2]">
                    {viewingCustomerHistory.id}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5]">
                    {customerSales.length} {customerSales.length === 1 ? 'Order' : 'Orders'}
                  </span>
                </div>
                <p className="text-xs text-[#8c9196] mt-0.5 flex items-center gap-2">
                  <span>{viewingCustomerHistory.email || 'No email'}</span>
                  <span>·</span>
                  <span>{viewingCustomerHistory.phone || 'No phone'}</span>
                  {viewingCustomerHistory.createdAt && (
                    <>
                      <span>·</span>
                      <span>Member since {viewingCustomerHistory.createdAt}</span>
                    </>
                  )}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const target = viewingCustomerHistory;
                  setViewingCustomerHistory(null);
                  handleOpenEditCustomer(target);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#202223] dark:text-white bg-[#f1f2f4] dark:bg-[#2b2c2e] hover:bg-[#e4e5e7] dark:hover:bg-[#393a3d] border border-[#d2d5d8] dark:border-[#404040] rounded-lg transition-colors cursor-pointer shadow-2xs"
                title="Edit customer contact details"
              >
                <Edit className="w-3.5 h-3.5 text-[#008060]" />
                <span>Edit Profile</span>
              </button>
              <button
                onClick={() => setViewingCustomerHistory(null)}
                className="p-1.5 rounded-md text-[#8c9196] hover:text-[#202223] dark:hover:text-white hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e] transition-colors cursor-pointer"
                title="Close purchase history"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 py-3 my-3 bg-[#f9fafb] dark:bg-[#171819] rounded-xl border border-[#e1e3e5] dark:border-[#2e3032] px-4 shrink-0">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Total Spent</span>
              <span className="text-base font-mono font-bold text-[#008060]">
                {settings.currencySymbol}{viewingCustomerHistory.totalSpent.toFixed(2)}
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Total Orders</span>
              <span className="text-base font-mono font-bold text-[#202223] dark:text-white">
                {customerSales.length}
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Products Bought</span>
              <span className="text-base font-mono font-bold text-[#202223] dark:text-white">
                {purchasedItems.length} ({totalUnitsBought} units)
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#8c9196] tracking-wider block">Avg Order Value</span>
              <span className="text-base font-mono font-bold text-[#202223] dark:text-white">
                {settings.currencySymbol}{avgOrderValue.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Tab Navigation: What they bought vs Chronological Receipts */}
          <div className="flex items-center justify-between border-b border-[#e1e3e5] dark:border-[#303030] pb-2 mb-3 shrink-0">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCustomerHistoryTab('items')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  customerHistoryTab === 'items'
                    ? 'bg-[#008060] text-white shadow-xs'
                    : 'text-[#5c5f62] dark:text-[#a6acb2] hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e]'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                <span>What He Bought Before ({purchasedItems.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setCustomerHistoryTab('orders')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  customerHistoryTab === 'orders'
                    ? 'bg-[#008060] text-white shadow-xs'
                    : 'text-[#5c5f62] dark:text-[#a6acb2] hover:bg-[#f1f2f4] dark:hover:bg-[#2b2c2e]'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Orders & Receipts ({customerSales.length})</span>
              </button>
            </div>
            <div className="text-xs text-[#8c9196] hidden sm:block">
              {customerHistoryTab === 'items'
                ? 'Itemized list of products purchased by this customer'
                : 'Full order history and sale slips'}
            </div>
          </div>

          {/* Tab Content: Scrollable Body */}
          <div className="flex-1 overflow-y-auto pr-1">
            {customerHistoryTab === 'items' ? (
              // Tab 1: Products Bought Before
              purchasedItems.length > 0 ? (
                <div className="space-y-2.5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {purchasedItems.map(item => {
                      const inStock = item.product.stock > 0;
                      return (
                        <div
                          key={item.product.id}
                          className="p-3 bg-[#fdfdfd] dark:bg-[#1a1b1c] rounded-xl border border-[#e1e3e5] dark:border-[#2e3032] flex items-center justify-between gap-3 shadow-2xs hover:border-[#008060] transition-colors group"
                        >
                          <div className="flex items-center gap-3 overflow-hidden min-w-0">
                            {item.product.image ? (
                              <img
                                src={item.product.image}
                                alt={item.product.name}
                                className="w-12 h-12 object-cover rounded-lg shrink-0 border border-[#e1e3e5] dark:border-[#303030]"
                              />
                            ) : (
                              <div className="w-12 h-12 rounded-lg bg-[#f1f2f4] dark:bg-[#2a2b2d] flex items-center justify-center text-[#8c9196] shrink-0 font-bold text-sm">
                                {item.product.name.slice(0, 2).toUpperCase()}
                              </div>
                            )}
                            <div className="overflow-hidden min-w-0">
                              <h4 className="text-xs font-bold text-[#202223] dark:text-white truncate group-hover:text-[#008060] transition-colors">
                                {item.product.name}
                              </h4>
                              <div className="flex items-center gap-2 text-[10px] text-[#8c9196] mt-0.5">
                                <span>SKU: {item.product.sku}</span>
                                <span>·</span>
                                <span>{item.product.category}</span>
                              </div>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5]">
                                  Bought {item.totalQuantity}x ({settings.currencySymbol}{item.totalSpent.toFixed(2)})
                                </span>
                                <span className="text-[10px] text-[#8c9196]">
                                  Last: {new Date(item.lastDate).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-1.5 shrink-0">
                            <span className="text-xs font-bold font-mono text-[#202223] dark:text-white">
                              {settings.currencySymbol}{item.product.price.toFixed(2)}
                            </span>
                            <button
                              onClick={() => handleReorderProduct(item.product, 1)}
                              disabled={!inStock}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all shadow-2xs ${
                                inStock
                                  ? 'bg-[#008060] hover:bg-[#006e52] text-white cursor-pointer active:scale-95'
                                  : 'bg-[#f1f2f4] dark:bg-[#2a2b2d] text-[#8c9196] cursor-not-allowed'
                              }`}
                              title={inStock ? `Add ${item.product.name} to active cart` : 'Out of stock'}
                            >
                              <Plus className="w-3 h-3" />
                              <span>{inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-[#f1f2f4] dark:bg-[#26282a] flex items-center justify-center text-[#8c9196] mb-3">
                    <Package className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-[#202223] dark:text-white">No items purchased yet</h4>
                  <p className="text-xs text-[#8c9196] mt-1 max-w-sm">
                    {viewingCustomerHistory.name} hasn't completed any sales yet. Ring up a sale with this customer attached to track their purchased items!
                  </p>
                </div>
              )
            ) : (
              // Tab 2: Chronological Orders & Receipts
              customerSales.length > 0 ? (
                <div className="space-y-3">
                  {customerSales.map(sale => (
                    <div
                      key={sale.id}
                      className="p-4 bg-[#fdfdfd] dark:bg-[#1a1b1c] rounded-xl border border-[#e1e3e5] dark:border-[#2e3032] space-y-3 shadow-2xs"
                    >
                      {/* Order Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-[#e1e3e5] dark:border-[#2c2d2e]">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Receipt className="w-4 h-4 text-[#008060]" />
                          <span className="text-xs font-bold font-mono text-[#202223] dark:text-white">
                            {sale.receiptNumber}
                          </span>
                          <span className="text-[11px] text-[#8c9196]">
                            {new Date(sale.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#f1f2f4] dark:bg-[#2b2c2e] text-[#5c5f62] dark:text-[#a6acb2]">
                            {sale.paymentMethod}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            sale.status === 'completed'
                              ? 'bg-[#e3f1df] dark:bg-[#004e38] text-[#008060] dark:text-[#98f2d5]'
                              : 'bg-[#fee8e7] dark:bg-[#341615] text-[#c01507] dark:text-[#ff8f87]'
                          }`}>
                            {sale.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handlePrintPastSaleSlip(sale)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#202223] dark:text-white bg-[#f1f2f4] dark:bg-[#2b2c2e] hover:bg-[#e4e5e7] dark:hover:bg-[#393a3d] border border-[#d2d5d8] dark:border-[#404040] rounded-lg transition-colors shadow-2xs cursor-pointer"
                            title="View or print receipt"
                          >
                            <Printer className="w-3.5 h-3.5 text-[#008060]" />
                            <span>Receipt</span>
                          </button>
                          <button
                            onClick={() => handleReorderSale(sale)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-white bg-[#008060] hover:bg-[#006e52] rounded-lg transition-colors shadow-2xs cursor-pointer"
                            title="Add all items from this order into current cart"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Re-order All</span>
                          </button>
                        </div>
                      </div>

                      {/* Line Items List */}
                      <div className="space-y-1.5 text-xs">
                        <div className="grid grid-cols-12 text-[10px] uppercase font-bold text-[#8c9196] px-1 pb-1">
                          <span className="col-span-6">Item</span>
                          <span className="col-span-2 text-center">Qty</span>
                          <span className="col-span-2 text-right">Price</span>
                          <span className="col-span-2 text-right">Total</span>
                        </div>
                        {sale.items.map((it, idx) => {
                          const unitPrice = it.customPrice ?? it.product.price;
                          const lineTotal = unitPrice * it.quantity;
                          return (
                            <div
                              key={`${it.product.id}-${idx}`}
                              className="grid grid-cols-12 items-center p-2 rounded-lg bg-[#f9fafb] dark:bg-[#202123] border border-[#f1f2f4] dark:border-[#2a2b2d]"
                            >
                              <div className="col-span-6 flex items-center gap-2 overflow-hidden min-w-0 pr-2">
                                <span className="font-semibold text-[#202223] dark:text-white truncate">
                                  {it.product.name}
                                </span>
                                <span className="text-[10px] font-mono text-[#8c9196] shrink-0">
                                  {it.product.sku}
                                </span>
                              </div>
                              <div className="col-span-2 text-center font-mono font-bold text-[#202223] dark:text-white">
                                {it.quantity}x
                              </div>
                              <div className="col-span-2 text-right font-mono text-[#5c5f62] dark:text-[#a6acb2]">
                                {settings.currencySymbol}{unitPrice.toFixed(2)}
                              </div>
                              <div className="col-span-2 text-right font-mono font-bold text-[#008060]">
                                {settings.currencySymbol}{lineTotal.toFixed(2)}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Order Totals Footer */}
                      <div className="flex justify-between items-center pt-2 border-t border-[#f1f2f4] dark:border-[#2c2d2e] text-xs">
                        <span className="text-[#8c9196] text-[11px]">
                          Cashier: {sale.cashier} {sale.note ? `· Note: "${sale.note}"` : ''}
                        </span>
                        <div className="flex items-center gap-4 text-xs font-mono">
                          {sale.discountTotal > 0 && (
                            <span className="text-[#c01507]">
                              Disc: -{settings.currencySymbol}{sale.discountTotal.toFixed(2)}
                            </span>
                          )}
                          <span className="text-[#5c5f62] dark:text-[#a6acb2]">
                            Tax: {settings.currencySymbol}{sale.taxTotal.toFixed(2)}
                          </span>
                          <span className="text-sm font-bold text-[#202223] dark:text-white">
                            Total: <span className="text-[#008060]">{settings.currencySymbol}{sale.total.toFixed(2)}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-[#f1f2f4] dark:bg-[#26282a] flex items-center justify-center text-[#8c9196] mb-3">
                    <Receipt className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-[#202223] dark:text-white">No sales history</h4>
                  <p className="text-xs text-[#8c9196] mt-1 max-w-sm">
                    No orders have been recorded under {viewingCustomerHistory.name}.
                  </p>
                </div>
              )
            )}
          </div>

          {/* Modal Footer */}
          <div className="pt-3 border-t border-[#e1e3e5] dark:border-[#303030] flex justify-between items-center shrink-0 mt-3">
            <span className="text-xs text-[#8c9196]">
              {purchasedItems.length} distinct products purchased across {customerSales.length} orders
            </span>
            <button
              type="button"
              onClick={() => setViewingCustomerHistory(null)}
              className="px-4 py-2 bg-[#202223] dark:bg-white text-white dark:text-[#202223] text-xs font-bold rounded-lg hover:opacity-90 transition-opacity cursor-pointer shadow-xs"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: ORDER NOTE
  // ====================================================
  function renderNoteModal() {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#e1e3e5] dark:border-[#303030]">
          <h3 className="text-sm font-bold text-[#202223] dark:text-white mb-2">Order Memo / Note</h3>
          <textarea
            rows={3}
            value={noteInput}
            onChange={e => setNoteInput(e.target.value)}
            placeholder="Special instructions, gift wrapping note, or delivery memo..."
            className="w-full text-xs p-2.5 bg-white dark:bg-[#202123] border border-[#8c9196] dark:border-[#4d5053] text-[#111213] dark:text-white placeholder:text-[#5c5f62] dark:placeholder:text-[#9ea3a8] rounded-lg mb-3 shadow-xs focus:ring-2 focus:ring-[#008060] outline-none"
          />
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setShowNoteModal(false)}
              className="px-3 py-1.5 border border-[#c9cccf] text-xs rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                setOrderNote(noteInput);
                setShowNoteModal(false);
              }}
              className="px-4 py-1.5 bg-[#008060] text-white text-xs font-bold rounded-lg"
            >
              Save Note
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MODAL: DELETE PRODUCT CONFIRMATION
  // ====================================================
  function renderDeleteConfirmationModal() {
    const prodToDelete = products.find(p => p.id === deletingProductId);
    if (!prodToDelete) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm bg-white dark:bg-[#1e1f20] rounded-[12px] p-6 shadow-2xl border border-[#fee8e7] dark:border-[#3d1a19] text-center">
          <div className="w-10 h-10 rounded-full bg-[#fee8e7] text-[#c01507] flex items-center justify-center mx-auto mb-3">
            <Trash2 className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-[#202223] dark:text-white">Delete Product from Inventory?</h3>
          <p className="text-xs text-[#6d7175] my-2">
            Are you sure you want to permanently remove <span className="font-semibold text-[#202223] dark:text-white">"{prodToDelete.name}"</span>?
          </p>
          <div className="flex justify-end gap-2 mt-4">
            <button
              onClick={() => setDeletingProductId(null)}
              className="flex-1 py-2 border border-[#c9cccf] text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={() => handleDeleteProduct(prodToDelete.id)}
              className="flex-1 py-2 bg-[#c01507] hover:bg-[#9f1105] text-white text-xs font-bold rounded-lg"
            >
              Delete Product
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // THERMAL RECEIPT (STANDALONE CLEAN DOM FOR PRINTING)
  // ====================================================
  function renderPrintableThermalReceipt(sale?: Sale) {
    if (!sale) return null;

    return (
      <div style={{ width: settings.paperWidth === '58mm' ? '58mm' : '80mm', margin: '0 auto', fontFamily: 'monospace', fontSize: '11px', lineHeight: '1.4' }}>
        <div style={{ textAlign: 'center', marginBottom: '8px' }}>
          <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{settings.storeName.toUpperCase()}</div>
          <div style={{ fontSize: '9px' }}>{settings.storeAddress}</div>
          <div style={{ fontSize: '9px' }}>TEL: {settings.storePhone}</div>
          <div style={{ fontSize: '9px' }}>{settings.storeEmail}</div>
        </div>

        <div style={{ borderTop: '1px dashed #000', borderBottom: '1px dashed #000', padding: '4px 0', margin: '6px 0', fontSize: '10px' }}>
          <div>RECEIPT: {sale.receiptNumber}</div>
          <div>DATE: {new Date(sale.date).toLocaleString()}</div>
          <div>CASHIER: {sale.cashier}</div>
          {sale.customerName && <div>CUSTOMER: {sale.customerName}</div>}
        </div>

        <div style={{ margin: '6px 0' }}>
          {sale.items.map((it, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '70%' }}>
                {it.quantity}x {it.product.name}
              </span>
              <span>{settings.currencySymbol}{((it.customPrice ?? it.product.price) * it.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>

        <div style={{ borderTop: '1px dashed #000', padding: '4px 0', marginTop: '6px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>SUBTOTAL:</span>
            <span>{settings.currencySymbol}{sale.subtotal.toFixed(2)}</span>
          </div>
          {sale.discountTotal > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>DISCOUNT:</span>
              <span>-{settings.currencySymbol}{sale.discountTotal.toFixed(2)}</span>
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>TAX:</span>
            <span>{settings.currencySymbol}{sale.taxTotal.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '13px', marginTop: '4px' }}>
            <span>TOTAL:</span>
            <span>{settings.currencySymbol}{sale.total.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', marginTop: '4px' }}>
            <span>TENDER METHOD:</span>
            <span>{sale.paymentMethod.toUpperCase()}</span>
          </div>
          {sale.changeGiven !== undefined && sale.changeGiven > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px' }}>
              <span>CHANGE DUE:</span>
              <span>{settings.currencySymbol}{sale.changeGiven.toFixed(2)}</span>
            </div>
          )}
        </div>

        <div style={{ textAlign: 'center', marginTop: '12px', fontSize: '9px', whiteSpace: 'pre-line' }}>
          {settings.receiptHeader}
          {'\n'}
          {settings.receiptFooter}
          {'\n\n'}
          * THANK YOU FOR YOUR PATRONAGE *
        </div>
      </div>
    );
  }

  // ====================================================
  // THERMAL SALES REPORT (STANDALONE CLEAN DOM FOR PRINTING)
  // ====================================================
  function renderPrintableThermalSalesReport(report: ThermalSalesReport) {
    const is58mm = settings.paperWidth === '58mm';

    return (
      <div
        style={{
          width: is58mm ? '58mm' : '80mm',
          margin: '0 auto',
          fontFamily: "'Courier New', Courier, monospace, monospace",
          fontSize: is58mm ? '9.5px' : '11px',
          lineHeight: '1.35',
          color: '#000000',
          padding: '2px 0'
        }}
      >
        {/* Store Header */}
        <div style={{ textAlign: 'center', marginBottom: '6px' }}>
          <div style={{ fontWeight: 'bold', fontSize: is58mm ? '12px' : '14px', letterSpacing: '0.5px' }}>
            {settings.storeName.toUpperCase()}
          </div>
          {settings.storeAddress && <div style={{ fontSize: is58mm ? '8.5px' : '9.5px' }}>{settings.storeAddress}</div>}
          {settings.storePhone && <div style={{ fontSize: is58mm ? '8.5px' : '9.5px' }}>TEL: {settings.storePhone}</div>}
          {settings.storeEmail && <div style={{ fontSize: is58mm ? '8.5px' : '9.5px' }}>{settings.storeEmail}</div>}
        </div>

        {/* Report Banner */}
        <div style={{ borderTop: '2px solid #000', borderBottom: '2px solid #000', padding: '4px 0', margin: '6px 0', textAlign: 'center' }}>
          <div style={{ fontWeight: 'bold', fontSize: is58mm ? '11px' : '13px' }}>
            *** {report.title} ***
          </div>
          <div style={{ fontSize: is58mm ? '8.5px' : '9.5px', marginTop: '2px', fontWeight: '600' }}>
            COVERAGE: {report.periodLabel.toUpperCase()}
          </div>
        </div>

        {/* Audit & Timing Metadata */}
        <div style={{ fontSize: is58mm ? '8.5px' : '9.5px', margin: '4px 0', lineHeight: '1.4' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>DATE RANGE:</span>
            <span>{report.startDate} - {report.endDate}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>PRINTED AT:</span>
            <span>{report.printedAt}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>TERMINAL:</span>
            <span>REG-01 ({settings.paperWidth})</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>CASHIER:</span>
            <span>{settings.cashierName || 'Store Manager'}</span>
          </div>
        </div>

        {/* Section: Sales Summary & Totals */}
        <div style={{ borderTop: '1px dashed #000', margin: '6px 0', paddingTop: '4px' }}>
          <div style={{ fontWeight: 'bold', textAlign: 'center', margin: '2px 0 4px', fontSize: is58mm ? '9.5px' : '11px' }}>
            === SALES TOTALS ===
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
            <span>ORDERS COMPLETED:</span>
            <span style={{ fontWeight: 'bold' }}>{report.totalOrders}</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
            <span>GROSS SALES:</span>
            <span>{settings.currencySymbol}{report.grossSales.toFixed(2)}</span>
          </div>

          {report.totalDiscounts > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
              <span>DISCOUNTS GIVEN:</span>
              <span>-{settings.currencySymbol}{report.totalDiscounts.toFixed(2)}</span>
            </div>
          )}

          {report.totalRefunded > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
              <span>RETURNS / REFUNDS:</span>
              <span>-{settings.currencySymbol}{report.totalRefunded.toFixed(2)}</span>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0' }}>
            <span>TAX COLLECTED:</span>
            <span>{settings.currencySymbol}{report.totalTax.toFixed(2)}</span>
          </div>

          <div style={{ borderTop: '1px solid #000', margin: '4px 0', paddingTop: '4px', display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: is58mm ? '11px' : '12.5px' }}>
            <span>NET REVENUE:</span>
            <span>{settings.currencySymbol}{report.netSales.toFixed(2)}</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2px 0', fontSize: is58mm ? '8.5px' : '9.5px' }}>
            <span>AVG BASKET (AOV):</span>
            <span>{settings.currencySymbol}{report.aov.toFixed(2)}</span>
          </div>
        </div>

        {/* Section: Payment Breakdown */}
        <div style={{ borderTop: '1px dashed #000', margin: '6px 0', paddingTop: '4px' }}>
          <div style={{ fontWeight: 'bold', textAlign: 'center', margin: '2px 0 4px', fontSize: is58mm ? '9.5px' : '11px' }}>
            === PAYMENT METHODS ===
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '3px 0' }}>
            <span>CASH ({report.cashCount} orders):</span>
            <span style={{ fontWeight: 'bold' }}>{settings.currencySymbol}{report.cashTotal.toFixed(2)}</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '3px 0' }}>
            <span>CARD ({report.cardCount} orders):</span>
            <span style={{ fontWeight: 'bold' }}>{settings.currencySymbol}{report.cardTotal.toFixed(2)}</span>
          </div>

          {report.splitCount > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', margin: '3px 0' }}>
              <span>SPLIT ({report.splitCount} orders):</span>
              <span style={{ fontWeight: 'bold' }}>{settings.currencySymbol}{report.splitTotal.toFixed(2)}</span>
            </div>
          )}

          <div style={{ borderTop: '1px solid #000', margin: '4px 0', paddingTop: '3px', display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
            <span>TOTAL TENDERED:</span>
            <span>{settings.currencySymbol}{(report.cashTotal + report.cardTotal + report.splitTotal).toFixed(2)}</span>
          </div>
        </div>

        {/* Footer & Cut Mark */}
        <div style={{ borderTop: '1px dashed #000', marginTop: '8px', paddingTop: '6px', textAlign: 'center', fontSize: is58mm ? '8.5px' : '9px' }}>
          <div style={{ fontWeight: 'bold' }}>*** END OF SALES REPORT ***</div>
          <div style={{ marginTop: '3px', letterSpacing: '1px', color: '#333' }}>-- TEAR HERE --</div>
          <div style={{ height: '14px' }}></div>
        </div>
      </div>
    );
  }
}
