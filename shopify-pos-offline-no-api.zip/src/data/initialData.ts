import { Product, Customer, StoreSettings, Sale } from '../types';

export const INITIAL_SETTINGS: StoreSettings = {
  storeName: "Meridian Supply Co.",
  storeAddress: "482 Broadway, Soho, New York, NY 10013",
  storePhone: "+1 (212) 555-0194",
  storeEmail: "pos@meridiansupply.co",
  taxRate: 0.08875, // 8.875% NYC sales tax
  currencySymbol: "$",
  receiptHeader: "Thank you for shopping at Meridian",
  receiptFooter: "Returns accepted within 30 days with receipt.\nVisit meridiansupply.co",
  cashierName: "Alex Vance",
  paperWidth: "80mm",
  theme: "light",
  soundEnabled: true,
  inventoryPin: "1111", // Strictly 1111 as required
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "prod-001",
    name: "Heavyweight Cotton Hoodie - Charcoal",
    sku: "APP-HD-001",
    barcode: "840291001827",
    category: "Apparel",
    price: 98.00,
    cost: 42.00,
    stock: 24,
    lowStockThreshold: 5,
    image: "/src/assets/images/pos_product_hoodie_1792100599508.jpg",
    description: "480 GSM organic french terry with double-needle ribbed hems."
  },
  {
    id: "prod-002",
    name: "Ethiopia Guji Specialty Coffee (250g)",
    sku: "BEV-CF-002",
    barcode: "840291002934",
    category: "Beverages",
    price: 22.00,
    cost: 9.50,
    stock: 35,
    lowStockThreshold: 8,
    image: "/src/assets/images/pos_product_coffee_1792100600829.jpg",
    description: "Natural process heirloom variety with notes of jasmine, blueberry & black tea."
  },
  {
    id: "prod-003",
    name: "Aura Cedarwood Ceramic Candle",
    sku: "LIV-CD-003",
    barcode: "840291003451",
    category: "Living",
    price: 36.00,
    cost: 14.00,
    stock: 18,
    lowStockThreshold: 4,
    image: "/src/assets/images/pos_product_candle_1792100601991.jpg",
    description: "Hand-poured coconut soy wax with wood wick in fluted ceramic vessel."
  },
  {
    id: "prod-004",
    name: "Heavy Canvas Utility Tote",
    sku: "ACC-TT-004",
    barcode: "840291004128",
    category: "Accessories",
    price: 64.00,
    cost: 26.00,
    stock: 12,
    lowStockThreshold: 3,
    image: "/src/assets/images/pos_product_tote_1792100600971.jpg",
    description: "18oz unbleached cotton duck canvas with reinforced vegetable-tanned leather handles."
  },
  {
    id: "prod-005",
    name: "Japanese Grid Desk Notebook (A5)",
    sku: "STA-NB-005",
    barcode: "840291005889",
    category: "Stationery",
    price: 18.00,
    cost: 6.50,
    stock: 40,
    lowStockThreshold: 10,
    description: "Fountain pen friendly 80gsm Tomoe River paper with lay-flat binding."
  },
  {
    id: "prod-006",
    name: "Matte Black Thermal Tumbler (16oz)",
    sku: "BEV-TM-006",
    barcode: "840291006771",
    category: "Beverages",
    price: 32.00,
    cost: 13.00,
    stock: 28,
    lowStockThreshold: 6,
    description: "Double-wall vacuum insulated 18/8 food-grade stainless steel with ceramic interior."
  },
  {
    id: "prod-007",
    name: "Merino Wool Beanie - Heather Oatmeal",
    sku: "APP-BN-007",
    barcode: "840291007662",
    category: "Apparel",
    price: 44.00,
    cost: 18.00,
    stock: 15,
    lowStockThreshold: 4,
    description: "100% extra-fine merino wool rib knit, naturally temperature regulating."
  },
  {
    id: "prod-008",
    name: "Smoked Amber Glass Carafe & Tumbler Set",
    sku: "LIV-CR-008",
    barcode: "840291008553",
    category: "Living",
    price: 52.00,
    cost: 21.00,
    stock: 7,
    lowStockThreshold: 3,
    description: "Mouth-blown borosilicate glass bedside water carafe with nesting cup."
  },
  {
    id: "prod-009",
    name: "Solid Brass Rollerball Pen",
    sku: "STA-PN-009",
    barcode: "840291009444",
    category: "Stationery",
    price: 48.00,
    cost: 19.00,
    stock: 19,
    lowStockThreshold: 5,
    description: "Machined solid brass body with Schmidt safety ceramic rollerball refill."
  },
  {
    id: "prod-010",
    name: "Minimalist Italian Leather Cardholder",
    sku: "ACC-WL-010",
    barcode: "840291010335",
    category: "Accessories",
    price: 45.00,
    cost: 17.50,
    stock: 2, // Low stock test case
    lowStockThreshold: 3,
    description: "Full-grain Badalassi Carlo vegetable-tanned leather with 4 card slots."
  },
  {
    id: "prod-011",
    name: "Ceramic Dripper V60 - Matte Moss",
    sku: "BEV-DR-011",
    barcode: "840291011226",
    category: "Beverages",
    price: 28.00,
    cost: 11.00,
    stock: 0, // Out of stock test case
    lowStockThreshold: 4,
    description: "Artisanal stoneware pour-over dripper handcrafted in Arita, Japan."
  },
  {
    id: "prod-012",
    name: "Linen Kitchen Apron - Natural Flax",
    sku: "LIV-AP-012",
    barcode: "840291012117",
    category: "Living",
    price: 58.00,
    cost: 24.00,
    stock: 9,
    lowStockThreshold: 3,
    description: "Pre-washed pure European flax linen with adjustable twill tie straps."
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: "cust-001",
    name: "Elena Rostova",
    email: "elena.rostova@designworks.studio",
    phone: "+1 (917) 555-8321",
    notes: "Prefers email receipts. Enjoys Ethiopian roast coffees.",
    totalOrders: 4,
    totalSpent: 388.50,
    createdAt: "2026-08-12"
  },
  {
    id: "cust-002",
    name: "Marcus Thorne",
    email: "mthorne@archgroup.com",
    phone: "+1 (646) 555-9012",
    notes: "Regular customer, corporate account.",
    totalOrders: 6,
    totalSpent: 624.00,
    createdAt: "2026-07-28"
  },
  {
    id: "cust-003",
    name: "Chloe Chen",
    email: "chloe.chen@lumina.io",
    phone: "+1 (212) 555-4478",
    notes: "Buys home goods and stationery gifts.",
    totalOrders: 2,
    totalSpent: 168.00,
    createdAt: "2026-09-04"
  }
];

export const INITIAL_SALES: Sale[] = [
  {
    id: "sale-1001",
    receiptNumber: "REC-20261014-001",
    items: [
      { product: INITIAL_PRODUCTS[0], quantity: 1 },
      { product: INITIAL_PRODUCTS[1], quantity: 2 }
    ],
    subtotal: 142.00,
    discountTotal: 0,
    taxTotal: 12.60,
    total: 154.60,
    paymentMethod: "card",
    customerName: "Elena Rostova",
    customerId: "cust-001",
    cashier: "Alex Vance",
    date: "2026-10-14T11:20:00",
    status: "completed"
  },
  {
    id: "sale-1002",
    receiptNumber: "REC-20261014-002",
    items: [
      { product: INITIAL_PRODUCTS[2], quantity: 1 },
      { product: INITIAL_PRODUCTS[3], quantity: 1 }
    ],
    subtotal: 100.00,
    discountTotal: 10.00,
    taxTotal: 7.99,
    total: 97.99,
    paymentMethod: "cash",
    cashReceived: 100.00,
    changeGiven: 2.01,
    customerName: "Marcus Thorne",
    customerId: "cust-002",
    cashier: "Alex Vance",
    date: "2026-10-14T14:45:00",
    status: "completed"
  },
  {
    id: "sale-1003",
    receiptNumber: "REC-20261015-001",
    items: [
      { product: INITIAL_PRODUCTS[4], quantity: 2 },
      { product: INITIAL_PRODUCTS[8], quantity: 1 }
    ],
    subtotal: 84.00,
    discountTotal: 0,
    taxTotal: 7.46,
    total: 91.46,
    paymentMethod: "card",
    cashier: "Alex Vance",
    date: "2026-10-15T10:15:00",
    status: "completed"
  },
  {
    id: "sale-1004",
    receiptNumber: "REC-20261015-004",
    items: [
      { product: INITIAL_PRODUCTS[1], quantity: 3 },
      { product: INITIAL_PRODUCTS[5], quantity: 1 }
    ],
    subtotal: 98.00,
    discountTotal: 0,
    taxTotal: 8.70,
    total: 106.70,
    paymentMethod: "card",
    customerName: "Elena Rostova",
    customerId: "cust-001",
    cashier: "Alex Vance",
    date: "2026-10-15T16:30:00",
    status: "completed"
  },
  {
    id: "sale-1005",
    receiptNumber: "REC-20261016-002",
    items: [
      { product: INITIAL_PRODUCTS[8], quantity: 2 },
      { product: INITIAL_PRODUCTS[4], quantity: 3 }
    ],
    subtotal: 150.00,
    discountTotal: 0,
    taxTotal: 13.31,
    total: 163.31,
    paymentMethod: "card",
    customerName: "Marcus Thorne",
    customerId: "cust-002",
    cashier: "Alex Vance",
    date: "2026-10-16T09:40:00",
    status: "completed"
  },
  {
    id: "sale-1006",
    receiptNumber: "REC-20261016-003",
    items: [
      { product: INITIAL_PRODUCTS[7], quantity: 1 },
      { product: INITIAL_PRODUCTS[2], quantity: 2 }
    ],
    subtotal: 124.00,
    discountTotal: 0,
    taxTotal: 11.00,
    total: 135.00,
    paymentMethod: "card",
    customerName: "Chloe Chen",
    customerId: "cust-003",
    cashier: "Alex Vance",
    date: "2026-10-16T11:15:00",
    status: "completed"
  }
];
