# Shopify POS – Offline Point of Sale

A fully offline retail POS (React + Vite + Tailwind). **No API key, no backend, no
network calls** – all data (products, customers, sales, refunds, settings) is stored in
the browser's `localStorage`, and backups/reports are generated locally (XLSX / PDF).

## Run locally

Prerequisite: Node.js 18+

```bash
npm install
npm run dev        # http://localhost:3000
```

## Build for production

```bash
npm run build      # outputs ./dist (static files)
npm run preview    # serve the built app locally
```

`dist/` can be hosted on any static host (or a local web server) and works with no
internet connection once loaded. Use the in-app Excel backup export regularly, since
browser storage is per-browser/per-device.
