// Hardware utilities: WebHID, WebUSB, WebSerial real device detection, barcode keyboard wedge, and Web Audio feedback

export interface HardwareManager {
  checkRealDevices: () => Promise<{
    scannerConnected: boolean;
    scannerName: string;
    printerConnected: boolean;
    printerName: string;
  }>;
  requestScannerConnection: () => Promise<{ success: boolean; name?: string; error?: string }>;
  requestPrinterConnection: () => Promise<{ success: boolean; name?: string; error?: string }>;
}

export const hardwareManager: HardwareManager = {
  async checkRealDevices() {
    let scannerConnected = false;
    let scannerName = "Disconnected";
    let printerConnected = false;
    let printerName = "Disconnected";

    try {
      // 1. Check WebHID for connected Barcode Scanners
      if ('hid' in navigator && (navigator as any).hid?.getDevices) {
        const hidDevices = await (navigator as any).hid.getDevices();
        if (hidDevices.length > 0) {
          scannerConnected = true;
          scannerName = hidDevices[0].productName || "HID Barcode Scanner";
        }
      }

      // 2. Check WebUSB if HID had no devices
      if (!scannerConnected && 'usb' in navigator && (navigator as any).usb?.getDevices) {
        const usbDevices = await (navigator as any).usb.getDevices();
        if (usbDevices.length > 0) {
          scannerConnected = true;
          scannerName = usbDevices[0].productName || "USB Barcode Reader";
        }
      }

      // 3. Check WebSerial for POS Receipt Printers (common ESC/POS thermal interface)
      if ('serial' in navigator && (navigator as any).serial?.getPorts) {
        const serialPorts = await (navigator as any).serial.getPorts();
        if (serialPorts.length > 0) {
          printerConnected = true;
          const info = serialPorts[0].getInfo?.() || {};
          printerName = `POS Printer (USB VID:${info.usbVendorId || 'Serial'})`;
        }
      }

      // 4. Check WebUSB for direct USB thermal printers
      if (!printerConnected && 'usb' in navigator && (navigator as any).usb?.getDevices) {
        const usbDevices = await (navigator as any).usb.getDevices();
        const printerDev = usbDevices.find((d: any) => 
          (d.productName && /print|receipt|thermal|pos|epson|star/i.test(d.productName))
        );
        if (printerDev) {
          printerConnected = true;
          printerName = printerDev.productName || "USB Receipt Printer";
        }
      }
    } catch {
      // Hardware access denied or unpermitted in iframe
    }

    return {
      scannerConnected,
      scannerName,
      printerConnected,
      printerName,
    };
  },

  async requestScannerConnection() {
    // Attempt real WebHID pairing first
    if ('hid' in navigator && (navigator as any).hid?.requestDevice) {
      try {
        const devices = await (navigator as any).hid.requestDevice({
          filters: [] // Allow user to pick any connected HID barcode device
        });
        if (devices && devices.length > 0) {
          const device = devices[0];
          return {
            success: true,
            name: device.productName || "Connected HID Scanner"
          };
        }
      } catch (err: any) {
        if (err.name === 'SecurityError' || err.name === 'NotAllowedError') {
          // May be restricted in certain iframe policies; fall back or report real status
          return { success: false, error: err.message || "Device pairing was cancelled or not allowed in current browser context." };
        }
      }
    }

    // Try WebUSB as fallback
    if ('usb' in navigator && (navigator as any).usb?.requestDevice) {
      try {
        const device = await (navigator as any).usb.requestDevice({ filters: [] });
        return {
          success: true,
          name: device.productName || "Connected USB Scanner"
        };
      } catch (err: any) {
        return { success: false, error: err.message || "Pairing was cancelled." };
      }
    }

    return {
      success: false,
      error: "WebHID / WebUSB is not supported in this browser or security context. Barcode scanners can still be used via standard USB Keyboard Wedge (instant typing)."
    };
  },

  async requestPrinterConnection() {
    // Attempt WebSerial pairing first (Standard for ESC/POS thermal printers)
    if ('serial' in navigator && (navigator as any).serial?.requestPort) {
      try {
        const port = await (navigator as any).serial.requestPort();
        const info = port.getInfo?.() || {};
        return {
          success: true,
          name: `Thermal Printer (VID: ${info.usbVendorId || 'Generic'})`
        };
      } catch (err: any) {
        return { success: false, error: err.message || "Printer pairing cancelled." };
      }
    }

    // Attempt WebUSB
    if ('usb' in navigator && (navigator as any).usb?.requestDevice) {
      try {
        const device = await (navigator as any).usb.requestDevice({ filters: [] });
        return {
          success: true,
          name: device.productName || "USB Thermal Printer"
        };
      } catch (err: any) {
        return { success: false, error: err.message || "Printer pairing cancelled." };
      }
    }

    return {
      success: false,
      error: "WebSerial / WebUSB not supported. Browser printing (Thermal Receipt Layout) is fully operational via System Print Dialog."
    };
  }
};

// Web Audio API Synthesizer for Shopify POS sound feedback
export function playSound(type: 'beep' | 'success' | 'alert' | 'error') {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'beep') {
      // Crisp POS scan beep (1800Hz, 70ms)
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1850, now);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === 'success') {
      // Shopify double chime (C6 -> G6)
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1046.5, now);
      osc.frequency.setValueAtTime(1567.98, now + 0.09);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'alert') {
      // Warning double tone
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(370, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.start(now);
      osc.stop(now + 0.22);
    } else if (type === 'error') {
      // Low buzz
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.start(now);
      osc.stop(now + 0.18);
    }
  } catch {
    // Audio context may be muted or blocked before user gesture
  }
}
