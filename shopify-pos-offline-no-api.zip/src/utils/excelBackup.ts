import * as XLSX from 'xlsx';
import { Product, Sale, Refund, Customer, StoreSettings } from '../types';

export function exportFullBackupXLSX(
  products: Product[],
  sales: Sale[],
  refunds: Refund[],
  customers: Customer[],
  settings: StoreSettings
) {
  const wb = XLSX.utils.book_new();

  // 1. Products sheet
  const productRows = products.map(p => ({
    ID: p.id,
    Name: p.name,
    SKU: p.sku,
    Barcode: p.barcode,
    Category: p.category,
    Price: p.price,
    Cost: p.cost,
    Stock: p.stock,
    LowStockThreshold: p.lowStockThreshold,
    Description: p.description || ''
  }));
  const wsProducts = XLSX.utils.json_to_sheet(productRows);
  XLSX.utils.book_append_sheet(wb, wsProducts, "Inventory");

  // 2. Sales sheet
  const saleRows = sales.map(s => ({
    SaleID: s.id,
    ReceiptNumber: s.receiptNumber,
    Date: s.date,
    Cashier: s.cashier,
    Customer: s.customerName || 'Walk-in',
    Subtotal: s.subtotal,
    Discount: s.discountTotal,
    Tax: s.taxTotal,
    Total: s.total,
    PaymentMethod: s.paymentMethod,
    Status: s.status,
    ItemsCount: s.items.reduce((sum, it) => sum + it.quantity, 0)
  }));
  const wsSales = XLSX.utils.json_to_sheet(saleRows);
  XLSX.utils.book_append_sheet(wb, wsSales, "Sales");

  // 3. Sale Items detail sheet
  const itemRows: any[] = [];
  sales.forEach(s => {
    s.items.forEach(it => {
      itemRows.push({
        ReceiptNumber: s.receiptNumber,
        Date: s.date,
        ProductName: it.product.name,
        SKU: it.product.sku,
        Barcode: it.product.barcode,
        UnitPrice: it.product.price,
        Quantity: it.quantity,
        LineTotal: (it.customPrice ?? it.product.price) * it.quantity
      });
    });
  });
  const wsItems = XLSX.utils.json_to_sheet(itemRows);
  XLSX.utils.book_append_sheet(wb, wsItems, "Sold_Items");

  // 4. Refunds sheet
  const refundRows = refunds.map(r => ({
    RefundID: r.id,
    RefundNumber: r.refundNumber,
    OriginalReceipt: r.receiptNumber,
    Date: r.date,
    Cashier: r.cashier,
    TotalRefunded: r.totalRefunded,
    Reason: r.reason,
    ItemsSummary: r.items.map(it => `${it.productName} (x${it.quantity})`).join(', ')
  }));
  const wsRefunds = XLSX.utils.json_to_sheet(refundRows);
  XLSX.utils.book_append_sheet(wb, wsRefunds, "Refunds");

  // 5. Customers sheet
  const customerRows = customers.map(c => ({
    CustomerID: c.id,
    Name: c.name,
    Email: c.email,
    Phone: c.phone,
    TotalOrders: c.totalOrders,
    TotalSpent: c.totalSpent,
    Notes: c.notes || ''
  }));
  const wsCustomers = XLSX.utils.json_to_sheet(customerRows);
  XLSX.utils.book_append_sheet(wb, wsCustomers, "Customers");

  // Generate file name with current local date
  const cleanStoreName = settings.storeName.replace(/[^a-zA-Z0-9]/g, '_');
  const todayStr = new Date().toISOString().slice(0, 10);
  const fileName = `${cleanStoreName}_Full_POS_Backup_${todayStr}.xlsx`;

  XLSX.writeFile(wb, fileName);
}

export function exportInventoryXLSX(products: Product[], storeName: string) {
  const wb = XLSX.utils.book_new();
  const rows = products.map(p => ({
    Name: p.name,
    SKU: p.sku,
    Barcode: p.barcode,
    Category: p.category,
    Price: p.price,
    Cost: p.cost,
    Stock: p.stock,
    LowStockThreshold: p.lowStockThreshold,
    Description: p.description || ''
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Inventory");

  const todayStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `${storeName.replace(/\s+/g, '_')}_Inventory_${todayStr}.xlsx`);
}

export async function parseInventoryXLSX(file: File): Promise<{ success: boolean; products?: Product[]; message: string }> {
  try {
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    if (!firstSheetName) {
      return { success: false, message: "No sheet found in uploaded Excel file." };
    }

    const worksheet = workbook.Sheets[firstSheetName];
    const rawRows: any[] = XLSX.utils.sheet_to_json(worksheet);

    if (rawRows.length === 0) {
      return { success: false, message: "Excel sheet is empty. Please ensure it has product records." };
    }

    const importedProducts: Product[] = [];

    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i];
      const name = row.Name || row.name || row.Title || row.title || row.ProductName || `Product ${i + 1}`;
      const sku = String(row.SKU || row.sku || `SKU-${Date.now().toString().slice(-4)}-${i + 1}`);
      const barcode = String(row.Barcode || row.barcode || row.UPC || row.upc || Math.floor(100000000000 + Math.random() * 900000000000));
      const category = row.Category || row.category || 'General';
      const price = parseFloat(row.Price ?? row.price ?? 0);
      const cost = parseFloat(row.Cost ?? row.cost ?? 0);
      const stock = parseInt(row.Stock ?? row.stock ?? row.Quantity ?? row.quantity ?? 10, 10);
      const lowStockThreshold = parseInt(row.LowStockThreshold ?? row.lowStockThreshold ?? 5, 10);
      const description = row.Description || row.description || '';

      importedProducts.push({
        id: `prod-import-${Date.now()}-${i}`,
        name: String(name).trim(),
        sku: sku.trim(),
        barcode: barcode.trim(),
        category: String(category).trim(),
        price: isNaN(price) ? 0 : price,
        cost: isNaN(cost) ? 0 : cost,
        stock: isNaN(stock) ? 0 : stock,
        lowStockThreshold: isNaN(lowStockThreshold) ? 5 : lowStockThreshold,
        description: String(description).trim()
      });
    }

    return {
      success: true,
      products: importedProducts,
      message: `Successfully imported ${importedProducts.length} products from Excel.`
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Failed to parse Excel file: ${err.message || 'Unknown error'}`
    };
  }
}
