# Customer Details Edit & Management in Directory

## Overview
Enable store cashiers and managers to view, edit, and delete customer records directly from the Customer Directory table via a dedicated modal dialog. This updates customer contact info (name, email, phone, notes) while keeping purchase statistics intact, and syncs across active register sessions.

## User Review & Critical Decisions
> [!IMPORTANT]
> The following design choices were confirmed in Phase 1:
> - **Access Location**: Placed in the **Customer Directory table only** via a dedicated row action column.
> - **Editable Attributes & Actions**: Contact info (Name, Phone, Email, Internal Notes) plus an option to **Delete Customer** with confirmation.
> - **Interface Presentation**: Clean, accessible **Modal Dialog** with pre-filled inputs, Cancel, Delete, and Save Changes buttons.

- **Confirmed Decision 1**: Add an **Actions** column to the Customer Directory table containing an **Edit** button with a pencil icon for every customer record.
- **Confirmed Decision 2**: Edit modal includes a safety confirmation step before deleting a customer to avoid accidental record loss.
- **Confirmed Decision 3**: Synchronize active register session (`selectedCustomer`) if the edited customer is currently attached to the cart.

---

## 1. Overview & Core Concept
- **What It Does**: Cashiers and managers can manage customer records directly from the Customer Directory screen. Clicking "Edit" on any customer opens a modal dialog pre-filled with the customer's current name, email, phone, and notes, displays their lifetime spend and order count, allows editing contact information, and provides a safe deletion flow.
- **Target Audience**: Retail cashiers and store managers maintaining client relationship data and phone/email directories.
- **Key Value**: Eliminates the previous limitation where customers could only be created but never modified or removed.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Navigate to Customer Directory**: User clicks the "Customers" tab in the main sidebar.
2. **Locate Customer & Click Edit**: User searches or scrolls through the directory table. In the rightmost **Actions** column, clicks the **Edit** button (`<Edit className="w-3.5 h-3.5" />`).
3. **Modal Dialog Opens**:
   - Header: "Edit Customer Details" with customer name and close (`X`) button.
   - Profile summary bar: Initial avatar badge, lifetime orders, total spent, and registered date.
   - Form fields: Full Name (required), Phone Number, Email Address, and Internal Notes (textarea).
   - Footer actions:
     - Left: "Delete Customer" button with red text and trash icon. Clicking prompts inline confirmation ("Are you sure? Click again to confirm" or confirmation dialog).
     - Right: "Cancel" button and primary "Save Changes" button (`#008060` Shopify green).
4. **Save Flow**: Form validates inputs, updates state and localStorage, updates `selectedCustomer` if matching, plays audio confirmation, and closes the modal.
5. **Delete Flow**: Clears customer from directory, resets `selectedCustomer` if matching, plays audio feedback, and closes modal.

### Visual Identity & Theme
- **Color Palette**: Shopify Polaris design tokens — `#008060` primary green, `#d82c0d` danger red for deletion, `#f4f6f8` / dark `#111213` surfaces, `#202223` / dark `#ffffff` text.
- **Typography & Layout**: Standard 12px/13px system font with tabular numbers for phone, spend, and order stats. Anti-slop zero-pill discipline for metadata.
- **Interactive Feedback**: Hover states on table rows, focus rings on input fields, responsive touch targets ($\ge 40\text{px}$).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Action Placement in Table Only**:
  - *Chosen Approach*: An "Actions" column in the Customer Directory table with an explicit Edit button.
  - *Why*: Conforms strictly to the user's choice to keep customer editing in the directory table, preventing clutter in the fast-paced register checkout bar.
- **Decision 2: Safe Deletion Handling**:
  - *Chosen Approach*: Two-step confirmation (inline state or alert confirmation) before deleting a customer.
  - *Why*: Prevents accidental taps in a touch/POS environment that could wipe customer purchase records.
- **Decision 3: State Synchronization**:
  - *Chosen Approach*: When a customer is updated or deleted, inspect `selectedCustomer`. If it matches, update or clear it immediately.
  - *Why*: Guarantees that sales completed on the register right after editing use the newly updated name and contact information.

---

## 4. Technical Architecture & Component Structure

```
┌────────────────────────────────────────────────────────┐
│                   Customer Directory                   │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Table: Name | Email | Phone | Orders | Spent | Act│  │
│  │ John Doe | ...    | ...   | 4      | $120  | [✎] │──┼──► Click [Edit]
│  └──────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
              ┌───────────────────────────┐
              │    Edit Customer Modal    │
              │ ───────────────────────── │
              │ • Full Name               │
              │ • Email                   │
              │ • Phone                   │
              │ • Notes                   │
              │                           │
              │ [🗑 Delete]  [Cancel] [Save]│
              └─────────────┬─────────────┘
                            │
                ┌───────────┴───────────┐
                ▼                       ▼
      [Delete Customer]          [Save Changes]
      - Remove from list         - Mutate customer list
      - Clear active session     - Update active session
      - Save to localStorage     - Save to localStorage
```

### State & Handler Specifications
1. **State Declarations**:
   - `editingCustomer: Customer | null` (holds customer entity currently being edited).
   - `showDeleteConfirm: boolean` (safety confirmation flag for deletion).
2. **Handlers**:
   - `handleEditCustomer(cust: Customer)`: Sets `editingCustomer` and opens modal.
   - `handleSaveCustomer(updated: Customer)`: Updates `customers` list, syncs `selectedCustomer`, updates localStorage, plays audio cue.
   - `handleDeleteCustomer(id: string)`: Removes customer, cleans up `selectedCustomer`, plays audio cue, closes modal.
3. **UI Integration**:
   - Update `renderCustomersScreen()` table header to add `<th className="py-3 px-4 text-right">Actions</th>`.
   - Update table rows to add `<td className="py-3 px-4 text-right">` with `<button onClick={() => handleEditCustomer(cust)} className="p-1.5 hover:bg-[#eaecee] ..."><Edit className="w-4 h-4 text-[#5c5f62]" /></button>`.
   - Add `renderEditCustomerModal()` to modal overlays in `App.tsx`.
