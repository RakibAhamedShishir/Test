export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  lowStockThreshold: number;
  image?: string;
  description?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  discountType?: 'percent' | 'fixed';
  discountValue?: number;
  customPrice?: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  notes?: string;
  totalOrders: number;
  totalSpent: number;
  createdAt: string;
}

export type PaymentMethod = 'cash' | 'card' | 'split';

export interface Sale {
  id: string;
  receiptNumber: string;
  items: CartItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  total: number;
  paymentMethod: PaymentMethod;
  cashReceived?: number;
  changeGiven?: number;
  cardAmount?: number;
  cashAmount?: number;
  customerId?: string;
  customerName?: string;
  cashier: string;
  date: string;
  status: 'completed' | 'refunded' | 'partially_refunded';
  note?: string;
}

export interface RefundItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  refundAmount: number;
}

export interface Refund {
  id: string;
  refundNumber: string;
  originalSaleId: string;
  receiptNumber: string;
  items: RefundItem[];
  totalRefunded: number;
  reason: string;
  date: string;
  cashier: string;
}

export interface StoreSettings {
  storeName: string;
  storeAddress: string;
  storePhone: string;
  storeEmail: string;
  taxRate: number; // e.g. 0.08 for 8%
  currencySymbol: string;
  receiptHeader: string;
  receiptFooter: string;
  cashierName: string;
  paperWidth: '80mm' | '58mm';
  theme: 'light' | 'dark';
  soundEnabled: boolean;
  inventoryPin: string; // strictly '1111'
}

export interface HardwareState {
  scannerConnected: boolean;
  scannerName: string;
  printerConnected: boolean;
  printerName: string;
  lastScannedBarcode: string;
}

export interface ThermalSalesReport {
  type: 'weekly' | 'monthly';
  title: string;
  periodLabel: string;
  startDate: string;
  endDate: string;
  printedAt: string;
  totalOrders: number;
  grossSales: number;
  totalDiscounts: number;
  totalRefunded: number;
  totalTax: number;
  netSales: number;
  aov: number;
  cashCount: number;
  cashTotal: number;
  cardCount: number;
  cardTotal: number;
  splitCount: number;
  splitTotal: number;
}

