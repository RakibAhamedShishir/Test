import { jsPDF } from 'jspdf';
import { Sale, Refund, StoreSettings } from '../types';

export function generateSalesReportPDF(
  period: 'weekly' | 'monthly',
  sales: Sale[],
  refunds: Refund[],
  settings: StoreSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const now = new Date();
  const periodLabel = period === 'weekly' ? 'Weekly Sales Summary' : 'Monthly Executive Sales Report';
  const dateRangeStr = period === 'weekly'
    ? `Past 7 Days (Ending ${now.toLocaleDateString()})`
    : `Month of ${now.toLocaleString('default', { month: 'long', year: 'numeric' })}`;

  // Filter sales for period
  const cutoffDays = period === 'weekly' ? 7 : 30;
  const cutoffTime = now.getTime() - cutoffDays * 24 * 60 * 60 * 1000;

  const relevantSales = sales.filter(s => new Date(s.date).getTime() >= cutoffTime);
  const relevantRefunds = refunds.filter(r => new Date(r.date).getTime() >= cutoffTime);

  const grossSales = relevantSales.reduce((acc, s) => acc + s.subtotal, 0);
  const totalTax = relevantSales.reduce((acc, s) => acc + s.taxTotal, 0);
  const totalDiscounts = relevantSales.reduce((acc, s) => acc + s.discountTotal, 0);
  const totalRefunded = relevantRefunds.reduce((acc, r) => acc + r.totalRefunded, 0);
  const netSales = grossSales - totalDiscounts - totalRefunded;
  const totalTransactions = relevantSales.length;
  const aov = totalTransactions > 0 ? (grossSales / totalTransactions) : 0;

  // Payment breakdown
  const cashSales = relevantSales.filter(s => s.paymentMethod === 'cash').reduce((acc, s) => acc + s.total, 0);
  const cardSales = relevantSales.filter(s => s.paymentMethod === 'card').reduce((acc, s) => acc + s.total, 0);
  const splitSales = relevantSales.filter(s => s.paymentMethod === 'split').reduce((acc, s) => acc + s.total, 0);

  // Top products
  const productCountMap = new Map<string, { name: string; qty: number; revenue: number }>();
  relevantSales.forEach(s => {
    s.items.forEach(it => {
      const existing = productCountMap.get(it.product.name) || { name: it.product.name, qty: 0, revenue: 0 };
      existing.qty += it.quantity;
      existing.revenue += (it.customPrice ?? it.product.price) * it.quantity;
      productCountMap.set(it.product.name, existing);
    });
  });

  const topProducts = Array.from(productCountMap.values())
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  // Styling - Shopify Polaris Brand Palette
  // Header Charcoal Banner
  doc.setFillColor(26, 26, 26); // #1a1a1a
  doc.rect(0, 0, 210, 32, 'F');

  // Accent Line
  doc.setFillColor(0, 128, 96); // #008060 Shopify Green
  doc.rect(0, 32, 210, 2.5, 'F');

  // Header Text
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(settings.storeName.toUpperCase(), 14, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(200, 200, 200);
  doc.text(`${settings.storeAddress}  |  ${settings.storePhone}`, 14, 23);

  // Title Right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text(periodLabel.toUpperCase(), 196, 15, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(200, 200, 200);
  doc.text(dateRangeStr, 196, 23, { align: 'right' });

  // Body content
  let y = 44;

  // Executive KPI Cards (Row of 4 metrics)
  doc.setFillColor(244, 246, 248); // #f4f6f8
  doc.setDrawColor(225, 227, 229); // #e1e3e5

  const kpis = [
    { label: 'GROSS SALES', val: `${settings.currencySymbol}${grossSales.toFixed(2)}` },
    { label: 'NET SALES', val: `${settings.currencySymbol}${netSales.toFixed(2)}` },
    { label: 'TRANSACTIONS', val: `${totalTransactions}` },
    { label: 'AVG ORDER VALUE', val: `${settings.currencySymbol}${aov.toFixed(2)}` },
  ];

  const colWidth = 43;
  const colGap = 4;
  kpis.forEach((kpi, idx) => {
    const x = 14 + idx * (colWidth + colGap);
    doc.roundedRect(x, y, colWidth, 22, 2, 2, 'FD');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(110, 115, 122);
    doc.text(kpi.label, x + 4, y + 7);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(26, 26, 26);
    doc.text(kpi.val, x + 4, y + 17);
  });

  y += 30;

  // Section 1: Financial Reconciliation
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(26, 26, 26);
  doc.text("Financial Breakdown & Revenue Statement", 14, y);

  doc.setDrawColor(225, 227, 229);
  doc.line(14, y + 2, 196, y + 2);

  y += 8;

  const financialItems = [
    ["Gross Merchandise Volume (GMV)", `${settings.currencySymbol}${grossSales.toFixed(2)}`],
    ["Total Discounts Applied", `-${settings.currencySymbol}${totalDiscounts.toFixed(2)}`],
    ["Total Refunds Processed", `-${settings.currencySymbol}${totalRefunded.toFixed(2)}`],
    ["Estimated Sales Tax Collected", `${settings.currencySymbol}${totalTax.toFixed(2)}`],
    ["Net Total Revenue (Excl. Tax)", `${settings.currencySymbol}${netSales.toFixed(2)}`],
  ];

  financialItems.forEach(([label, value], i) => {
    doc.setFont('helvetica', i === financialItems.length - 1 ? 'bold' : 'normal');
    doc.setFontSize(9);
    doc.setTextColor(i === financialItems.length - 1 ? 0 : 70, i === financialItems.length - 1 ? 128 : 70, i === financialItems.length - 1 ? 96 : 70);
    doc.text(label, 16, y);
    doc.text(value, 194, y, { align: 'right' });
    y += 6.5;
  });

  y += 6;

  // Section 2: Payment Tenders
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(26, 26, 26);
  doc.text("Payment Tender Distribution", 14, y);
  doc.line(14, y + 2, 196, y + 2);

  y += 8;
  const paymentItems = [
    ["Credit / Debit Card (EMV/NFC)", `${settings.currencySymbol}${cardSales.toFixed(2)}`, `${grossSales > 0 ? ((cardSales / grossSales) * 100).toFixed(1) : 0}%`],
    ["Cash Tendered", `${settings.currencySymbol}${cashSales.toFixed(2)}`, `${grossSales > 0 ? ((cashSales / grossSales) * 100).toFixed(1) : 0}%`],
    ["Split / Mixed Tender", `${settings.currencySymbol}${splitSales.toFixed(2)}`, `${grossSales > 0 ? ((splitSales / grossSales) * 100).toFixed(1) : 0}%`],
  ];

  paymentItems.forEach(([label, amount, pct]) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(50, 50, 50);
    doc.text(label, 16, y);
    doc.text(pct, 140, y, { align: 'right' });
    doc.setFont('helvetica', 'bold');
    doc.text(amount, 194, y, { align: 'right' });
    y += 6.5;
  });

  y += 8;

  // Section 3: Top Performing SKUs
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(26, 26, 26);
  doc.text("Top Selling Inventory Items", 14, y);
  doc.line(14, y + 2, 196, y + 2);

  y += 7;

  // Table Header
  doc.setFillColor(240, 242, 244);
  doc.rect(14, y - 4, 182, 7, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(90, 90, 90);
  doc.text("PRODUCT NAME", 16, y);
  doc.text("QTY SOLD", 140, y, { align: 'right' });
  doc.text("GROSS REVENUE", 194, y, { align: 'right' });

  y += 6;

  if (topProducts.length === 0) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8.5);
    doc.setTextColor(130, 130, 130);
    doc.text("No transactions recorded in this period.", 16, y);
    y += 8;
  } else {
    topProducts.forEach((tp) => {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(40, 40, 40);
      doc.text(tp.name, 16, y);
      doc.text(`${tp.qty} units`, 140, y, { align: 'right' });
      doc.setFont('helvetica', 'bold');
      doc.text(`${settings.currencySymbol}${tp.revenue.toFixed(2)}`, 194, y, { align: 'right' });
      y += 6;
    });
  }

  // Footer & Audit Sign-off
  const footerY = 275;
  doc.setDrawColor(225, 227, 229);
  doc.line(14, footerY, 196, footerY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(140, 145, 150);
  doc.text(`Generated by ${settings.cashierName} on ${now.toLocaleString()} | Shopify POS Offline Engine`, 14, footerY + 5);
  doc.text(`Store ID: POS-NY-SOC-01 | Page 1 of 1`, 196, footerY + 5, { align: 'right' });

  // Save PDF
  const cleanStoreName = settings.storeName.replace(/[^a-zA-Z0-9]/g, '_');
  const dateStr = now.toISOString().slice(0, 10);
  const filename = `${cleanStoreName}_${period === 'weekly' ? 'Weekly' : 'Monthly'}_Sales_Report_${dateStr}.pdf`;
  doc.save(filename);
}
